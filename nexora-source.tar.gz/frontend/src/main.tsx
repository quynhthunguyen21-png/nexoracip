import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './App.css';
import './figma-reference.css';
import './requested-ui.css';
import './enterprise-ui.css';
import './task-ui.css';
import './governance-ui.css';
import './skills-ui.css';
import './unified-ui.css';
import './compact-ai.css';
import './jira-review.css';
import './case-workspace.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode><App /></StrictMode>,
);
