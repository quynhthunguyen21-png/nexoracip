import type {PlanDraft} from './legalPlan.ts';
export interface ProposalSeed {title:string;summary:string;origin:'rules'|'openai'|'gemini';reference:string;documentId?:string;sourceExcerpt?:string;items:{title:string;rationale:string;evidence:string;department?:string;owner?:string;accountable?:string;priority?:'high'|'medium'|'low'}[]}
export function planFromFindings(seed:ProposalSeed,documentId:string):PlanDraft{
 if(!seed.items.length||seed.items.length>8)throw Error('Select 1–8 findings');
 return {documentId,summary:seed.summary.slice(0,5000),sourceExcerpt:(seed.sourceExcerpt||'').slice(0,12000),missing:'Chưa kết luận vi phạm. Cần xác minh bản nguồn, phạm vi áp dụng, cấu hình thực tế và phân công/hạn nội bộ trước triển khai. / No violation confirmed. Verify sources, applicability, actual implementation and assignments/targets before deployment.',origin:seed.origin,reviewReference:seed.reference,actions:seed.items.map(i=>({title:i.title.slice(0,1000),department:i.department||'unassigned',owner:i.owner||'',accountable:i.accountable||'',due:'',priority:i.priority||'high',expectedEvidence:i.evidence.slice(0,1000),rationale:i.rationale.slice(0,2000)}))};
}
