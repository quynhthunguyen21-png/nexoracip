import {legalCatalog} from './legalCatalog.ts';
/** Historical synthetic scenarios are retained for existing saved records. */
export type Locale = 'vi' | 'en';
export type Bilingual = { vi: string; en: string };
const b = (vi: string, en: string): Bilingual => ({ vi, en });
export const documents = [
  { id: 'SYN-01', title: b('Tình huống mẫu: dữ liệu đăng ký dịch vụ', 'Sample scenario: service registration data'), category: b('Thu thập dữ liệu', 'Data collection'), passage: b('Kịch bản giả định: một biểu mẫu đăng ký nhận tên và email để tạo tài khoản dịch vụ.', 'Synthetic scenario: a registration form collects a name and email to create a service account.'), question: b('Biểu mẫu đang thu thập gì, nhằm mục đích nào và ai có thể truy cập?', 'What does the form collect, for what purpose, and who can access it?'), actions: [b('Lập danh sách trường dữ liệu trên biểu mẫu mẫu', 'List the fields in the sample registration form'), b('Ghi lại mục đích xử lý giả định để nhóm rà soát', 'Document assumed processing purposes for team review'), b('Chuẩn bị câu hỏi xác minh nguồn pháp lý với nhóm', 'Prepare legal-source verification questions for the team')] },
  { id: 'SYN-02', title: b('Tình huống mẫu: chia sẻ với nhà cung cấp', 'Sample scenario: sharing with a supplier'), category: b('Chia sẻ dữ liệu', 'Data sharing'), passage: b('Kịch bản giả định: doanh nghiệp dùng một nhà cung cấp hạ tầng để lưu dữ liệu dịch vụ. Chưa có thông tin vị trí lưu hoặc hợp đồng.', 'Synthetic scenario: a business uses an infrastructure supplier to store service data. Storage location and contract details are missing.'), question: b('Nhà cung cấp nào tham gia và thông tin nào còn thiếu?', 'Which supplier is involved and which details are missing?'), actions: [b('Ghi nhận nhà cung cấp hạ tầng giả định', 'Record the fictional infrastructure supplier'), b('Lập danh sách thông tin lưu trữ cần xác minh', 'List storage details that need verification'), b('Chuẩn bị checklist hợp đồng để nhóm xem xét', 'Prepare a contract checklist for team discussion')] },
  { id: 'SYN-03', title: b('Tình huống mẫu: lưu giữ và xóa dữ liệu', 'Sample scenario: retention and deletion'), category: b('Vòng đời dữ liệu', 'Data lifecycle'), passage: b('Kịch bản giả định: tài khoản ngừng sử dụng vẫn còn dữ liệu trong hệ thống mẫu. Chưa có thời hạn lưu giữ đã thống nhất.', 'Synthetic scenario: an inactive account still has data in the sample system. No retention period has been agreed.'), question: b('Dữ liệu nào còn lưu và ai sẽ xác nhận tiêu chí lưu giữ?', 'Which data remains and who will confirm retention criteria?'), actions: [b('Liệt kê nơi lưu dữ liệu trong hệ thống mẫu', 'List data locations in the sample system'), b('Ghi nhận câu hỏi về tiêu chí lưu giữ nội bộ', 'Record questions about internal retention criteria'), b('Chuẩn bị tình huống kiểm thử xóa giả lập', 'Prepare a simulated deletion test scenario')] },
  ...legalCatalog.map(d=>({id:d.id,title:b(d.title,d.title),category:b(d.kind.trim(),d.kind.trim()),passage:b('Chưa có trích đoạn điều khoản được xác minh.','Verified clause excerpt not supplied.'),question:b('Cần đối chiếu điều khoản và hoạt động doanh nghiệp trước khi xác định nghĩa vụ.','Compare clauses and company activities before establishing obligations.'),actions:[] as Bilingual[]})),
];
export type DemoDocument = typeof documents[number];
export interface Company { name: string; department: string; activity: string }
export interface Analysis { id: string; documentId: string; company: Company; createdAt: string }
export interface Proposal { id: string; analysisId: string; documentId: string; title: Bilingual; status: 'pending' | 'changes_requested' | 'approved' | 'rejected'; note: string }
export interface Task { id: string; proposalId: string; title: Bilingual; department: string; status: 'todo' | 'in_progress' | 'awaiting_confirmation' | 'needs_evidence' | 'done'; due: string; evidence: string }
export interface DemoEvent { id: string; at: string; kind: 'analysis' | 'approved' | 'changes' | 'rejected' | 'edited' | 'task'; subject: string }
export interface DemoState { version: 1; company: Company; selectedDocumentId: string; analyses: Analysis[]; proposals: Proposal[]; tasks: Task[]; events: DemoEvent[] }
export const STORAGE_KEY = 'nexora-cip-personal-prototype-v1';
export function initialState(): DemoState { return { version: 1, company: { name: 'Nexora Sandbox', department: 'Nhóm sản phẩm / Product team', activity: 'Cổng dịch vụ giả lập / Fictional service portal' }, selectedDocumentId: 'SYN-01', analyses: [], proposals: [], tasks: [], events: [] }; }
export type DemoAction =
  | { type: 'company'; company: Company }
  | { type: 'select'; id: string }
  | { type: 'analyze'; id: string; at: string }
  | { type: 'review'; id: string; decision: 'approved' | 'changes_requested' | 'rejected'; note: string; at: string }
  | { type: 'edit'; id: string; title: string; locale: Locale; at: string }
  | { type: 'task'; id: string; status: Task['status']; evidence: string; due: string; department: string; at: string };
export function reducer(state: DemoState, action: DemoAction): DemoState {
  if (action.type === 'company') return { ...state, company: action.company };
  if (action.type === 'select') return documents.some(d => d.id === action.id) ? { ...state, selectedDocumentId: action.id } : state;
  const event = (kind: DemoEvent['kind'], subject: string): DemoEvent => ({ id: `${action.at}-${kind}-${subject}`, at: action.at, kind, subject });
  if (action.type === 'analyze') {
    if (state.analyses.some(a => a.id === action.id) || state.analyses.length >= 20 || !state.company.name.trim() || !state.company.activity.trim()) return state;
    const doc = documents.find(d => d.id === state.selectedDocumentId)!;
    const analysis: Analysis = { id: action.id, documentId: doc.id, company: { ...state.company }, createdAt: action.at };
    return { ...state, analyses: [...state.analyses, analysis], proposals: [...state.proposals, ...doc.actions.map((title, i): Proposal => ({ id: `${action.id}-${i}`, analysisId: action.id, documentId: doc.id, title: { ...title }, status: 'pending', note: '' }))], events: [...state.events, event('analysis', doc.id)] };
  }
  if (action.type === 'review') {
    const p = state.proposals.find(p => p.id === action.id);
    if (!p || p.status !== 'pending' || (action.decision !== 'approved' && !action.note.trim())) return state;
    const a = state.analyses.find(a => a.id === p.analysisId)!;
    return { ...state, proposals: state.proposals.map(item => item.id === p.id ? { ...item, status: action.decision, note: action.note.trim() } : item), tasks: action.decision === 'approved' ? [...state.tasks, { id: `task-${p.id}`, proposalId: p.id, title: { ...p.title }, department: a.company.department, status: 'todo', evidence: '', due: '' }] : state.tasks, events: [...state.events, event(action.decision === 'approved' ? 'approved' : action.decision === 'rejected' ? 'rejected' : 'changes', p.documentId)] };
  }
  if (action.type === 'edit') {
    const p = state.proposals.find(p => p.id === action.id);
    if (!p || !['pending', 'changes_requested'].includes(p.status) || !action.title.trim()) return state;
    return { ...state, proposals: state.proposals.map(p => p.id === action.id ? { ...p, title: { ...p.title, [action.locale]: action.title.trim() }, status: 'pending', note: '' } : p), events: [...state.events, event('edited', p.documentId)] };
  }
  if (action.type === 'task') {
    const task = state.tasks.find(t => t.id === action.id);
    if (!task || !state.proposals.some(p => p.id === task.proposalId && p.status === 'approved') || (action.status === 'done' && !action.evidence.trim())) return state;
    return { ...state, tasks: state.tasks.map(t => t.id === action.id ? { ...t, status: action.status, evidence: action.evidence.trim(), due: action.due, department: action.department.trim() } : t), events: [...state.events, event('task', task.id)] };
  }
  return state;
}
/** Reject stale/corrupt browser data instead of trusting an arbitrary localStorage object. */
export function parseState(raw: string | null): DemoState {
  if (raw === null) return initialState();
  const s: unknown = JSON.parse(raw);
  const record = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);
  const str = (v: unknown): v is string => typeof v === 'string' && v.length <= 3000;
  const company = (v: unknown): v is Company => record(v) && str(v.name) && str(v.department) && str(v.activity);
  const title = (v: unknown): v is Bilingual => record(v) && str(v.vi) && str(v.en);
  const date = (v: unknown): v is string => str(v) && Number.isFinite(Date.parse(v));
  if (!record(s) || s.version !== 1 || !company(s.company) || !documents.some(d => d.id === s.selectedDocumentId) || !Array.isArray(s.analyses) || !Array.isArray(s.proposals) || !Array.isArray(s.tasks) || !Array.isArray(s.events) || s.analyses.length > 20 || s.proposals.length > 60 || s.tasks.length > 60 || s.events.length > 3000) throw new Error('Invalid prototype data');
  const analyses = s.analyses; const proposals = s.proposals;
  if (!analyses.every(a => record(a) && str(a.id) && documents.some(d => d.id === a.documentId) && company(a.company) && date(a.createdAt))) throw new Error('Invalid analyses');
  if (!proposals.every(p => record(p) && str(p.id) && str(p.analysisId) && analyses.some((a: Analysis) => a.id === p.analysisId && a.documentId === p.documentId) && title(p.title) && ['pending','changes_requested','approved','rejected'].includes(String(p.status)) && str(p.note))) throw new Error('Invalid proposals');
  if (!s.tasks.every(t => record(t) && str(t.id) && str(t.proposalId) && proposals.some((p: Proposal) => p.id === t.proposalId && p.status === 'approved') && title(t.title) && str(t.department) && ['todo','in_progress','awaiting_confirmation','needs_evidence','done'].includes(String(t.status)) && str(t.due) && (t.due === '' || /^\d{4}-\d{2}-\d{2}$/.test(t.due)) && str(t.evidence) && (t.status !== 'done' || t.evidence.trim().length > 0))) throw new Error('Invalid tasks');
  if (!s.events.every(e => record(e) && str(e.id) && str(e.subject) && date(e.at) && ['analysis','approved','changes','rejected','edited','task'].includes(String(e.kind)))) throw new Error('Invalid history');
  for (const rows of [s.analyses, s.proposals, s.tasks]) if (new Set(rows.map(r => r.id)).size !== rows.length) throw new Error('Duplicate ids');
  if (new Set(s.tasks.map(t => t.proposalId)).size !== s.tasks.length) throw new Error('Duplicate task');
  const tasks = s.tasks;
  if (proposals.some(p => p.status === 'approved' && tasks.filter((t: Task) => t.proposalId === p.id).length !== 1)) throw new Error('Approved proposal has no unique task');
  return s as unknown as DemoState;
}
