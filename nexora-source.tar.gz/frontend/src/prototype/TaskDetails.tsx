import EvidencePanel from './EvidencePanel';
import {taskStatusLabels,availableOwners,currentIdentity,taskTone} from './enterprise';
import {useDepartments} from './EnterpriseContext';
import { useEffect, useId, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Badge, Icon, Modal } from './ui';
import { canUpdateTask, demoUsers, ownerName, roleLabels } from './permissions';
import { departments, dueState } from './workflow';
import { priorities } from './workspaces';
import type { WorkspaceState, WorkspaceTask, WorkspaceAction, TaskSnapshot } from './workspaces';
import type { Locale } from './demo';
const statuses=taskStatusLabels;
export default function TaskDetails({state,taskId,locale,today,inline,suspended=false,close,dispatch,openAnalysis,openAssistant,source,saved,unified=false}:{state:WorkspaceState;taskId:string;locale:Locale;today:string;inline:boolean;suspended?:boolean;close:()=>void;dispatch:(action:WorkspaceAction)=>void;openAnalysis:(id:string)=>void;openAssistant:()=>void;source:ReactNode;saved:()=>void;unified?:boolean}) {
 const [wide,setWide]=useState(()=>matchMedia('(min-width: 1280px)').matches);
 const ref=useRef<HTMLElement>(null),titleId=useId();
 const departments=useDepartments();
 const task=state.tasks.find(t=>t.id===taskId)!;
 const originAnalysis=state.analyses.find(a=>a.id===task.analysisId),proposalIndex=state.proposals.filter(p=>p.analysisId===task.analysisId).findIndex(p=>p.id===task.proposalId),originalAction=originAnalysis?.legalPlan?.actions[proposalIndex];
 const t=(vi:string,en:string)=>locale==='vi'?vi:en;
 const editable=currentIdentity(state).id!=='unassigned-head'&&canUpdateTask(state.role,state.department,task.department)&&['todo','in_progress','needs_evidence'].includes(task.status),due=dueState(task,today);
 useEffect(()=>{const m=matchMedia('(min-width: 1280px)'),change=()=>setWide(m.matches);m.addEventListener('change',change);return()=>m.removeEventListener('change',change);},[]);
 useEffect(()=>{if(inline&&wide&&!suspended)ref.current?.focus({preventScroll:true});},[taskId,inline,wide]);
 function clearEvidenceError(form:HTMLFormElement|null){(form?.elements.namedItem('evidence') as HTMLTextAreaElement)?.setCustomValidity('');}
 const history=state.history.filter(h=>h.taskId===task.id).slice(-10).reverse();
 const snapshot=(value:TaskSnapshot)=>`${statuses[value.status][locale]} · ${ownerName(value.owner)||t('Chưa phân công','Unassigned')} · ${value.due||t('Chưa đặt hạn','No target')}`;
 const body=<>
  <h3>{task.title[locale]}</h3><div className="badge-row"><Badge tone={taskTone(task.status)}>{statuses[task.status][locale]}</Badge><Badge>{priorities[task.priority][locale]}</Badge>{due!=='none'&&<Badge tone={due==='overdue'?'danger':'warning'}>{due==='overdue'?t('Quá hạn nội bộ','Overdue internal target'):t('Sắp đến hạn','Due soon')}</Badge>}</div>
  <p className="muted">{departments[task.department][locale]} · {ownerName(task.owner)||t('Chưa phân công','Unassigned')}</p>
  <p><strong>{t('Đầu ra cần bàn giao:','Expected deliverable:')}</strong> {task.expectedEvidence[locale]}</p>
  {originalAction&&<div className="integration-grid"><article><strong>{t('Project Jira dự kiến','Planned Jira project')}</strong><p>{originalAction.jiraProject||t('Chưa chọn','Not selected')}</p><Badge>{t('Chưa gửi ticket','Ticket not sent')}</Badge></article><article><strong>{t('Chịu trách nhiệm kết quả theo bản phân tích (A)','Accountable in analysis (A)')}</strong><p>{ownerName(originalAction.accountable)||t('Chưa xác định','Undetermined')}</p><small>{t('Người thực hiện hiện tại hiển thị ở nhiệm vụ.','Current responsible person is shown on the task.')}</small></article></div>}
  <button className="text-button" onClick={()=>{close();openAnalysis(task.analysisId);}}>{t('Mở phân tích liên quan','Open related analysis')} →</button>
  <button className="text-button" onClick={()=>{close();openAssistant();}}>{t('Hỏi trợ lý về nhiệm vụ này','Ask about this task')} →</button><details className="source-details"><summary>{t('Nguồn nhiệm vụ','Task source')} · {task.documentId}</summary>{source}</details>
  {!editable?<div className="task-readonly"><Badge>{t('Chỉ xem','Read only')}</Badge><p>{task.due||t('Chưa đặt hạn','No target')} · {t('Hạn nội bộ','Internal target')}</p><p>{task.evidence||t('Chưa có ghi chú minh chứng','No evidence note')}</p></div>:<form key={task.id} onSubmit={e=>{
   e.preventDefault();const f=new FormData(e.currentTarget),status=String(f.get('status')) as WorkspaceTask['status'],evidence=String(f.get('evidence')).trim();
   if(status==='done'&&!evidence){const field=e.currentTarget.elements.namedItem('evidence') as HTMLTextAreaElement;field.setCustomValidity(t('Cần ghi chú minh chứng trước khi hoàn tất.','An evidence note is required before completion.'));field.reportValidity();return;}
   dispatch({type:'task',id:task.id,status,evidence,department:task.department,owner:String(f.get('owner')),due:String(f.get('due')),at:new Date().toISOString()});saved();
  }}><div className="form-grid"><label>{t('Trạng thái công việc','Task status')}<select name="status" defaultValue={task.status==='todo'?'todo':'in_progress'} onChange={e=>clearEvidenceError(e.currentTarget.form)}>{Object.entries(statuses).filter(([key])=>['todo','in_progress'].includes(key)).map(([key,label])=><option key={key} value={key}>{label[locale]}</option>)}</select></label>
  <label>{t('Người phụ trách','Owner')}<select name="owner" defaultValue={task.owner}><option value="">{t('Chưa phân công','Unassigned')}</option>{availableOwners(state,task.department).map(u=><option key={u.id} value={u.id}>{u.name}</option>)}</select></label><label>{t('Hạn nội bộ','Internal target')}<input name="due" type="date" defaultValue={task.due}/></label></div>
  <label>{t('Ghi chú minh chứng','Evidence note')}<textarea name="evidence" maxLength={1500} rows={3} defaultValue={task.evidence} onInput={e=>e.currentTarget.setCustomValidity('')}/></label><button className="button primary wide" type="submit">{t('Lưu công việc','Save task')}</button></form>}
  <EvidencePanel unified={unified} key={`${task.id}-${task.status}`} state={unified?{...state,role:task.status==='awaiting_confirmation'?'legal':'department',department:task.department}:state} task={task} locale={locale} dispatch={dispatch}/>
  <section className="task-comments"><h3>{t('Bình luận','Comments')} · {(state.comments||[]).filter(c=>c.taskId===task.id).length}</h3>{(state.comments||[]).filter(c=>c.taskId===task.id).map(c=><article className="comment" key={c.id}><strong>{ownerName(c.actor)}</strong><small>{new Date(c.at).toLocaleString(locale==='vi'?'vi-VN':'en-GB')}</small><p>{c.body}</p></article>)}
   {editable&&<form onSubmit={e=>{e.preventDefault();const form=e.currentTarget,field=form.elements.namedItem('comment') as HTMLTextAreaElement;if(!field.value.trim()){field.setCustomValidity(t('Nhập nội dung bình luận.','Enter a comment.'));field.reportValidity();return;}dispatch({type:'comment',id:crypto.randomUUID(),taskId:task.id,body:field.value,at:new Date().toISOString()});form.reset();}}><label>{t('Thêm bình luận','Add comment')}<textarea name="comment" maxLength={2000} required rows={2} onInput={e=>e.currentTarget.setCustomValidity('')}/></label><button className="button secondary" type="submit">{t('Gửi bình luận','Post comment')}</button></form>}
  </section>
  <details className="history-panel"><summary>{t('Lịch sử công việc','Task history')} · {history.length}</summary>{history.length===0?<p className="fine-print">{t('Chưa có lịch sử cập nhật được ghi nhận.','No task updates recorded yet.')}</p>:history.map(h=><article className="history-row" key={h.id}><div><strong>{ownerName(h.actor)}</strong><small>{roleLabels[h.role][locale]} · {new Date(h.at).toLocaleString(locale==='vi'?'vi-VN':'en-GB')}</small>{h.changes?<><p>{t('Trước:','Before:')} {snapshot(h.changes.before)}</p><p>{t('Sau:','After:')} {snapshot(h.changes.after)}</p>{h.changes.before.evidence!==h.changes.after.evidence&&<p>{t('Minh chứng:','Evidence:')} {h.changes.before.evidence||'—'} → {h.changes.after.evidence||'—'}</p>}</>:<p>{h.note[locale]}</p>}</div></article>)}</details>
 </>;
 if(inline&&(wide||suspended))return <aside className="task-detail-panel" aria-labelledby={titleId} ref={ref} tabIndex={-1} onKeyDown={e=>{if(e.key==='Escape')close();}}><div className="modal-head"><h2 id={titleId}>{t('Chi tiết công việc','Task details')}</h2><button className="icon-button" onClick={close} aria-label={t('Đóng chi tiết','Close details')}><Icon name="close"/></button></div>{body}</aside>;
 return <Modal title={t('Chi tiết công việc','Task details')} close={close}>{body}</Modal>;
}
