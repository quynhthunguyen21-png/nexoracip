/** Demo-only policy. This is not authentication or a backend security boundary. */
import type { Bilingual } from './demo.ts';
import {digitalRoster} from './digitalCompany.ts';
import type { Department } from './workflow.ts';
export type Page = 'overview' | 'documents' | 'analysis' | 'review' | 'tasks' | 'assistant' | 'company' | 'departments' | 'organization';
export type Role = 'legal' | 'department' | 'administrator';
export const corePages:Page[]=['overview','documents','analysis','review','tasks'];
export const pages:Page[]=[...corePages,'assistant','company','departments','organization'];
export const roleLabels: Record<Role, Bilingual> = {
  legal: { vi: 'Chuyên viên pháp chế', en: 'Legal Specialist' },
  department: { vi: 'Trưởng phòng ban', en: 'Department Head' },
  administrator: { vi: 'Giám đốc', en: 'Director' },
};
export const demoUsers = [
  { id: 'minh-anh', name: 'Nguyễn Minh Anh', department: 'legal', role: 'legal', title: {vi:'Người rà soát pháp lý',en:'Legal Reviewer'} },
  { id: 'gia-huy', name: 'Trần Gia Huy', department: 'product', role: 'department', title: {vi:'Phụ trách sản phẩm',en:'Product Owner'} },
  { id: 'hoang-nam', name: 'Lê Hoàng Nam', department: 'engineering', role: 'department', title: {vi:'Trưởng nhóm kỹ thuật',en:'Engineering Lead'} },
  { id: 'khanh-linh', name: 'Phạm Khánh Linh', department: 'data', role: 'department', title: {vi:'Trưởng nhóm Dữ liệu & IT',en:'Data & IT Lead'} },
 ...digitalRoster.map(p=>({...p,role:'department' as const,title:{vi:p.position,en:p.position}})),
] as const;
export const headDepartments = ['engineering', 'product', 'data'] as const;
export const demoPermissions: Record<Role, {pages:Page[]; prepare:boolean; review:boolean; reviewEvidence:boolean; updateTasks:boolean; departmentScoped:boolean; departmentProgress:boolean; reviewQueue:boolean; recentUpdates:boolean}> = {
  // Demo permissions per owner-approved Director workflow; not backend authorization.
  legal: { pages:[...corePages,'assistant'], prepare: true, review: false, reviewEvidence:true, updateTasks: false, departmentScoped: false, departmentProgress: false, reviewQueue: true, recentUpdates: true },
  department: { pages: [...corePages,'assistant'], prepare: false, review: false, reviewEvidence:false, updateTasks: true, departmentScoped: true, departmentProgress: false, reviewQueue: false, recentUpdates: true },
  administrator: { pages, prepare: false, review: true, reviewEvidence:false, updateTasks: false, departmentScoped: false, departmentProgress: true, reviewQueue: true, recentUpdates: true },
};
export function identity(role:Role, department:Department) {
  if(role==='administrator') return { id:'enterprise-admin', name:'Nexora Admin', department:'unassigned' as Department };
  return role==='legal' ? demoUsers[0] : (demoUsers.find(u=>u.role==='department'&&u.department===department)||demoUsers[2]);
}
export function ownerName(id:string) { if(id==='enterprise-admin')return 'Nexora Admin';return demoUsers.find(u=>u.id===id)?.name || id; }
export function canReview(role:Role, department:Department) {
  return demoPermissions[role].review && identity(role,department).id==='enterprise-admin';
}
export function validOwner(id:string, department:Department) { return id==='' || demoUsers.some(u=>u.id===id&&u.department===department); }
export function canUpdateTask(role:Role, department:Department, taskDepartment:Department) {
  return demoPermissions[role].updateTasks && department===taskDepartment;
}

export function canReviewEvidence(role:Role,department:Department){return demoPermissions[role].reviewEvidence&&identity(role,department).id==='minh-anh';}

/** Primary navigation only. Contextual records remain governed by scope and reducer checks. */
export function workspaceNavigation(role:Role,consulting=false):Page[]{
 const desired:Page[]=role==='legal'?[...corePages,'assistant']:role==='administrator'?['overview','review','tasks','assistant']:['overview',...(consulting?['review' as Page]:[]),'tasks','assistant'];
 return desired.filter(page=>demoPermissions[role].pages.includes(page));
}
