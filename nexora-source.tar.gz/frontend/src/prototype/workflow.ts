import type {Governance} from './governance.ts';
import type {PlanDraft} from './legalPlan.ts';
import {legalCatalog} from './legalCatalog.ts';
/** Five-screen personal demo only. No legal facts, real AI, auth or database writes. */
import { documents, initialState, parseState, reducer as legacyReducer } from './demo.ts';
import type { Analysis, Bilingual, DemoState, Locale, Proposal, Task } from './demo.ts';
export const WORKFLOW_KEY = 'nexora-cip-five-screen-demo-v2';
export const bi = (vi: string, en: string): Bilingual => ({ vi, en });
export const departments:Record<string,Bilingual> = {
  unassigned: bi('Chưa phân công', 'Unassigned'), legal: bi('Pháp chế / Tuân thủ', 'Legal / Compliance'),
  product: bi('Sản phẩm', 'Product'), engineering: bi('Kỹ thuật / R&D', 'Engineering / R&D'),
  data: bi('Dữ liệu / IT', 'Data / IT'), marketing: bi('Marketing', 'Marketing'),
};
export type Department = string;
export type ReviewStatus = 'draft' | 'pending' | 'changes_requested' | 'approved' | 'rejected';
export const lifecycles = { unknown: bi('Chưa rõ', 'Unknown'), effective: bi('Đang có hiệu lực', 'Effective'), not_yet_effective: bi('Sắp có hiệu lực', 'Not yet effective'), superseded: bi('Đã được thay thế', 'Superseded'), expired: bi('Hết hiệu lực','Expired') };
export const verifications = { pending: bi('Chờ xác minh', 'Pending verification'), verified: bi('Đã xác minh', 'Verified'), unable: bi('Chưa thể xác minh', 'Unable to verify') };
export const updates = documents.map((d, i) => {
 const legal=legalCatalog.find(r=>r.id===d.id);
 return {...d,lifecycle:legal?'unknown' as const:(['unknown','effective','superseded'] as const)[i],verification:legal?'pending' as const:(['pending','verified','unable'] as const)[i],isNew:!legal&&i<2,
 source:legal?bi('Cổng thông tin Chính phủ · Nhóm tiếp nhận thủ công','Government portal · Manually collected'):bi('Kịch bản tổng hợp nội bộ','Internal synthetic scenario'),
 identifier:legal?.identifier||null,issuer:legal?.issuer||null,issueDate:legal?.issued||null,effectiveDate:legal?.effective||null,sourceUrl:legal?.sourceUrl||null,attachmentUrl:legal?.attachmentUrl||null};
});
export const profiles = [
  { id: 'sandbox', name: 'Nexora Sandbox', activity: bi('Cổng dịch vụ giả lập có biểu mẫu đăng ký.', 'Fictional service portal with a registration form.') },
  { id: 'cloud', name: 'Demo Cloud Lab', activity: bi('Ứng dụng giả lập sử dụng nhà cung cấp hạ tầng.', 'Fictional app using an infrastructure supplier.') },
];
const expectedEvidence: Record<string, Bilingual[]> = {
 'SYN-01': [bi('Checklist mẫu liệt kê trường dữ liệu.', 'Sample checklist listing data fields.'),bi('Ghi chú mẫu về mục đích và thông tin còn thiếu.', 'Sample note on purposes and missing information.'),bi('Danh sách câu hỏi để nhóm xác minh.', 'Question list for team verification.')],
 'SYN-02': [bi('Danh sách nhà cung cấp giả định.', 'Fictional supplier inventory.'),bi('Ghi chú về vị trí lưu và thông tin cần xác minh.', 'Note on storage locations and details to verify.'),bi('Checklist câu hỏi hợp đồng mẫu.', 'Sample contract question checklist.')],
 'SYN-03': [bi('Sơ đồ vị trí dữ liệu giả lập.', 'Fictional data-location map.'),bi('Danh sách câu hỏi về lưu giữ.', 'Retention question list.'),bi('Checklist kiểm thử xóa trên dữ liệu tổng hợp.', 'Deletion-test checklist using synthetic data.')],
};
export interface WorkflowAnalysis extends Analysis { legalPlan?:PlanDraft; governance?:Governance; status: ReviewStatus; profileId: string; seeded: boolean; reviewNote: Bilingual; selection?:string[]; reviewChecks?:Record<string,boolean>; companyRevision?:number; enterpriseSnapshot?:unknown }
export interface WorkflowProposal extends Proposal { department: Department; owner: string; due: string; expectedEvidence: Bilingual }
export interface WorkflowTask extends Task { department: Department; owner: string; expectedEvidence: Bilingual; analysisId: string; documentId: string; seeded: boolean }
export interface History { id: string; analysisId: string; kind: 'generated'|'submitted'|'edited'|'approved'|'rejected'|'changes_requested'|'task'|'checklist'|'selection'|'comment'|'governance'; at: string; note: Bilingual; seeded: boolean }
export interface WorkflowState extends DemoState { workflowVersion: 2; analyses: WorkflowAnalysis[]; proposals: WorkflowProposal[]; tasks: WorkflowTask[]; history: History[]; profileId: string }
export function todayKey(date = new Date()): string { return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`; }
export function shiftDay(day: string, offset: number): string { const d = new Date(day+'T00:00:00Z'); d.setUTCDate(d.getUTCDate()+offset); return d.toISOString().slice(0,10); }
export function validDay(day: string): boolean { return day === '' || (/^\d{4}-\d{2}-\d{2}$/.test(day) && Number.isFinite(Date.parse(day)) && new Date(day).toISOString().slice(0,10) === day); }
export function dueState(task: WorkflowTask, today = todayKey()): 'overdue'|'soon'|'none' { return task.status === 'done' || !task.due ? 'none' : task.due < today ? 'overdue' : task.due <= shiftDay(today,7) ? 'soon' : 'none'; }
export type WorkflowAction =
 | { type: 'select'; id: string } | { type: 'profile'; id: string }
 | { type: 'analyze'; id: string; documentId: string; profileId: string; at: string; seeded?: boolean }
 | { type: 'submit'; id: string; at: string }
 | { type: 'decision'; id: string; decision: 'approved'|'rejected'|'changes_requested'; note: string; at: string; seeded?: boolean }
 | { type: 'edit'; id: string; title: string; department: Department; owner: string; due: string; expectedEvidence: string; locale: Locale; at: string }
 | { type: 'task'; id: string; status: Task['status']; evidence: string; department: Department; owner: string; due: string; at: string };
function knownDepartment(s:WorkflowState,id:string){return id in departments||(s as WorkflowState&{enterprise?:{departments:{id:string}[]}}).enterprise?.departments?.some(d=>d.id===id)===true;}
export function workflowReducer(s: WorkflowState, action: WorkflowAction): WorkflowState {
 if (action.type === 'select') return updates.some(d=>d.id===action.id) ? {...s, selectedDocumentId:action.id} : s;
 if (action.type === 'profile') return profiles.some(p=>p.id===action.id) ? {...s,profileId:action.id} : s;
 const history = (analysisId:string,kind:History['kind'],note:Bilingual,seeded=false):History => ({id:`${action.at}-${kind}-${analysisId}-${s.history.length}`,analysisId,kind,at:action.at,note,seeded});
 if (action.type === 'analyze') {
  const profile=profiles.find(p=>p.id===action.profileId); const doc=updates.find(d=>d.id===action.documentId);
  if (!profile||!doc||s.analyses.some(a=>a.id===action.id)||s.analyses.length>=20) return s;
  const base=legacyReducer({...s,selectedDocumentId:doc.id,company:{name:profile.name,department:'product',activity:profile.id}}, {type:'analyze',id:action.id,at:action.at});
  const extras=base.proposals.filter(p=>p.analysisId===action.id).map((p,i):WorkflowProposal=>({...p,department:(['product','data','legal'] as const)[i],owner:'',due:'',expectedEvidence:{...expectedEvidence[doc.id][i]}}));
  const analysis:WorkflowAnalysis={...base.analyses.at(-1)!,status:'draft',profileId:profile.id,seeded:!!action.seeded,reviewNote:bi('','')};
  return {...s,analyses:[...s.analyses,analysis],proposals:[...s.proposals,...extras],history:[...s.history,history(analysis.id,'generated',bi('Tạo đầu ra AI mô phỏng; chưa gửi duyệt.', 'Generated simulated AI output; not submitted.'),!!action.seeded)]};
 }
 if(action.type==='submit') {
  const a=s.analyses.find(a=>a.id===action.id); if(!a||!['draft','changes_requested'].includes(a.status))return s;
  return {...s,analyses:s.analyses.map(a=>a.id===action.id?{...a,status:'pending'}:a),proposals:s.proposals.map(p=>p.analysisId===action.id?{...p,status:'pending'}:p),history:[...s.history,history(a.id,'submitted',bi('Gửi để con người xem xét trong demo.', 'Submitted for human review in the demo.'),a.seeded)]};
 }
 if(action.type==='decision') {
  const a=s.analyses.find(a=>a.id===action.id); if(!a||a.status!=='pending'||(action.decision!=='approved'&&!action.note.trim()))return s;
  const all=s.proposals.filter(p=>p.analysisId===a.id);const ps=a.selection===undefined?all:all.filter(p=>a.selection!.includes(p.id));if(!ps.length)return s;
  const tasks:WorkflowTask[]=action.decision==='approved'?ps.map(p=>({id:`task-${p.id}`,proposalId:p.id,title:{...p.title},department:p.department,owner:p.owner,due:p.due,expectedEvidence:{...p.expectedEvidence},status:'todo',evidence:'',analysisId:a.id,documentId:a.documentId,seeded:!!action.seeded})):[];
  return {...s,analyses:s.analyses.map(a=>a.id===action.id?{...a,status:action.decision,reviewNote:bi(action.note.trim(),action.note.trim())}:a),proposals:s.proposals.map(p=>ps.some(chosen=>chosen.id===p.id)?{...p,status:action.decision,note:action.note.trim()}:p),tasks:[...s.tasks,...tasks],history:[...s.history,history(a.id,action.decision,bi(action.note.trim(),action.note.trim()),!!action.seeded)]};
 }
 if(action.type==='edit') {
  const p=s.proposals.find(p=>p.id===action.id);const a=p&&s.analyses.find(a=>a.id===p.analysisId);
  if(!p||!a||['approved','rejected'].includes(a.status)||!action.title.trim()||!action.expectedEvidence.trim()||!validDay(action.due)||!knownDepartment(s,action.department))return s;
  return {...s,analyses:s.analyses.map(x=>x.id===a.id?{...x,status:'draft'}:x),proposals:s.proposals.map(x=>x.analysisId===a.id?{...x,status:'pending',...(x.id===p.id?{title:{...x.title,[action.locale]:action.title.trim()},department:action.department,owner:action.owner.trim(),due:action.due,expectedEvidence:{...x.expectedEvidence,[action.locale]:action.expectedEvidence.trim()}}:{})}:x),history:[...s.history,history(a.id,'edited',bi('Đã chỉnh sửa đề xuất; cần gửi duyệt lại.', 'Proposal edited; resubmission required.'))]};
 }
 if(action.type==='task') {
  const task=s.tasks.find(t=>t.id===action.id);if(!task||!s.analyses.some(a=>a.id===task.analysisId&&a.status==='approved')||!['todo','in_progress','awaiting_confirmation','needs_evidence','done'].includes(action.status)||(action.status==='done'&&!action.evidence.trim())||!validDay(action.due)||!knownDepartment(s,action.department))return s;
  return {...s,tasks:s.tasks.map(t=>t.id===task.id?{...t,status:action.status,evidence:action.evidence.trim(),department:action.department,owner:action.owner.trim(),due:action.due}:t),history:[...s.history,history(task.analysisId,'task',bi('Cập nhật công việc demo; không phải kết luận tuân thủ.', 'Demo task updated; not a compliance conclusion.'))]};
 }
 return s;
}
export function initialWorkflow(day=todayKey()):WorkflowState {
 let s:WorkflowState={...initialState(),workflowVersion:2,profileId:'sandbox',analyses:[],proposals:[],tasks:[],history:[]};
 s=workflowReducer(s,{type:'analyze',id:'SEED-APPROVED',documentId:'SYN-02',profileId:'cloud',at:shiftDay(day,-3)+'T09:00:00Z',seeded:true});
 s=workflowReducer(s,{type:'submit',id:'SEED-APPROVED',at:shiftDay(day,-3)+'T09:05:00Z'});
 s=workflowReducer(s,{type:'decision',id:'SEED-APPROVED',decision:'approved',note:'',at:shiftDay(day,-3)+'T09:10:00Z',seeded:true});
 s={...s,tasks:s.tasks.map((t,i)=>({...t,status:(['in_progress','todo','done'] as const)[i],due:shiftDay(day,[-2,3,-1][i]),owner:i===1?'':`DEMO-${i+1}`,evidence:i===2?'SYN-EVIDENCE-PRESET-01':''}))};
 s=workflowReducer(s,{type:'analyze',id:'SEED-PENDING',documentId:'SYN-01',profileId:'sandbox',at:shiftDay(day,-1)+'T09:00:00Z',seeded:true});
 return workflowReducer(s,{type:'submit',id:'SEED-PENDING',at:shiftDay(day,-1)+'T09:05:00Z'});
}
export function parseWorkflow(raw:string|null):WorkflowState {
 if(raw===null)return initialWorkflow();
 const value:unknown=JSON.parse(raw);parseState(raw);
 const s=value as WorkflowState;const str=(x:unknown):x is string=>typeof x==='string'&&x.length<=3000;
 const bilingual=(x:unknown):x is Bilingual=>!!x&&typeof x==='object'&&str((x as Bilingual).vi)&&str((x as Bilingual).en);
 if(s.workflowVersion!==2||!profiles.some(p=>p.id===s.profileId)||!Array.isArray(s.history)||s.history.length>3000)throw new Error('Invalid workflow');
 for(const a of s.analyses)if(!['draft','pending','changes_requested','approved','rejected'].includes(a.status)||!profiles.some(p=>p.id===a.profileId)||typeof a.seeded!=='boolean'||!bilingual(a.reviewNote))throw new Error('Invalid analysis state');
 for(const p of s.proposals)if(!knownDepartment(s,p.department)||!str(p.owner)||!validDay(p.due)||!bilingual(p.expectedEvidence))throw new Error('Invalid proposal details');
 for(const a of s.analyses){
  const ps=s.proposals.filter(p=>p.analysisId===a.id);
  if(a.selection!==undefined&&(!Array.isArray(a.selection)||new Set(a.selection).size!==a.selection.length||a.selection.some(id=>!ps.some(p=>p.id===id))))throw new Error('Invalid proposal selection');
  if(ps.length!==(a.legalPlan?.actions.length??3)||(['pending','approved'].includes(a.status)&&a.selection?.length===0)||ps.some(p=>p.status!==((a.selection===undefined||a.selection.includes(p.id))&&!['draft','pending'].includes(a.status)&&!(a.governance&&a.status==='approved'&&a.governance.stage!=='deployed')?a.status:'pending')))throw new Error('Inconsistent review state');
 }
 for(const t of s.tasks)if(!s.analyses.some(a=>a.id===t.analysisId&&a.status==='approved'&&a.documentId===t.documentId)||!s.proposals.some(p=>p.id===t.proposalId&&p.analysisId===t.analysisId)||!knownDepartment(s,t.department)||!str(t.owner)||!validDay(t.due)||!bilingual(t.expectedEvidence)||typeof t.seeded!=='boolean')throw new Error('Invalid task details');
 if(!s.history.every(h=>str(h.id)&&str(h.at)&&Number.isFinite(Date.parse(h.at))&&s.analyses.some(a=>a.id===h.analysisId)&&['generated','submitted','edited','approved','rejected','changes_requested','task','checklist','selection','comment','governance'].includes(h.kind)&&bilingual(h.note)&&typeof h.seeded==='boolean'))throw new Error('Invalid review history');
 return s;
}
export function metrics(s:WorkflowState,today=todayKey()) {return {updates:updates.filter(d=>d.isNew).length,pending:s.analyses.filter(a=>a.status==='pending').length,soon:s.tasks.filter(t=>dueState(t,today)==='soon').length,overdue:s.tasks.filter(t=>dueState(t,today)==='overdue').length,completed:s.tasks.filter(t=>t.status==='done').length};}
