/** Browser-only draft notes and file metadata. File bytes are never uploaded or persisted. */
export const MAX_REVIEW_FILES=5;
export const MAX_REVIEW_FILE_SIZE=10*1024*1024;
export interface ReviewAttachment {id:string;name:string;size:number;type:string}
export interface ReviewDraft {note:string;files:ReviewAttachment[]}
export const emptyReviewDraft:ReviewDraft={note:'',files:[]};
export function validReviewDraft(value:unknown):value is ReviewDraft {
 if(!value||typeof value!=='object'||Array.isArray(value))return false;
 const d=value as ReviewDraft;
 return Object.keys(d).every(k=>['note','files'].includes(k))&&typeof d.note==='string'&&d.note.length<=1000&&Array.isArray(d.files)&&d.files.length<=MAX_REVIEW_FILES
  &&new Set(d.files.map(f=>f?.id)).size===d.files.length
  &&new Set(d.files.map(f=>`${f?.name}|${f?.size}|${f?.type}`)).size===d.files.length
  &&d.files.every(f=>f&&Object.keys(f).every(k=>['id','name','size','type'].includes(k))&&typeof f.id==='string'&&f.id.length>0&&f.id.length<=100&&typeof f.name==='string'&&f.name.length>0&&f.name.length<=200&&!/[\\/\x00-\x1F]/.test(f.name)&&/\.(pdf|txt)$/i.test(f.name)&&Number.isInteger(f.size)&&f.size>0&&f.size<=MAX_REVIEW_FILE_SIZE&&['application/pdf','text/plain',''].includes(f.type)&&(f.type===''||f.type===(/\.pdf$/i.test(f.name)?'application/pdf':'text/plain')));
}
