import {scope} from './workspaces.ts';
import type {WorkspaceState} from './workspaces.ts';
import {enterprise,departmentLabels,taskStatusLabels} from './enterprise.ts';
import {dueState,todayKey} from './workflow.ts';
import {ownerName} from './permissions.ts';
import type {Locale} from './demo.ts';
export function progressReport(state:WorkspaceState,locale:Locale,at=new Date().toISOString()){
 const rows=scope(state),teams=departmentLabels(state),tasks=rows.tasks,day=todayKey(new Date(at));
 return {title:locale==='vi'?'Báo cáo tiến độ thực hiện':'Execution progress report',company:enterprise(state).profile.name,generatedAt:at,companyRevision:enterprise(state).profile.revision,scope:state.role==='department'?teams[state.department][locale]:'organization',storage:'browser_local',jiraConnected:false,
  totals:{tasks:tasks.length,done:tasks.filter(t=>t.status==='done').length,overdue:tasks.filter(t=>dueState(t,day)==='overdue').length,awaitingEvidenceReview:tasks.filter(t=>t.status==='awaiting_confirmation').length},
  departments:Object.entries(teams).map(([id,label])=>{const own=tasks.filter(t=>t.department===id);return {id,name:label[locale],total:own.length,done:own.filter(t=>t.status==='done').length,overdue:own.filter(t=>dueState(t,day)==='overdue').length};}).filter(d=>d.total),
  tasks:tasks.map(t=>({id:t.id,title:t.title[locale],department:teams[t.department][locale],owner:ownerName(t.owner),due:t.due||null,status:taskStatusLabels[t.status][locale],evidence:t.evidence,reviewedBy:t.submissions?.at(-1)?.reviewedBy||null,reviewedAt:t.submissions?.at(-1)?.reviewedAt||null})),
  limitations:locale==='vi'?['Tỷ lệ hoàn thành nhiệm vụ không phải tỷ lệ tuân thủ pháp luật.','Chưa có kết nối Jira; dữ liệu chỉ lưu trong trình duyệt.','Nguồn pháp lý và phạm vi áp dụng cần được xác minh.']:['Task completion is not legal compliance.','Jira is not connected; records are browser-local.','Legal sources and applicability require verification.']};
}
export function contractDraft(input:{company:string;partner:string;scope:string;value:string;data:string;ip:string;notes:string}){
 return `BẢN NHÁP LÀM VIỆC — CHƯA ĐƯỢC PHÊ DUYỆT\n\nBên cung cấp: ${input.company}\nĐối tác: ${input.partner.trim()||'[Chưa cung cấp]'}\n\n1. PHẠM VI DỊCH VỤ\n${input.scope.trim()||'[Cần thống nhất phạm vi và tiêu chí nghiệm thu]'}\n\n2. GIÁ TRỊ VÀ THANH TOÁN\n${input.value.trim()||'[Cần thống nhất giá, thuế, tiến độ và điều kiện thanh toán]'}\n\n3. DỮ LIỆU VÀ BẢO MẬT — NỘI DUNG CẦN THƯƠNG LƯỢNG\n${input.data.trim()||'[Cần xác định vai trò xử lý dữ liệu, mục đích, phạm vi, bên nhận, thời gian lưu, bảo mật và xử lý sự cố]'}\n\n4. SỞ HỮU TRÍ TUỆ — NỘI DUNG CẦN THƯƠNG LƯỢNG\n${input.ip.trim()||'[Cần xác định quyền với mã nguồn, tài sản có sẵn, thư viện bên thứ ba, quyền sử dụng và điều kiện bàn giao]'}\n\n5. VẤN ĐỀ CHƯA CHỐT\n${input.notes.trim()||'[Nghiệm thu, SLA, trách nhiệm, chấm dứt, giải quyết tranh chấp và điều khoản khác cần rà soát]'}\n\nNguồn tạo: biểu mẫu do người dùng điền; không phải kết quả AI. Chưa đối chiếu với văn bản pháp luật hoặc mẫu hợp đồng đã được chuyên gia xác nhận. Không sử dụng như hợp đồng đã hoàn chỉnh.`;
}
