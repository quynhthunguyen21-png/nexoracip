import {govern,newGovernance,validGovernance,canPrepareAnalysis,canDirectorApprove} from './governance.ts';
import {createLegalPlan,validPlan} from './legalPlan.ts';
import type {PlanDraft} from './legalPlan.ts';
import {digitalProfile,digitalDepartments} from './digitalCompany.ts';
import type {GovernanceAction} from './governance.ts';
import { isDigitalCompany,enterprise,initialEnterprise,validEnterprise,validProfile,validDepartments,currentIdentity,validOwnerFor,departmentLabels } from './enterprise.ts';
import type { Enterprise,CompanyProfile,DepartmentRecord } from './enterprise.ts';
import {applyEvidence,validSubmissions} from './evidence.ts';
import type {EvidenceAction,EvidenceSubmission} from './evidence.ts';
/** Shared browser state for the three workspaces. All names/records are synthetic. */
import { initialWorkflow, parseWorkflow, workflowReducer, shiftDay, todayKey, updates, bi, departments } from './workflow.ts';
import type { WorkflowState, WorkflowAction, WorkflowTask, WorkflowProposal, History, Department } from './workflow.ts';
import { demoPermissions, demoUsers, headDepartments, identity, validOwner, canUpdateTask, canReview } from './permissions.ts';
import { readyForApproval, selectedProposals, reviewItems } from './review.ts';
import type { ReviewItem } from './review.ts';
import type { Role } from './permissions.ts';
import { validReviewDraft } from './reviewDrafts.ts';
import type { ReviewDraft } from './reviewDrafts.ts';
export const WORKSPACE_KEY = 'nexora-cip-role-workspaces-v3';
export const organization = { name:'Nexora Technology', activity:bi('Phát triển phần mềm web/mobile, hệ thống doanh nghiệp, dữ liệu và AI.', 'Custom web/mobile software, enterprise systems, data and AI.') };
export const departmentRationale:Record<Department,ReturnType<typeof bi>> = {
 legal:bi('Cần kiểm tra nguồn, phạm vi áp dụng và các câu hỏi pháp lý còn thiếu.','Source, applicability and unresolved legal questions need review.'),
 engineering:bi('Cần đối chiếu biểu mẫu và luồng xử lý trong ứng dụng mẫu.','Sample application forms and processing flows need inspection.'),
 data:bi('Cần làm rõ vị trí lưu, quyền truy cập và vòng đời dữ liệu giả định.','Assumed storage, access and data lifecycle need clarification.'),
 product:bi('Cần rà soát yêu cầu và trải nghiệm người dùng của sản phẩm mẫu.','Sample product requirements and user journeys need review.'),
 marketing:bi('Cần xác nhận có hoạt động truyền thông liên quan hay không.','Whether relevant communication activities exist needs confirmation.'),
 unassigned:bi('Chưa xác định bộ phận phù hợp.','The responsible department is not determined.'),
};
export const priorities = { high:bi('Cao','High'), medium:bi('Trung bình','Medium'), low:bi('Thấp','Low') };
export const activityLabels = {
 generated:bi('Tạo phân tích mô phỏng.','Generated simulated analysis.'),
 submitted:bi('Gửi hồ sơ xem xét.','Submitted analysis for review.'),
 edited:bi('Cập nhật đề xuất; cần duyệt lại.','Updated proposal; review required.'),
 task:bi('Cập nhật tiến độ và ghi chú minh chứng.','Updated task progress and evidence note.'),
 checklist:bi('Cập nhật checklist rà soát.','Updated review checklist.'),
 selection:bi('Thay đổi đề xuất được chọn; cần gửi lại.','Changed proposal selection; resubmission required.'),
 comment:bi('Thêm bình luận vào công việc.','Added a task comment.'),
};
export type Priority = keyof typeof priorities;
export type WorkspaceProposal = WorkflowProposal & { priority:Priority };
export type WorkspaceTask = WorkflowTask & { priority:Priority; submissions?:EvidenceSubmission[] };
export type TaskSnapshot = Pick<WorkspaceTask,'status'|'owner'|'due'|'evidence'>;
export type Activity = History & { actor:string; role:Role; session?:'unified'; taskId?:string; changes?:{before:TaskSnapshot;after:TaskSnapshot} };
export interface TaskComment {id:string; taskId:string; body:string; actor:string; role:Role; at:string}
export interface WorkspaceState extends WorkflowState {
  enterprise?:Enterprise; assistant?:Record<string,{draft:string;messages:{id:string;question:string;answer:string;recordId:string;at:string}[]}>; workspaceVersion:1; role:Role; department:Department; comments?:TaskComment[]; reviewDrafts?:Record<string,ReviewDraft>;
  proposals:WorkspaceProposal[]; tasks:WorkspaceTask[]; history:Activity[];
}
export type WorkspaceAction = WorkflowAction | EvidenceAction | GovernanceAction
 | {type:'legalPlan';id:string;at:string;plan:PlanDraft}
 | {type:'adoptDigital';at:string}
 | {type:'enterpriseProfile';profile:CompanyProfile;at:string}
 | {type:'enterpriseDepartment';departmentRecord:DepartmentRecord;at:string}
 | {type:'assistantDraft';text:string}
 | {type:'assistantReply';id:string;question:string;answer:string;recordId:string;at:string}
 | {type:'reviewDraft';id:string;draft:ReviewDraft}
 | {type:'selection'; id:string; proposalId:string; selected:boolean; at:string}
 | {type:'checklist'; id:string; item:ReviewItem; checked:boolean; at:string}
 | {type:'comment'; id:string; taskId:string; body:string; at:string}
 | { type:'role'; role:Role }
 | { type:'department'; department:Department }
 | { type:'proposal'; id:string; title:string; department:Department; owner:string; due:string; expectedEvidence:string; priority:Priority; locale:'vi'|'en'; at:string };
export function scope(s:WorkspaceState) {
  const policy=demoPermissions[s.role];
  const tasks=policy.departmentScoped?s.tasks.filter(t=>t.department===s.department):s.tasks;
  const analyses=policy.departmentScoped?s.analyses.filter(a=>tasks.some(t=>t.analysisId===a.id)||a.governance?.stage==='consulting'&&a.governance.consultationDepartments.includes(s.department)):s.analyses;
  const documents=policy.departmentScoped?updates.filter(d=>analyses.some(a=>a.documentId===d.id)):isDigitalCompany(s)?updates.filter(d=>d.id.startsWith('L')||analyses.some(a=>a.documentId===d.id)):updates;
  return {tasks,analyses,documents,history:s.history.filter(h=>analyses.some(a=>a.id===h.analysisId)&&(!policy.departmentScoped||!h.taskId||tasks.some(t=>t.id===h.taskId)))};
}
function apply(s:WorkspaceState, action:WorkflowAction, actor:string, role:Role):WorkspaceState {
  const next=workflowReducer(s,action); if(next===s)return s;
  return {...next, workspaceVersion:1, role:s.role, department:s.department,
    proposals:next.proposals.map(p=>({...p,priority:s.proposals.find(x=>x.id===p.id)?.priority||'medium'})),
    tasks:next.tasks.map(t=>({...t,priority:s.tasks.find(x=>x.id===t.id)?.priority||s.proposals.find(p=>p.id===t.proposalId)?.priority||'medium'})),
    history:next.history.map((h,i)=>i<s.history.length?s.history[i]:{...h,actor,role,...(action.type==='task'?{taskId:action.id}:{})}),
  };
}
export function canApproveAnalysis(s:WorkspaceState,a:WorkspaceState['analyses'][number]){return canDirectorApprove(s,a);}
export function workspaceReducer(s:WorkspaceState, action:WorkspaceAction):WorkspaceState {
  const policy=demoPermissions[s.role];
  if(action.type==='legalPlan')return createLegalPlan(s,action.id,action.at,action.plan);
  if(action.type==='adoptDigital'){
    if(s.role!=='administrator'||!Number.isFinite(Date.parse(action.at)))return s;
    const old=enterprise(s),departments=[...old.departments.map(d=>digitalDepartments.find(n=>n.id===d.id)||d),...digitalDepartments.filter(n=>!old.departments.some(d=>d.id===n.id))];
    return {...s,enterprise:{profile:{...digitalProfile,revision:old.profile.revision+1,updatedAt:action.at},departments,history:[...old.history,{at:action.at,actor:'enterprise-admin',action:'profile',subject:digitalProfile.name}]}};
  }
  if(action.type==='role') {
    if(!Object.hasOwn(demoPermissions,action.role)||s.role===action.role)return s;
    return {...s,role:action.role};
  }
  if(action.type==='department')return policy.departmentScoped&&enterprise(s).departments.some(d=>d.id===action.department&&d.headId)?{...s,department:action.department}:s;
  if(action.type==='select')return scope(s).documents.some(d=>d.id===action.id)?{...s,selectedDocumentId:action.id}:s;
  if(action.type==='profile')return s;
  if(['governanceConfig','consultationStart','consultationRespond','consultationClose','consultationWithdraw','release','deploy','submit','decision'].includes(action.type))return govern(s,action as GovernanceAction|Extract<WorkflowAction,{type:'submit'|'decision'}>);
  const actor=currentIdentity(s);
  const event=(analysisId:string,kind:Activity['kind'],note:Activity['note'],taskId?:string):Activity=>({id:`${'at' in action?action.at:''}-${kind}-${s.history.length}`,analysisId,kind,note,at:'at' in action?action.at:'',actor:actor.id,role:s.role,seeded:false,...(taskId?{taskId}:{})});
  if(action.type==='enterpriseProfile'||action.type==='enterpriseDepartment'){
    if(s.role!=='administrator'||!Number.isFinite(Date.parse(action.at)))return s;
    const e=enterprise(s);let next:Enterprise;
    if(action.type==='enterpriseProfile'){
      const profile={...action.profile,revision:e.profile.revision+1,updatedAt:action.at,origin:'user_input' as const};if(!validProfile(profile))return s;
      next={...e,profile,history:[...e.history,{at:action.at,actor:actor.id,action:'profile',subject:profile.name}]};
    }else{
      const d=action.departmentRecord,rows=e.departments.some(r=>r.id===d.id)?e.departments.map(r=>r.id===d.id?d:r):[...e.departments,d];
      if(!validDepartments(rows)||d.id==='unassigned')return s;
      next={...e,profile:{...e.profile,revision:e.profile.revision+1,updatedAt:action.at,origin:'user_input'},departments:rows,history:[...e.history,{at:action.at,actor:actor.id,action:'department',subject:d.id}]};
    }
    return validEnterprise(next)?{...s,enterprise:next}:s;
  }
  if(action.type==='assistantDraft'||action.type==='assistantReply'){
    const channel=`${s.role}:${s.role==='department'?s.department:'organization'}`,old=s.assistant?.[channel]||{draft:'',messages:[]};
    if(action.type==='assistantDraft')return typeof action.text==='string'&&action.text.length<=1000?{...s,assistant:{...s.assistant,[channel]:{...old,draft:action.text}}}:s;
    if(!action.id||old.messages.some(m=>m.id===action.id)||!action.question.trim()||action.question.length>1000||!action.answer.trim()||action.answer.length>6000||!scope(s).documents.some(d=>d.id===action.recordId)||!Number.isFinite(Date.parse(action.at)))return s;
    return {...s,assistant:{...s.assistant,[channel]:{draft:'',messages:[...old.messages,{id:action.id,question:action.question,answer:action.answer,recordId:action.recordId,at:action.at}].slice(-40)}}};
  }
  if(action.type==='evidenceSubmit'||action.type==='evidenceReview')return applyEvidence(s,action);
  if(action.type==='reviewDraft'){
    const a=s.analyses.find(a=>a.id===action.id);
    if(!a||!(canPrepareAnalysis(s,a)||canReview(s.role,s.department)&&a.status==='pending')||!validReviewDraft(action.draft))return s;
    return {...s,reviewDrafts:{...s.reviewDrafts,[a.id]:{note:action.draft.note,files:action.draft.files.map(f=>({...f}))}}};
  }
  if(action.type==='selection'){
    const a=s.analyses.find(a=>a.id===action.id),p=s.proposals.find(p=>p.id===action.proposalId&&p.analysisId===action.id);
    if(!a||!p||!canPrepareAnalysis(s,a))return s;
    const chosen=selectedProposals(a,s.proposals).map(p=>p.id);
    const selection=action.selected?[...new Set([...chosen,p.id])]:chosen.filter(id=>id!==p.id);
    if(JSON.stringify(chosen)===JSON.stringify(selection))return s;
    return {...s,analyses:s.analyses.map(x=>x.id===a.id?{...x,status:'draft',selection,reviewChecks:{},governance:{...newGovernance(),procedure:x.governance?.procedure||'unspecified',procedureNote:x.governance?.procedureNote||'',resources:x.governance?.resources||''}}:x),proposals:s.proposals.map(p=>p.analysisId===a.id?{...p,status:'pending'}:p),history:[...s.history,event(a.id,'selection',activityLabels.selection)]};
  }
  if(action.type==='checklist'){
    const a=s.analyses.find(a=>a.id===action.id);
    if(!canReview(s.role,s.department)||!a||a.status!=='pending'||!reviewItems.some(i=>i.id===action.item)||typeof action.checked!=='boolean'||a.reviewChecks?.[action.item]===action.checked)return s;
    return {...s,analyses:s.analyses.map(x=>x.id===a.id?{...x,reviewChecks:{...x.reviewChecks,[action.item]:action.checked}}:x),history:[...s.history,event(a.id,'checklist',bi(`${reviewItems.find(i=>i.id===action.item)!.label.vi}: ${action.checked?'đã rà soát':'cần rà soát'}`,`${reviewItems.find(i=>i.id===action.item)!.label.en}: ${action.checked?'reviewed':'needs review'}`))]};
  }
  if(action.type==='comment'){
    const task=s.tasks.find(t=>t.id===action.taskId);
    if(!task||!canUpdateTask(s.role,s.department,task.department)||actor.id==='unassigned-head'||!action.body.trim()||action.body.length>2000||(s.comments||[]).some(c=>c.id===action.id))return s;
    return {...s,comments:[...(s.comments||[]),{id:action.id,taskId:task.id,body:action.body.trim(),actor:actor.id,role:s.role,at:action.at}],history:[...s.history,event(task.analysisId,'comment',activityLabels.comment,task.id)]};
  }
  if(action.type==='task') {
    const task=s.tasks.find(t=>t.id===action.id);
    if(!task||!canUpdateTask(s.role,s.department,task.department)||actor.id==='unassigned-head'||!['todo','in_progress','needs_evidence'].includes(task.status)||!['todo','in_progress'].includes(action.status)||action.department!==task.department||!validOwnerFor(s,action.owner,task.department))return s;
  } else if(action.type==='proposal') {
    const a=s.analyses.find(a=>a.id===s.proposals.find(p=>p.id===action.id)?.analysisId);
    if(!a||!canPrepareAnalysis(s,a)||!validOwnerFor(s,action.owner,action.department)||!enterprise(s).departments.some(d=>d.id===action.department&&d.active)||!Object.hasOwn(priorities,action.priority))return s;
    const next=apply(s,{...action,type:'edit'},actor.id,s.role);
    return next===s?s:{...next,analyses:next.analyses.map(a=>a.id===next.proposals.find(p=>p.id===action.id)?.analysisId?{...a,reviewChecks:{},governance:{...newGovernance(),procedure:a.governance?.procedure||'unspecified',procedureNote:a.governance?.procedureNote||'',resources:a.governance?.resources||''}}:a),proposals:next.proposals.map(p=>p.id===action.id?{...p,priority:action.priority}:p)};
  } else if(!policy.prepare||action.type==='edit')return s;
  const next=apply(s,action as WorkflowAction,actor.id,s.role);
  if(action.type==='analyze'&&next!==s) {
    const day=todayKey(new Date(action.at));
    return {...next,analyses:next.analyses.map(a=>a.id===action.id?{...a,governance:newGovernance(),selection:next.proposals.filter(p=>p.analysisId===a.id).map(p=>p.id),reviewChecks:{},companyRevision:enterprise(s).profile.revision,enterpriseSnapshot:{...enterprise(s).profile,departmentSnapshot:enterprise(s).departments.map(d=>({...d,name:{...d.name}}))},company:{...a.company,name:enterprise(s).profile.name,activity:enterprise(s).profile.activity}}:a),proposals:next.proposals.map((p)=>p.analysisId===action.id?{...p,department:(['engineering','data','legal'] as Department[])[Number(p.id.slice(-1))],owner:['hoang-nam','khanh-linh','minh-anh'][Number(p.id.slice(-1))],due:shiftDay(day,7),priority:'medium'}:p)};
  }
  if(next!==s&&action.type==='task'){
    const before=s.tasks.find(t=>t.id===action.id)!,after=next.tasks.find(t=>t.id===action.id)!;
    const snapshot=(t:WorkspaceTask):TaskSnapshot=>({status:t.status,owner:t.owner,due:t.due,evidence:t.evidence});
    return {...next,history:next.history.map((h,i)=>i===next.history.length-1?{...h,changes:{before:snapshot(before),after:snapshot(after)}}:h)};
  }
  return next;
}
export function initialWorkspace(day=todayKey()):WorkspaceState {
  const base=initialWorkflow(day);
  let s:WorkspaceState={...base,workspaceVersion:1,role:'legal',department:'engineering',
    analyses:base.analyses.map(a=>({...a,company:{...a.company,name:organization.name,activity:organization.activity.vi}})),
    proposals:base.proposals.map((p,i)=>({...p,owner:['gia-huy','khanh-linh','minh-anh'][i%3],priority:i%3===0?'high':'medium',due:shiftDay(day,5)})),
    tasks:base.tasks.map((t,i)=>({...t,owner:['gia-huy','khanh-linh','minh-anh'][i],priority:i===0?'high':'medium'})),
    history:base.history.map(h=>({...h,actor:'minh-anh',role:'legal'})),
  };
  for(const [id,documentId,decision,note] of [
    ['SEED-ENGINEERING','SYN-03','approved',bi('Duyệt kế hoạch thử nghiệm nội bộ, chưa kết luận tuân thủ.','Internal test plan accepted; compliance not determined.')],
    ['SEED-RETURNED','SYN-01','changes_requested',bi('Cần thông tin về biểu mẫu và nguồn đã xác minh.','Form details and verified sources are needed.')],
    ['SEED-REJECTED','SYN-03','rejected',bi('Thiếu căn cứ cho phạm vi đề xuất; cần chuẩn bị lại.','The proposed scope lacks support; prepare a new analysis.')],
  ] as const) {
    const at=shiftDay(day,-2)+'T10:00:00Z';
    s=workspaceReducer(s,{type:'analyze',id,documentId,profileId:'sandbox',at,seeded:true});
    s=apply(s,{type:'submit',id,at},'minh-anh','legal');
    // Historical fixture approval predates the checklist; do not invent reviewed checks.
    s=apply(s,{type:'decision',id,decision,note:note.vi,at,seeded:true},'minh-anh','legal');
    s={...s,history:s.history.map(h=>h.analysisId===id&&h.kind===decision?{...h,note}:h),analyses:s.analyses.map(a=>a.id===id?{...a,reviewNote:note}:a)};
  }
  s={...s,tasks:s.tasks.map(t=>t.analysisId==='SEED-ENGINEERING'?{...t,due:shiftDay(day,t.department==='engineering'?2:-1),status:t.department==='engineering'?'todo':'in_progress'}:t),
    history:s.history.map(h=>({...h,seeded:true})),
  };
  // Initial approved record has a documented reviewer and note as well.
  return {...s,
    proposals:s.proposals.map(p=>{const task=s.tasks.find(t=>t.proposalId===p.id);return task?{...p,due:task.due}:p;}),
    analyses:s.analyses.map(({governance,...a})=>a.id==='SEED-APPROVED'?{...a,reviewNote:bi('Kế hoạch mẫu được duyệt để theo dõi nội bộ.','Sample plan accepted for internal tracking.')}:a),
  };
}
export function parseWorkspace(raw:string|null):WorkspaceState {
  if(raw===null)return initialWorkspace();
  const s=JSON.parse(raw) as WorkspaceState;parseWorkflow(raw);
  for(const a of s.analyses)if(a.legalPlan&&(!validPlan(s,a.legalPlan,true)||a.legalPlan.documentId!==a.documentId))throw new Error('Invalid legal plan');
  if(s.enterprise!==undefined&&!validEnterprise(s.enterprise))throw new Error('Invalid enterprise');
  if(s.workspaceVersion!==1||!Object.hasOwn(demoPermissions,s.role)||!enterprise(s).departments.some(d=>d.id===s.department&&(d.headId||s.enterprise?.history.some(h=>h.action==='department'&&h.subject===d.id))))throw new Error('Invalid workspace');
  if(s.reviewDrafts!==undefined&&(!s.reviewDrafts||typeof s.reviewDrafts!=='object'||Array.isArray(s.reviewDrafts)||Object.entries(s.reviewDrafts).some(([id,d])=>!s.analyses.some(a=>a.id===id)||!validReviewDraft(d))))throw new Error('Invalid review draft');
  for(const a of s.analyses)if(!validGovernance(s,a))throw new Error('Invalid governance');
  for(const a of s.analyses)if(a.reviewChecks!==undefined&&(!a.reviewChecks||Array.isArray(a.reviewChecks)||typeof a.reviewChecks!=='object'||Object.entries(a.reviewChecks).some(([key,value])=>!reviewItems.some(i=>i.id===key)||typeof value!=='boolean')))throw new Error('Invalid review checklist');
  if(s.comments!==undefined&&(!Array.isArray(s.comments)||s.comments.length>3000||new Set(s.comments.map(c=>c.id)).size!==s.comments.length||s.comments.some(c=>typeof c.id!=='string'||typeof c.body!=='string'||!c.body.trim()||c.body.length>2000||!s.tasks.some(t=>t.id===c.taskId)||!demoUsers.some(u=>u.id===c.actor&&u.role===c.role)||!Number.isFinite(Date.parse(c.at)))))throw new Error('Invalid task comments');
  for(const p of [...s.proposals,...s.tasks])if(!Object.hasOwn(departmentLabels(s),p.department)||(!validOwnerFor(s,p.owner,p.department)&&!(s.enterprise?.history.some(h=>h.action==='department'&&h.subject===p.department)&&demoUsers.some(u=>u.id===p.owner)))||!Object.hasOwn(priorities,p.priority))throw new Error('Invalid owner/priority');
  if(s.history.some(h=>!Object.hasOwn(demoPermissions,h.role)||!(h.actor==='enterprise-admin'||demoUsers.some(u=>u.id===h.actor))||(h.taskId&&!s.tasks.some(t=>t.id===h.taskId&&t.analysisId===h.analysisId))))throw new Error('Invalid actor history');
  for(const h of s.history)if(h.changes!==undefined){
    const snapshot=(v:TaskSnapshot)=>v&&['todo','in_progress','awaiting_confirmation','needs_evidence','done'].includes(v.status)&&typeof v.owner==='string'&&(v.owner===''||demoUsers.some(u=>u.id===v.owner))&&typeof v.evidence==='string'&&v.evidence.length<=1500&&typeof v.due==='string'&&(v.due===''||/^\d{4}-\d{2}-\d{2}$/.test(v.due)&&Number.isFinite(Date.parse(v.due)));
    if(!h.taskId||!h.changes||!snapshot(h.changes.before)||!snapshot(h.changes.after))throw new Error('Invalid task change history');
  }
  if(s.tasks.some(t=>!validSubmissions(t)))throw new Error('Invalid evidence submissions');
  if(s.assistant!==undefined){if(!s.assistant||Array.isArray(s.assistant)||typeof s.assistant!=='object')throw new Error('Invalid assistant');for(const [channel,c] of Object.entries(s.assistant)){const [role,target]=channel.split(':');if((role==='department'?!enterprise(s).departments.some(d=>d.id===target):target!=='organization')||!/^(legal|department|administrator):[a-z][a-z0-9-]{0,70}$/.test(channel)||!c||typeof c.draft!=='string'||c.draft.length>1000||!Array.isArray(c.messages)||c.messages.length>40||new Set(c.messages.map(m=>m.id)).size!==c.messages.length||c.messages.some(m=>!m||typeof m.id!=='string'||typeof m.question!=='string'||m.question.length>1000||typeof m.answer!=='string'||m.answer.length>6000||!updates.some(d=>d.id===m.recordId)||!Number.isFinite(Date.parse(m.at))))throw new Error('Invalid assistant channel');}}
  for(const a of s.analyses)if(a.companyRevision!==undefined&&(!Number.isInteger(a.companyRevision)||a.companyRevision<1||!a.enterpriseSnapshot||!validProfile(a.enterpriseSnapshot as CompanyProfile)))throw new Error('Invalid company snapshot');
  return s;
}
/** Fresh browser only. Existing stored workspaces are never reset or overwritten. */
export function initialDigitalWorkspace():WorkspaceState {
 const old=initialWorkspace();
 return {...old,company:{name:digitalProfile.name,activity:digitalProfile.activity,department:'legal'},enterprise:{profile:{...digitalProfile},departments:structuredClone(digitalDepartments),history:[]},selectedDocumentId:'L01',analyses:[],proposals:[],tasks:[],history:[],comments:[],assistant:{},reviewDrafts:{}};
}
export function workspaceMetrics(s:WorkspaceState,day=todayKey()) {
  const scoped=scope(s);
  const overdue=scoped.tasks.filter(t=>t.status!=='done'&&t.due&&t.due<day).length;
  const soon=scoped.tasks.filter(t=>t.status!=='done'&&t.due&&t.due>=day&&t.due<=shiftDay(day,7)).length;
  return {...scoped,overdue,soon,completed:scoped.tasks.filter(t=>t.status==='done').length,pending:scoped.analyses.filter(a=>a.status==='pending').length};
}
