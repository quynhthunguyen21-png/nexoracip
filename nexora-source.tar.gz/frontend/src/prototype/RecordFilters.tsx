import type {ReactNode} from 'react';
import type {Locale} from './demo';
/** Presentation only: the caller remains the single owner of filter values. */
export default function RecordFilters({locale,search,primary,advanced,activeCount=0}:{locale:Locale;search:ReactNode;primary:ReactNode;advanced:ReactNode;activeCount?:number}) {
 return <div className="record-filters"><div className="filter-primary">{search}{primary}</div><details className="filter-more"><summary>{locale==='vi'?'Bộ lọc nâng cao':'Advanced filters'}{activeCount>0&&<span className="filter-count">{activeCount}</span>}</summary><div className="filter-fields">{advanced}</div></details></div>;
}
