import {scope} from './workspaces.ts';
import type {WorkspaceState} from './workspaces.ts';
import {enterprise,departmentLabels} from './enterprise.ts';
import {mockAnswer} from './presentation.ts';
import {dueState,todayKey} from './workflow.ts';
import type {Locale} from './demo.ts';
export interface AssistantInput {state:WorkspaceState;recordId:string;taskId?:string;question:string;locale:Locale}
export type AssistantAdapter=(input:AssistantInput,signal:AbortSignal)=>Promise<string>;
export const demoAssistant:AssistantAdapter=async(input,signal)=>{
 await new Promise<void>((resolve,reject)=>{const timer=setTimeout(resolve,350);signal.addEventListener('abort',()=>{clearTimeout(timer);reject(new Error('cancelled'));},{once:true});});
 const records=scope(input.state);if(!records.documents.some(d=>d.id===input.recordId)||!input.question.trim()||input.question.length>1000)throw new Error('Unsupported request');
 const contextTask=records.tasks.find(t=>t.id===input.taskId&&t.documentId===input.recordId);
 if(input.taskId&&!contextTask)throw new Error('Task outside context');
 if(contextTask)return input.locale==='vi'?`Mô phỏng từ nhiệm vụ ${contextTask.id}: ${contextTask.title.vi}.\nMinh chứng dự kiến: ${contextTask.expectedEvidence.vi}. Hạn nội bộ: ${contextTask.due||'chưa đặt'}. Gửi minh chứng chỉ chuyển sang chờ Pháp chế xác nhận, không tự hoàn thành. Nguồn pháp lý chính thức chưa được cung cấp.`:`Simulated from task ${contextTask.id}: ${contextTask.title.en}.\nExpected evidence: ${contextTask.expectedEvidence.en}. Internal target: ${contextTask.due||'not set'}. Submission awaits Legal confirmation; it does not complete the task. Official legal sources are not supplied.`;
 if(/tiến độ|quá hạn|phụ trách|progress|overdue|unassigned/i.test(input.question)){
 const labels=departmentLabels(input.state),tasks=records.tasks,day=todayKey(),latest=records.history.map(h=>h.at).sort().at(-1),rows=Object.keys(labels).filter(id=>tasks.some(t=>t.department===id)).map(id=>{const own=tasks.filter(t=>t.department===id);return `${labels[id][input.locale]}: ${own.filter(t=>t.status==='done').length}/${own.length} ${input.locale==='vi'?'hoàn thành':'completed'}; ${own.filter(t=>dueState(t,day)==='overdue').length} ${input.locale==='vi'?'quá hạn nội bộ':'overdue internal targets'}`;});
 const refs=tasks.filter(t=>dueState(t,day)==='overdue'||!t.owner&&t.status!=='done').map(t=>`${t.id}: ${t.title[input.locale]} (${t.due||'—'})`);
 return (input.locale==='vi'?`Mô phỏng từ state demo trong phạm vi vai trò: ${tasks.length} nhiệm vụ. Ngày đối chiếu: ${day}. Hoạt động gần nhất: ${latest||'chưa ghi nhận'}.\n`:`Simulated from this role's demo state: ${tasks.length} tasks. As of ${day}. Latest activity: ${latest||'not recorded'}.\n`)+rows.join('\n')+'\n'+refs.join('\n')+(input.locale==='vi'?'\nTiến độ không chứng minh doanh nghiệp tuân thủ hay vi phạm pháp luật.':'\nProgress establishes neither legal compliance nor violation.');
 }
 const p=enterprise(input.state).profile,labels=departmentLabels(input.state),tasks=records.tasks.filter(t=>t.documentId===input.recordId),teams=[...new Set(tasks.map(t=>labels[t.department]?.[input.locale]||t.department))];
 return mockAnswer(input.recordId,input.question,input.locale,input.state.proposals.filter(t=>t.documentId===input.recordId&&records.analyses.some(a=>a.id===t.analysisId)).length)+(input.locale==='vi'?`\nNgữ cảnh doanh nghiệp: ${p.name}, phiên bản ${p.revision} (${p.origin==='demo'?'tổng hợp':'người dùng nhập, chưa xác minh'}). Trong phạm vi vai trò có ${tasks.length} nhiệm vụ liên quan; ${tasks.filter(t=>t.status==='awaiting_confirmation').length} chờ xác nhận; ${tasks.filter(t=>t.status==='done').length} hoàn thành. Phòng ban: ${teams.join(', ')||'chưa có nhiệm vụ'}.`:`\nCompany context: ${p.name}, revision ${p.revision} (${p.origin==='demo'?'synthetic':'user supplied, unverified'}). This role can see ${tasks.length} related tasks; ${tasks.filter(t=>t.status==='awaiting_confirmation').length} awaiting confirmation; ${tasks.filter(t=>t.status==='done').length} completed. Departments: ${teams.join(', ')||'no assigned tasks'}.`);
};
export async function assistantResult(adapter:AssistantAdapter,input:AssistantInput,signal:AbortSignal){try{const answer=await adapter(input,signal);if(!answer.trim()||answer.length>6000)throw new Error('Invalid response');return {ok:true as const,answer};}catch{return {ok:false as const,error:input.locale==='vi'?'Không nhận được phản hồi. Nội dung nhập được giữ lại; bạn có thể thử lại.':'No response received. Your draft is preserved; you can retry.'};}}
