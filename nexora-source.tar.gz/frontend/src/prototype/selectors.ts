import {departmentLabels} from './enterprise.ts';
import { dueState, departments, updates } from './workflow.ts';
import type { WorkflowTask } from './workflow.ts';
import { scope } from './workspaces.ts';
import type { WorkspaceState } from './workspaces.ts';
import { remainingChecks } from './review.ts';
import { ownerName } from './permissions.ts';
import type { Bilingual, Locale } from './demo.ts';
export interface DocumentFilters { query:string; field:string; issuer:string; lifecycle:string; verification:string;origin?:string }
export const emptyDocumentFilters:DocumentFilters={query:'',field:'all',issuer:'all',lifecycle:'all',verification:'all'};
export function filterDocuments(documents:typeof updates, filters:DocumentFilters, locale:Locale) {
 const q=filters.query.trim().toLocaleLowerCase();
 return documents.filter(d=>`${d.title[locale]} ${d.id} ${d.identifier||''} ${d.passage[locale]} ${d.category[locale]}`.toLocaleLowerCase().includes(q)
  &&(filters.field==='all'||d.category.vi===filters.field)
  &&(filters.issuer==='all'||filters.issuer==='missing'&&d.issuer===null||d.issuer===filters.issuer)
  &&(filters.lifecycle==='all'||d.lifecycle===filters.lifecycle)
  &&(!filters.origin||filters.origin==='all'||filters.origin==='missing'&&!d.sourceUrl||filters.origin==='official'&&!!d.sourceUrl)
  &&(filters.verification==='all'||d.verification===filters.verification));
}
export function paginate<T>(rows:T[], requested:number, size=6) {
 const pages=Math.max(1,Math.ceil(rows.length/size)), page=Math.min(pages,Math.max(1,requested));
 return {page,pages,rows:rows.slice((page-1)*size,page*size)};
}
export interface TaskFilters {analysis?:string;query:string;status:string;department:string;owner:string;due:string;evidence:string;field?:string}
export const emptyTaskFilters:TaskFilters={query:'',status:'all',department:'all',owner:'all',due:'all',evidence:'all'};
export function filterTasks<T extends WorkflowTask>(tasks:T[],f:TaskFilters,locale:Locale,today:string,labels:Record<string,Bilingual>=departments) {
 return tasks.filter(t=>(!f.analysis||f.analysis==='all'||t.analysisId===f.analysis)&&`${t.title[locale]} ${ownerName(t.owner)} ${labels[t.department]?.[locale]||t.department} ${t.id}`.toLocaleLowerCase().includes(f.query.trim().toLocaleLowerCase())
  &&(!f.field||f.field==='all'||updates.find(d=>d.id===t.documentId)?.category.vi===f.field)
  &&(f.department==='all'||t.department===f.department)
  &&(f.owner==='all'||t.owner===(f.owner==='unassigned'?'':f.owner))
  &&(f.status==='all'||(f.status==='open'?t.status!=='done':t.status===f.status))
  &&(f.due==='all'||(f.due==='undated'?!t.due:dueState(t,today)===f.due))
  &&(f.evidence==='all'||(f.evidence==='missing'?!t.evidence.trim():!!t.evidence.trim())));
}
export function dashboardData(s:WorkspaceState,today:string) {
 const scoped=scope(s),tasks=scoped.tasks;
 const stats={total:tasks.length,todo:tasks.filter(t=>t.status==='todo').length,awaiting:tasks.filter(t=>t.status==='awaiting_confirmation').length,needsEvidence:tasks.filter(t=>t.status==='needs_evidence').length,inProgress:tasks.filter(t=>t.status==='in_progress').length,done:tasks.filter(t=>t.status==='done').length,
  overdue:tasks.filter(t=>dueState(t,today)==='overdue').length,soon:tasks.filter(t=>dueState(t,today)==='soon').length,missingEvidence:tasks.filter(t=>!t.evidence.trim()).length};
 const departmentRows=Object.entries(departmentLabels(s)).filter(([id])=>id!=='unassigned'||tasks.some(t=>t.department===id)).map(([id,label])=>{const own=tasks.filter(t=>t.department===id);return {id,label,total:own.length,done:own.filter(t=>t.status==='done').length,overdue:own.filter(t=>dueState(t,today)==='overdue').length};});
 const pending=scoped.analyses.filter(a=>a.status==='pending');
 return {...scoped,stats,departmentRows,pending,active:scoped.analyses.filter(a=>['draft','pending','changes_requested'].includes(a.status)).length,drafts:scoped.analyses.filter(a=>a.status==='draft').length,
  missingChecks:pending.reduce((sum,a)=>sum+remainingChecks(a),0),documentsNeedingReview:scoped.documents.filter(d=>!d.identifier||!d.issuer).length};
}
/** Header search stays within the same workspace scope as the lists. */
export function quickSearch(s:WorkspaceState,query:string,locale:Locale) {
 const rows=scope(s),q=query.trim().toLocaleLowerCase();
 if(!q)return [];
 return [
  ...rows.documents.filter(d=>`${d.id} ${d.title[locale]}`.toLocaleLowerCase().includes(q)).map(d=>({id:d.id,title:d.title[locale],kind:'document' as const})),
  ...rows.tasks.filter(t=>`${t.id} ${t.title[locale]}`.toLocaleLowerCase().includes(q)).map(t=>({id:t.id,title:t.title[locale],kind:'task' as const})),
 ].slice(0,6);
}
