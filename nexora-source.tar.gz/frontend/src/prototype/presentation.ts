import { shiftDay, validDay, updates } from './workflow.ts';
import type { Locale } from './demo.ts';
import type { WorkspaceState } from './workspaces.ts';
import { scope } from './workspaces.ts';
import { selectedProposals } from './review.ts';
export const lifecycleTones={not_yet_effective:'warning',effective:'success',superseded:'info',unknown:'neutral',expired:'danger'} as const;
export type Period='all'|'week'|'month'|'quarter'|'year'|'last_week'|'last_month'|'last_quarter'|'last_year'|'custom';
export const periodLabels:Record<Period,{vi:string;en:string}>={all:{vi:'Tất cả thời gian',en:'All time'},week:{vi:'Tuần này',en:'This week'},month:{vi:'Tháng này',en:'This month'},quarter:{vi:'Quý này',en:'This quarter'},year:{vi:'Năm này',en:'This year'},last_week:{vi:'Tuần trước',en:'Last week'},last_month:{vi:'Tháng trước',en:'Last month'},last_quarter:{vi:'Quý trước',en:'Last quarter'},last_year:{vi:'Năm trước',en:'Last year'},custom:{vi:'Tùy chỉnh',en:'Custom'}};
export function periodRange(period:Period,today:string,from='',to=''):{from:string;to:string}|null {
 if(!validDay(today)||!today)return null;
 if(period==='all')return {from:'',to:''};
 if(period==='custom')return from&&to&&validDay(from)&&validDay(to)&&from<=to?{from,to}:null;
 const d=new Date(today+'T00:00:00Z'),year=d.getUTCFullYear(),month=d.getUTCMonth();
 const key=(y:number,m:number,day:number)=>new Date(Date.UTC(y,m,day)).toISOString().slice(0,10);
 if(period==='week'||period==='last_week'){const monday=shiftDay(today,-((d.getUTCDay()+6)%7)-(period==='last_week'?7:0));return {from:monday,to:shiftDay(monday,6)};}
 const months=period.includes('quarter')?3:period.includes('year')?12:1;
 const startMonth=months===12?0:months===3?Math.floor(month/3)*3:month;
 const start=startMonth-(period.startsWith('last_')?months:0);
 return {from:key(year,start,1),to:key(year,start+months,0)};
}
export function withinPeriod(date:string,range:ReturnType<typeof periodRange>){return !!range&&!!date&&validDay(date)&&(!range.from||date>=range.from)&&(!range.to||date<=range.to);}
export function dashboardSignals(s:WorkspaceState){const records=scope(s),pending=records.analyses.filter(a=>a.status==='pending');return {newUpdates:records.documents.filter(d=>d.isNew).length,pending:pending.length,highPriority:pending.filter(a=>selectedProposals(a,s.proposals).some(p=>s.proposals.find(row=>row.id===p.id)?.priority==='high')).length};}
export function mockAnswer(documentId:string,question:string,locale:Locale,proposalCount:number){
 const d=updates.find(d=>d.id===documentId);if(!d)return locale==='vi'?'Không có hồ sơ tương ứng.':'No matching record.';
 const vi=locale==='vi';const q=question.toLocaleLowerCase();
 const prefix=vi?`Mô phỏng · ${d.id}. `:`Simulated · ${d.id}. `;
 if(/nguồn|căn cứ|source|legal|hiệu lực|effective/.test(q))return prefix+(vi?'Chưa có URL chính thức, số hiệu, ngày hiệu lực hay điều khoản đã xác minh. Đoạn hiện có chỉ là tình huống tổng hợp; cần nhóm pháp lý cung cấp nguồn.':'Official URL, legal identifier, effective date and verified provisions are missing. The available passage is synthetic; the legal team must supply a source.');
 if(/minh chứng|evidence/.test(q))return prefix+(vi?'Đối chiếu đầu ra mong đợi của từng đề xuất. Ghi chú minh chứng trong demo chưa được xác minh và không chứng minh tuân thủ pháp luật.':'Inspect each proposal’s expected deliverable. Demo evidence notes are unverified and do not prove legal compliance.');
 if(/hạn|deadline|thời gian/.test(q))return prefix+(vi?'Ngày trong đề xuất là mục tiêu nội bộ do người dùng chỉnh sửa, không phải thời hạn pháp lý. Chưa có căn cứ để đặt hạn theo luật.':'Proposal dates are editable internal targets, not legal deadlines. No grounded legal deadline is available.');
 return prefix+(vi?`${d.question.vi} Có ${proposalCount} đề xuất trong hồ sơ này. Đây là gợi ý soạn sẵn để rà soát dữ liệu mẫu; không có mô hình AI được huấn luyện hoặc gọi API thật.`:`${d.question.en} This record contains ${proposalCount} proposals. These are predefined suggestions for sample-data review; no trained AI model or live API is used.`);
}
