import { useEffect, useId, useRef } from 'react';
import type { ReactNode } from 'react';
export function Icon({ name, size = 20 }: { name: string; size?: number }) {
  const paths: Record<string, ReactNode> = {
    overview: <><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></>,
    documents: <><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/></>,
    company: <><path d="M4 21V5l8-2v18M12 9h8v12M2 21h20M7 8h2M7 12h2M7 16h2M15 13h2M15 17h2"/></>,
    analysis: <><path d="m12 3 2.4 6.6L21 12l-6.6 2.4L12 21l-2.4-6.6L3 12l6.6-2.4z"/></>,
    review: <><path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6z"/><path d="m8 12 3 3 5-6"/></>,
    tasks: <><rect x="4" y="5" width="16" height="16" rx="2"/><path d="M9 3h6v4H9zM8 12l1 1 2-2M14 12h3M8 17l1 1 2-2M14 17h3"/></>,
    reports: <><path d="M4 3v18h17M8 16v-4M13 16V8M18 16V5"/></>,
    arrow: <path d="M5 12h14m-5-5 5 5-5 5"/>, check: <path d="m5 12 4 4L19 6"/>,
    alert: <><path d="m12 3 10 18H2zM12 9v5M12 17h.01"/></>,
    info: <><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/></>,
    attachment: <path d="m8 12 7-7a4 4 0 0 1 6 6L10 22a6 6 0 0 1-8-8L13 3a2 2 0 0 1 3 3L5 17"/>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></>,
    moon: <path d="M20 14a8 8 0 0 1-10-10 9 9 0 1 0 10 10z"/>,
    sun: <><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1 1M18 18l1 1M5 19l1-1M18 6l1-1"/></>,
    menu: <path d="M4 6h16M4 12h16M4 18h16"/>, close: <path d="m6 6 12 12M18 6 6 18"/>,
    search: <><circle cx="10" cy="10" r="6"/><path d="m15 15 5 5"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    chevron: <path d="m9 5 7 7-7 7"/>, download: <><path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name] || paths.info}</svg>;
}
export function Modal({ title, children, close }: { title: string; children: ReactNode; close: () => void }) {
  const ref = useRef<HTMLDialogElement>(null); const id = useId();
  useEffect(() => { const d = ref.current; d?.showModal(); return () => { if (d?.open) d.close(); }; }, []);
  return <dialog ref={ref} className="modal" aria-labelledby={id} onCancel={close} onClick={e => { if (e.target === ref.current) close(); }}><div className="modal-head"><h2 id={id}>{title}</h2><button className="icon-button" onClick={close} aria-label="Close / Đóng"><Icon name="close"/></button></div>{children}</dialog>;
}

export function Badge({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'neutral'|'info'|'success'|'warning'|'danger' }) {
  return <span className={`badge ${tone}`}><Icon name={tone === 'success' ? 'check' : tone === 'warning' || tone === 'danger' ? 'alert' : tone === 'info' ? 'info' : 'clock'} size={14}/>{children}</span>;
}
export function Empty({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return <div className="empty"><Icon name="documents" size={30}/><h3>{title}</h3>{children && <p>{children}</p>}{action}</div>;
}
