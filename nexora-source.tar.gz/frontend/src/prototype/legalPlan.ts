import type {WorkspaceState,WorkspaceAction,WorkspaceProposal} from './workspaces.ts';
import {enterprise,validOwnerFor,currentIdentity} from './enterprise.ts';
import {newGovernance} from './governance.ts';
import {legalCatalog} from './legalCatalog.ts';
import {digitalRoster} from './digitalCompany.ts';
export interface PlanAction {title:string;department:string;owner:string;due:string;expectedEvidence:string;priority:'high'|'medium'|'low';rationale:string;accountable:string;jiraProject?:string}
export interface PlanDraft {documentId:string;summary:string;sourceExcerpt:string;missing:string;origin:'human'|'openai'|'gemini'|'rules';reviewReference?:string;actions:PlanAction[]}
export function validPlan(s:WorkspaceState,p:PlanDraft,historical=false):boolean {
 const text=(x:unknown,max:number)=>typeof x==='string'&&x.length<=max;
 if(!p||!Array.isArray(p.actions)||p.actions.some(a=>!a||a.accountable!==''&&!digitalRoster.some(u=>u.id===a.accountable)||a.jiraProject!==undefined&&!['','KAN','NEX-GOV','NEX-BIZ','NEX-PROD'].includes(a.jiraProject)))return false;
 return !!p&&legalCatalog.some(d=>d.id===p.documentId)&&text(p.summary,5000)&&!!p.summary.trim()&&text(p.sourceExcerpt,12000)&&text(p.missing,5000)&&['human','openai','gemini','rules'].includes(p.origin)&&(p.reviewReference===undefined||text(p.reviewReference,300))&&Array.isArray(p.actions)&&p.actions.length>0&&p.actions.length<=8&&p.actions.every(a=>a&&text(a.title,1000)&&!!a.title.trim()&&text(a.expectedEvidence,1000)&&!!a.expectedEvidence.trim()&&text(a.rationale,2000)&&text(a.accountable,100)&&text(a.owner,100)&&text(a.department,80)&&(historical||validOwnerFor(s,a.owner,a.department)&&enterprise(s).departments.some(d=>d.id===a.department&&d.active))&&['high','medium','low'].includes(a.priority)&&text(a.due,10)&&(a.due===''||/^\d{4}-\d{2}-\d{2}$/.test(a.due)&&Number.isFinite(Date.parse(a.due))&&new Date(a.due).toISOString().slice(0,10)===a.due));
}
export function createLegalPlan(s:WorkspaceState,id:string,at:string,p:PlanDraft):WorkspaceState {
 if(s.role!=='legal'||!id||s.analyses.some(a=>a.id===id||p.reviewReference&&a.legalPlan?.reviewReference===p.reviewReference)||s.analyses.length>=20||s.proposals.length+p.actions.length>60||!Number.isFinite(Date.parse(at))||!validPlan(s,p))return s;
 const company=enterprise(s).profile;
 const proposals:WorkspaceProposal[]=p.actions.map((a,i)=>({id:`${id}-${i}`,analysisId:id,documentId:p.documentId,title:{vi:a.title,en:a.title},department:a.department,owner:a.owner,due:a.due,expectedEvidence:{vi:a.expectedEvidence,en:a.expectedEvidence},priority:a.priority,status:'pending',note:''}));
 return {...s,selectedDocumentId:p.documentId,analyses:[...s.analyses,{id,documentId:p.documentId,createdAt:at,company:{name:company.name,activity:company.activity,department:'legal'},profileId:'sandbox',status:'draft',seeded:false,reviewNote:{vi:'',en:''},selection:proposals.map(x=>x.id),reviewChecks:{},governance:newGovernance(),companyRevision:company.revision,enterpriseSnapshot:structuredClone(company),legalPlan:structuredClone(p)}],proposals:[...s.proposals,...proposals],history:[...s.history,{id:`${id}-created`,analysisId:id,kind:'generated',note:{vi:p.origin==='human'?'Lưu bản phân tích do người rà soát chuẩn bị.':p.origin==='rules'?'Lưu đề xuất từ sàng lọc quy tắc để con người rà soát.':'Lưu đầu ra AI để con người xem xét.',en:p.origin==='human'?'Saved human-prepared analysis.':p.origin==='rules'?'Saved rule-screening proposal for human review.':'Saved AI output for human review.'},at,actor:currentIdentity(s).id,role:s.role,seeded:false}]};
}
