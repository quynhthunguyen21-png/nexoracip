import {createContext,useContext} from 'react';
import {departments} from './workflow';
export const DepartmentContext=createContext(departments);
export function useDepartments(){return useContext(DepartmentContext);}
