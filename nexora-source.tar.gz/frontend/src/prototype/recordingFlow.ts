/** Owner-requested recording shortcuts. No AI or Jira writes, no invented review evidence. */
import type {WorkspaceState,WorkspaceAction} from './workspaces.ts';
import {unifiedReducer} from './unified.ts';
import {enterprise} from './enterprise.ts';
import {proposalPhase} from './governance.ts';
import {reviewItems} from './review.ts';
export const COMPANY_NAME='NEXORA TECHNOLOGY';
export const PRIVACY_NOTICE_KEY='nexora-privacy-notice-recording-20261023';
export const RECORDING_SETUP_KEY='nexora-recording-setup-20261023';
export function setupRecording(s:WorkspaceState,at:string){
 let next=s;const p=enterprise(s).profile;
 if(/nexora/i.test(p.name)&&p.name!==COMPANY_NAME)next=unifiedReducer(next,{type:'enterpriseProfile',profile:{...p,name:COMPANY_NAME},at});
 for(const a of next.analyses)if(a.documentId==='L01'&&proposalPhase(a)==='consulting')next=unifiedReducer(next,{type:'consultationWithdraw',id:a.id,at});
 return next;
}
export function submissionActions(s:WorkspaceState,id:string,at:string):WorkspaceAction[]{
 const a=s.analyses.find(a=>a.id===id);if(!a||!['draft','changes_requested'].includes(a.status))return [];
 const actions:WorkspaceAction[]=[];
 if(proposalPhase(a)==='consulting')actions.push({type:'consultationWithdraw',id,at});
 if(!a.governance||a.governance.procedure==='unspecified')actions.push({type:'governanceConfig',id,procedure:'not_required',procedureNote:'Kế hoạch rà soát nội bộ cho buổi trình diễn; không ban hành văn bản pháp lý. Cần người dùng xác nhận trước khi giao việc.',resources:a.governance?.resources||'',at});
 actions.push({type:'submit',id,at});return actions;
}
export function approvalActions(s:WorkspaceState,id:string,at:string):WorkspaceAction[]{
 const a=s.analyses.find(a=>a.id===id);if(!a||a.status!=='pending')return [];
 return [...reviewItems.map(item=>({type:'checklist' as const,id,item:item.id,checked:true,at})),{type:'decision',id,decision:'approved',note:'Người dùng xác nhận duyệt và giao kế hoạch tại popup trình diễn. Giới hạn và thông tin thiếu được giữ nguyên; không xác nhận tuân thủ pháp luật.',at},{type:'release',id,note:'Người dùng xác nhận điều kiện triển khai công việc nội bộ tại popup.',at},{type:'deploy',id,at}];
}
export function previewActions(s:WorkspaceState,actions:WorkspaceAction[]){return actions.reduce(unifiedReducer,s);}
