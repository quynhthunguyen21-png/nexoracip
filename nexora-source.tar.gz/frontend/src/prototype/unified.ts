/** Local presentation adapter. Functional stages are not authenticated identities.
 * Reuses existing transition guards; never approves/releases/deploys implicitly. */
import {legalCatalog} from './legalCatalog.ts';
import {workspaceReducer} from './workspaces.ts';
import type {WorkspaceState,WorkspaceAction} from './workspaces.ts';
export const primaryNavigation=['overview','documents','review','tasks'] as const;
export const utilityNavigation=['assistant','contracts','company'] as const;
export function unifiedReducer(s:WorkspaceState,a:WorkspaceAction):WorkspaceState {
 if(a.type==='role'||a.type==='department')return s;
 let role:WorkspaceState['role']='legal',department=s.department;
 if(['decision','checklist','enterpriseProfile','enterpriseDepartment','adoptDigital'].includes(a.type))role='administrator';
 if(a.type==='reviewDraft'&&s.analyses.find(row=>row.id===a.id)?.status==='pending')role='administrator';
 if(['task','comment','evidenceSubmit'].includes(a.type)){
  const id=a.type==='task'?a.id:'taskId' in a?a.taskId:'';
  const task=s.tasks.find(t=>t.id===id);if(!task)return s;
  role='department';department=task.department;
 }
 const context={...s,role,department},next=workspaceReducer(context,a);
 return next===context?s:{...next,role:s.role,department:s.department,history:next.history.map((h,i)=>i<s.history.length?h:{...h,session:'unified'})};
}
export function unifiedMetrics(s:WorkspaceState,day:string){
 const open=s.tasks.filter(t=>t.status!=='done');
 return {attention:s.analyses.filter(a=>a.status==='pending').length+open.filter(t=>t.status==='awaiting_confirmation'||t.due&&t.due<day).length,documents:legalCatalog.length,plans:s.analyses.filter(a=>['draft','pending','changes_requested'].includes(a.status)).length,pending:s.analyses.filter(a=>a.status==='pending').length,total:s.tasks.length,done:s.tasks.filter(t=>t.status==='done').length,overdue:open.filter(t=>t.due&&t.due<day).length,evidence:s.tasks.filter(t=>t.status==='awaiting_confirmation').length};
}
