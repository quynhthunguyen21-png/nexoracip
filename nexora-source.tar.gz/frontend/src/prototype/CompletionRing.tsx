import type { Locale } from './demo';
export default function CompletionRing({done,total,locale}:{done:number;total:number;locale:Locale}) {
 const percentage=total?Math.round(done/total*100):0;
 return <div className="completion-summary"><div className="completion-ring" role="img" aria-label={`${locale==='vi'?'Hoàn tất công việc':'Task completion'}: ${done}/${total}`}><svg viewBox="0 0 120 120" aria-hidden="true"><circle className="ring-track" cx="60" cy="60" r="50"/><circle className="ring-value" cx="60" cy="60" r="50" pathLength="100" strokeDasharray={`${percentage} ${100-percentage}`} transform="rotate(-90 60 60)"/></svg><strong>{total?`${percentage}%`:'—'}</strong></div><div><h2>{locale==='vi'?'Tiến độ công việc':'Task progress'}</h2><p>{done}/{total} {locale==='vi'?'hoàn tất':'completed'}</p><small>{locale==='vi'?'Chưa có dữ liệu so sánh kỳ trước':'No previous-period comparison data'}</small></div></div>;
}
