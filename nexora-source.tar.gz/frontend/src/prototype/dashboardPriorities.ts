import {proposalPhase} from './governance.ts';
import {scope} from './workspaces.ts';
import type {WorkspaceState} from './workspaces.ts';
import {dueState} from './workflow.ts';
export interface DashboardPriority {kind:'task'|'review'|'analysis'|'document';id:string;reason:'evidence'|'returned'|'overdue'|'plan'|'draft'|'work'|'source'|'consultation'|'release';rank:number}
/** A scoped, derived inbox. It creates no records and changes no workflow state. */
export function dashboardPriorities(state:WorkspaceState,today:string):DashboardPriority[]{
 const scoped=scope(state),items:DashboardPriority[]=[];
 for(const task of scoped.tasks){
  if(task.status==='done')continue;
  const overdue=dueState(task,today)==='overdue';
  if(state.role==='legal'&&task.status==='awaiting_confirmation')items.push({kind:'task',id:task.id,reason:'evidence',rank:0});
  else if(state.role==='department'&&task.status==='needs_evidence')items.push({kind:'task',id:task.id,reason:'returned',rank:0});
  else if(overdue)items.push({kind:'task',id:task.id,reason:'overdue',rank:1});
  else if(state.role==='department'&&task.status!=='awaiting_confirmation')items.push({kind:'task',id:task.id,reason:'work',rank:3});
  else if(state.role==='administrator'&&task.status==='awaiting_confirmation')items.push({kind:'task',id:task.id,reason:'evidence',rank:2});
 }
 for(const a of scoped.analyses){
  if(proposalPhase(a)==='consulting'){items.push({kind:'review',id:a.id,reason:'consultation',rank:2});continue;}
  if(state.role==='legal'&&a.governance&&['approved','awaiting_issuance','ready'].includes(proposalPhase(a)))items.push({kind:'review',id:a.id,reason:'release',rank:1});
  if(a.status==='pending')items.push({kind:'review',id:a.id,reason:'plan',rank:state.role==='administrator'?0:3});
  if(state.role==='legal'&&['draft','changes_requested'].includes(a.status))items.push({kind:'analysis',id:a.id,reason:'draft',rank:3});
 }
 if(state.role==='legal')for(const d of scoped.documents)if(d.verification!=='verified')items.push({kind:'document',id:d.id,reason:'source',rank:4});
 return items.sort((a,b)=>a.rank-b.rank||a.id.localeCompare(b.id));
}
