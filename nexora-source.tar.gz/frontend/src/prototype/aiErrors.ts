import type {Locale} from './demo.ts';
// Only known codes are presented; never echo upstream messages or arbitrary details.
export async function providerError(response:Response,locale:Locale):Promise<string|undefined>{
 try{
  const data=await response.json() as {detail?:{code?:unknown}}|null;
  const code=data?.detail?.code;
  const messages:Record<string,[string,string]>={
   provider_quota:['Gemini đã chạm hạn mức. Kiểm tra quota trong AI Studio và thử lại sau.','Gemini quota was reached. Check AI Studio and retry later.'],
   provider_access_denied:['Gemini từ chối quyền truy cập. Kiểm tra khóa và quyền của project ở backend.','Gemini denied access. Check the private key and project permissions.'],
   provider_model_unavailable:['Model Gemini đang cấu hình không khả dụng cho tài khoản này. Cần cập nhật GEMINI_MODEL và khởi động lại backend.','The configured Gemini model is unavailable to this account. Update GEMINI_MODEL and restart the backend.'],
   provider_unavailable:['Gemini đang quá tải hoặc tạm thời gián đoạn. Backend vẫn hoạt động; hãy thử lại sau.','Gemini is overloaded or temporarily unavailable. The backend is running; retry later.'],
  };
  if(typeof code==='string'&&Object.hasOwn(messages,code))return messages[code][locale==='vi'?0:1];
 }catch{/* HTML/proxy errors have no trusted provider code. */}
 return undefined;
}
