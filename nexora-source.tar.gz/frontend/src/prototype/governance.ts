import type {Bilingual} from './demo.ts';
/** Browser-only proposal governance. No authentication, legal verification or server writes. */
import type {WorkspaceState,WorkspaceTask} from './workspaces.ts';
import type {WorkflowAnalysis} from './workflow.ts';
import {bi,validDay} from './workflow.ts';
import {currentIdentity,enterprise,validOwnerFor} from './enterprise.ts';
import {canReview,demoPermissions} from './permissions.ts';
import {readyForApproval,selectedProposals} from './review.ts';
export type Procedure='unspecified'|'not_required'|'required';
export type Phase='draft'|'consulting'|'pending'|'changes_requested'|'rejected'|'approved'|'awaiting_issuance'|'ready'|'deployed';
export interface Governance {
 version:1;stage:Phase;procedure:Procedure;procedureNote:string;resources:string;
 consultationDepartments:string[];responses:Record<string,{actor:string;at:string;note:string}>;
 submittedBy?:string;submittedAt?:string;approvedBy?:string;approvedAt?:string;approvalNote?:string;
 release?:{actor:string;at:string;note:string};deployedBy?:string;deployedAt?:string;
}
export const phaseLabels={draft:bi('Bản nháp','Draft'),consulting:bi('Chờ tham vấn','Awaiting consultation'),pending:bi('Chờ Giám đốc phê duyệt','Awaiting Director approval'),changes_requested:bi('Cần chỉnh sửa','Changes requested'),rejected:bi('Bị từ chối','Rejected'),approved:bi('Đã phê duyệt','Approved'),awaiting_issuance:bi('Chờ hoàn tất thủ tục ban hành','Awaiting issuance procedure'),ready:bi('Sẵn sàng triển khai','Ready for implementation'),deployed:bi('Đã triển khai','Implemented')};
export function newGovernance():Governance{return {version:1,stage:'draft',procedure:'unspecified',procedureNote:'',resources:'',consultationDepartments:[],responses:{}};}
export function proposalPhase(a:WorkflowAnalysis):Phase{return a.governance?.stage||a.status;}
export function canPrepareAnalysis(s:WorkspaceState,a:WorkflowAnalysis){return demoPermissions[s.role].prepare&&['draft','pending','changes_requested'].includes(a.status)&&proposalPhase(a)!=='consulting';}
export function configured(a:WorkflowAnalysis){const g=a.governance;return !!g&&g.procedure!=='unspecified'&&(g.procedure!=='required'||!!g.procedureNote.trim());}
export function targetsActive(s:WorkspaceState,a:WorkflowAnalysis){return selectedProposals(a,s.proposals).every(p=>(!a.legalPlan||p.department!=='unassigned'&&!!p.owner)&&enterprise(s).departments.some(d=>d.id===p.department&&d.active&&(!a.legalPlan||!!d.headId))&&validOwnerFor(s,p.owner,p.department)&&validDay(p.due)&&p.title.vi.trim()&&p.expectedEvidence.vi.trim());}
export function canDirectorApprove(s:WorkspaceState,a:WorkflowAnalysis){return canReview(s.role,s.department)&&configured(a)&&readyForApproval(a,s.proposals)&&targetsActive(s,a)&&proposalPhase(a)==='pending';}
export type GovernanceAction=
 |{type:'governanceConfig';id:string;procedure:Procedure;procedureNote:string;resources:string;at:string}
 |{type:'consultationStart';id:string;departments:string[];at:string}
 |{type:'consultationRespond';id:string;note:string;at:string}
 |{type:'consultationClose';id:string;at:string}
 |{type:'consultationWithdraw';id:string;at:string}
 |{type:'release';id:string;note:string;at:string}
 |{type:'deploy';id:string;at:string};
type RoutedAction=GovernanceAction|{type:'submit';id:string;at:string}|{type:'decision';id:string;decision:'approved'|'rejected'|'changes_requested';note:string;at:string;seeded?:boolean};
export function govern(s:WorkspaceState,action:RoutedAction):WorkspaceState{
 const a=s.analyses.find(a=>a.id===action.id);if(!a||!Number.isFinite(Date.parse(action.at))||s.history.some(h=>h.analysisId===a.id&&Date.parse(h.at)>Date.parse(action.at)))return s;
 const actor=currentIdentity(s),g=a.governance||newGovernance();
 const commit=(next:WorkflowAnalysis,note:string|Bilingual,kind:WorkspaceState['history'][number]['kind']='governance',tasks=s.tasks,proposals=s.proposals):WorkspaceState=>({...s,analyses:s.analyses.map(row=>row.id===a.id?next:row),tasks,proposals,history:[...s.history,{id:`gov-${a.id}-${s.history.length}`,analysisId:a.id,kind,at:action.at,actor:actor.id,role:s.role,note:typeof note==='string'?bi(note,note):note,seeded:false}]});
 if(action.type==='governanceConfig'){
  if(!canPrepareAnalysis(s,a)||!['unspecified','required','not_required'].includes(action.procedure)||typeof action.procedureNote!=='string'||typeof action.resources!=='string'||action.procedureNote.length>2000||action.resources.length>2000)return s;
  const next={...newGovernance(),procedure:action.procedure,procedureNote:action.procedureNote.trim(),resources:action.resources.trim()};
  return commit({...a,status:'draft',governance:next,reviewChecks:{}},bi('Cập nhật thủ tục/nguồn lực; cần trình lại.','Updated procedure/resources; resubmission required.'),'edited',s.tasks,s.proposals.map(p=>p.analysisId===a.id?{...p,status:'pending'}:p));
 }
 if(action.type==='consultationStart'){
  if(!canPrepareAnalysis(s,a)||!['draft','changes_requested'].includes(a.status)||!selectedProposals(a,s.proposals).length||!Array.isArray(action.departments)||!action.departments.length||new Set(action.departments).size!==action.departments.length||action.departments.some(id=>!selectedProposals(a,s.proposals).some(p=>p.department===id)||!enterprise(s).departments.some(d=>d.id===id&&d.active&&d.headId)))return s;
  return commit({...a,status:'draft',reviewChecks:{},governance:{...g,stage:'consulting',consultationDepartments:[...action.departments],responses:{}}},bi('Gửi tham vấn; chưa giao nhiệm vụ.','Consultation requested; no official tasks assigned.'),'governance',s.tasks,s.proposals.map(p=>p.analysisId===a.id?{...p,status:'pending'}:p));
 }
 if(action.type==='consultationRespond'){
  if(s.role!=='department'||actor.id==='unassigned-head'||proposalPhase(a)!=='consulting'||!g.consultationDepartments.includes(s.department)||!action.note.trim()||action.note.length>2000||g.responses[s.department])return s;
  return commit({...a,governance:{...g,responses:{...g.responses,[s.department]:{actor:actor.id,at:action.at,note:action.note.trim()}}}},`${s.department}: ${action.note.trim()}`);
 }
 if(action.type==='consultationWithdraw'){
  if(s.role!=='legal'||proposalPhase(a)!=='consulting')return s;
  return commit({...a,governance:{...g,stage:'draft'}},bi('Rút yêu cầu tham vấn theo yêu cầu người dùng; giữ lịch sử và phản hồi đã có. Hồ sơ trở về chuẩn bị trình duyệt.','Consultation withdrawn at user request; prior history and responses retained. Submission is a draft.'));
 }
 if(action.type==='consultationClose'){
  if(s.role!=='legal'||proposalPhase(a)!=='consulting'||!g.consultationDepartments.every(id=>g.responses[id]))return s;
  return commit({...a,governance:{...g,stage:'draft'}},bi('Kết thúc tham vấn; chưa trình Giám đốc.','Consultation closed; not yet submitted to Director.'));
 }
 if(action.type==='submit'){
  if(!canPrepareAnalysis(s,a)||!['draft','changes_requested'].includes(a.status)||!configured(a)||!selectedProposals(a,s.proposals).length||!targetsActive(s,a))return s;
  return commit({...a,status:'pending',reviewChecks:{},governance:{...g,stage:'pending',submittedBy:actor.id,submittedAt:action.at}},bi('Pháp chế trình Giám đốc; chưa tạo nhiệm vụ.','Legal submitted to Director; no tasks created.'),'submitted',s.tasks,s.proposals.map(p=>p.analysisId===a.id?{...p,status:'pending'}:p));
 }
 if(action.type==='decision'){
  if(!canReview(s.role,s.department)||a.status!=='pending'||!['approved','rejected','changes_requested'].includes(action.decision)||!action.note.trim()||action.note.length>1000||action.decision==='approved'&&!canDirectorApprove(s,a))return s;
  const approved=action.decision==='approved',stage=approved?(g.procedure==='required'?'awaiting_issuance':'approved'):action.decision;
  const note=action.note.trim();
  return commit({...a,status:action.decision,reviewNote:bi(note,note),governance:{...g,stage,...(approved?{approvedBy:actor.id,approvedAt:action.at,approvalNote:note}:{})}},note,action.decision,s.tasks,s.proposals.map(p=>selectedProposals(a,s.proposals).some(x=>x.id===p.id)&&!approved?{...p,status:action.decision,note}:p));
 }
 if(action.type==='release'){
  if(s.role!=='legal'||a.status!=='approved'||!a.governance||!['approved','awaiting_issuance'].includes(g.stage)||!g.approvedBy||!g.approvedAt||!configured(a)||!action.note.trim()||action.note.length>2000||!targetsActive(s,a))return s;
  return commit({...a,governance:{...g,stage:'ready',release:{actor:actor.id,at:action.at,note:action.note.trim()}}},bi(`Xác nhận điều kiện triển khai: ${action.note.trim()}`,`Implementation conditions confirmed: ${action.note.trim()}`));
 }
 if(action.type==='deploy'){
  const ps=selectedProposals(a,s.proposals);
  if(s.role!=='legal'||a.status!=='approved'||!a.governance||g.stage!=='ready'||!g.release||!g.approvedBy||!ps.length||!targetsActive(s,a)||s.tasks.some(t=>t.analysisId===a.id||ps.some(p=>p.id===t.proposalId)))return s;
  const tasks:WorkspaceTask[]=ps.map(p=>({id:`task-${p.id}`,proposalId:p.id,analysisId:a.id,documentId:a.documentId,title:{...p.title},department:p.department,owner:p.owner,due:p.due,expectedEvidence:{...p.expectedEvidence},priority:s.proposals.find(row=>row.id===p.id)!.priority,status:'todo',evidence:'',seeded:false}));
  return commit({...a,governance:{...g,stage:'deployed',deployedBy:actor.id,deployedAt:action.at}},bi('Pháp chế triển khai kế hoạch sau phê duyệt và xác nhận điều kiện.','Legal implemented the approved and released plan.'),'governance',[...s.tasks,...tasks],s.proposals.map(p=>ps.some(x=>x.id===p.id)?{...p,status:'approved',note:g.approvalNote||''}:p));
 }
 return s;
}
export function validGovernance(s:WorkspaceState,a:WorkflowAnalysis):boolean{
 const g=a.governance;if(g===undefined)return true;
 const date=(x:unknown)=>typeof x==='string'&&Number.isFinite(Date.parse(x));const text=(x:unknown,max=2000)=>typeof x==='string'&&x.length<=max;
 if(!g||g.version!==1||!Object.hasOwn(phaseLabels,g.stage)||!['unspecified','not_required','required'].includes(g.procedure)||!text(g.procedureNote)||!text(g.resources)||!Array.isArray(g.consultationDepartments)||new Set(g.consultationDepartments).size!==g.consultationDepartments.length||g.consultationDepartments.some(id=>!enterprise(s).departments.some(d=>d.id===id))||!g.responses||Array.isArray(g.responses)||typeof g.responses!=='object')return false;
 for(const [id,r] of Object.entries(g.responses))if(!g.consultationDepartments.includes(id)||!r||!text(r.note)||!r.note.trim()||!date(r.at)||!s.history.some(h=>h.analysisId===a.id&&h.role==='department'&&h.actor===r.actor&&h.at===r.at&&h.kind==='governance'))return false;
 const base=g.stage==='consulting'?'draft':['awaiting_issuance','ready','deployed'].includes(g.stage)?'approved':g.stage;
 if(base!==a.status)return false;
 if(['pending','approved','awaiting_issuance','ready','deployed'].includes(g.stage)&&(!configured(a)||g.submittedBy!=='minh-anh'||!date(g.submittedAt)))return false;
 if(['approved','awaiting_issuance','ready','deployed'].includes(g.stage)&&(g.approvedBy!=='enterprise-admin'||!date(g.approvedAt)||!text(g.approvalNote,1000)||!g.approvalNote?.trim()||!s.history.some(h=>h.analysisId===a.id&&h.kind==='approved'&&h.actor===g.approvedBy&&h.role==='administrator'&&h.at===g.approvedAt)||g.stage==='awaiting_issuance'&&g.procedure!=='required'))return false;
 if(['ready','deployed'].includes(g.stage)&&(!g.release||g.release.actor!=='minh-anh'||!date(g.release.at)||!text(g.release.note)||!g.release.note.trim()||Date.parse(g.release.at)<Date.parse(g.approvedAt!)))return false;
 const tasks=s.tasks.filter(t=>t.analysisId===a.id),ps=selectedProposals(a,s.proposals);
 if(g.stage!=='deployed'&&tasks.length)return false;
 if(g.stage==='deployed'&&(g.deployedBy!=='minh-anh'||!date(g.deployedAt)||Date.parse(g.deployedAt!)<Date.parse(g.release!.at)||tasks.length!==ps.length||tasks.some(t=>!ps.some(p=>p.id===t.proposalId))))return false;
 return true;
}
