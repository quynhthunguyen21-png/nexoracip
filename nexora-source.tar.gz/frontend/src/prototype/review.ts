/** Checklist records review of available/missing demo inputs, never legal verification. */
import { bi } from './workflow.ts';
import type { WorkflowAnalysis, WorkflowProposal } from './workflow.ts';
export const reviewItems = [
 {id:'source',label:bi('Nguồn và số hiệu văn bản','Source and document identifier'),hint:bi('Đối chiếu nguồn, số hiệu và phiên bản; ghi rõ phần chưa xác minh.','Check source, identifier and version; record anything unverified.')},
 {id:'applicability',label:bi('Ngày hiệu lực và phạm vi áp dụng','Effective date and applicability'),hint:bi('Kiểm tra hiệu lực và điều kiện áp dụng với hoạt động doanh nghiệp.','Review validity and applicability to company activities.')},
 {id:'citations',label:bi('Điều khoản làm căn cứ','Supporting provisions'),hint:bi('Đối chiếu trích đoạn với bản gốc; ghi nhận khi chưa có điều khoản.','Check quotations against originals; record missing clauses.')},
 {id:'rationale',label:bi('Lý do đánh giá tác động','Impact rationale'),hint:bi('Rà soát lý do và giả định cho từng đề xuất đã chọn.','Inspect rationale and assumptions for each selected proposal.')},
 {id:'departments',label:bi('Phòng ban chịu trách nhiệm','Responsible departments'),hint:bi('Kiểm tra bộ phận và người phụ trách trong tổ chức mẫu.','Check department and owner in the fictional organization.')},
 {id:'actions',label:bi('Hành động và đầu ra/minh chứng','Actions and expected evidence'),hint:bi('Kiểm tra mô tả và đầu ra cần bàn giao.','Inspect action descriptions and required deliverables.')},
 {id:'deadlines',label:bi('Thời hạn và loại thời hạn','Deadlines and deadline type'),hint:bi('Mọi ngày mục tiêu ở đây là hạn nội bộ, không phải hạn luật định.','All target dates here are internal, not statutory deadlines.')},
 {id:'uncertainty',label:bi('Giả định và thông tin còn thiếu','Assumptions and missing information'),hint:bi('Xác định giới hạn của quyết định và những việc phải xác minh tiếp.','Record decision limitations and outstanding verification.')},
] as const;
export type ReviewItem = typeof reviewItems[number]['id'];
export function selectedProposals(a:WorkflowAnalysis, proposals:WorkflowProposal[]) {
 const all=proposals.filter(p=>p.analysisId===a.id);
 return a.selection===undefined?all:all.filter(p=>a.selection!.includes(p.id));
}
export function remainingChecks(a:WorkflowAnalysis) { return reviewItems.filter(item=>a.reviewChecks?.[item.id]!==true).length; }
export function readyForApproval(a:WorkflowAnalysis, proposals:WorkflowProposal[]) {
 return a.status==='pending'&&selectedProposals(a,proposals).length>0&&remainingChecks(a)===0;
}
