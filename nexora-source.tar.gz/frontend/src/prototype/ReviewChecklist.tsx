import { reviewItems } from './review';
import type { ReviewItem } from './review';
import type { WorkflowAnalysis } from './workflow';
import type { Locale } from './demo';
import { Badge,Icon } from './ui';
export function ReviewChecks({analysis,locale,editable,change,ids}:{analysis:WorkflowAnalysis;locale:Locale;editable:boolean;change:(item:ReviewItem,checked:boolean)=>void;ids:readonly ReviewItem[]}) {
 return <>{reviewItems.filter(item=>ids.includes(item.id)).map(item=><label className="checklist-item" key={item.id}><input type="checkbox" checked={analysis.reviewChecks?.[item.id]===true} disabled={!editable} onChange={e=>change(item.id,e.target.checked)}/><span><strong>{item.label[locale]}</strong><small>{item.hint[locale]}</small></span></label>)}</>;
}
export default function ReviewChecklist({analysis,locale,editable,change,openSource}:{analysis:WorkflowAnalysis;locale:Locale;editable:boolean;change:(item:ReviewItem,checked:boolean)=>void;openSource:()=>void}) {
 const t=(vi:string,en:string)=>locale==='vi'?vi:en;
 const ids=['source','applicability','citations'] as const,remaining=ids.filter(id=>analysis.reviewChecks?.[id]!==true).length;
 return <section className="review-checklist approval-step" aria-label={t('Xác minh căn cứ pháp lý','Verify legal basis')}><div className="approval-step-heading"><div><h3><span className="step-number">1</span>{t('Xác minh căn cứ pháp lý','Verify legal basis')}</h3><p>{t('Rà soát nguồn, hiệu lực và điều khoản được viện dẫn.','Review the source, applicability and cited provisions.')}</p></div><Badge tone={remaining?'warning':'success'}>{remaining?`${t('Còn','Remaining')} ${remaining} ${t('mục cần kiểm tra','checks')}`:t('Đã rà soát','Reviewed')}</Badge></div><ReviewChecks analysis={analysis} locale={locale} editable={editable} change={change} ids={ids}/><div className="legal-source-action"><small>{t('Checklist ghi nhận việc rà soát; không tự xác minh nguồn.','Checklist records review; it does not independently verify a source.')}</small><button className="button secondary" onClick={openSource}><Icon name="documents" size={16}/>{t('Mở nguồn','Open source')}</button></div></section>;
}
