/** Owner-supplied fictional organization, 2026-10-21. Emails are not used for messaging. */
export const digitalRoster = [
 {id:'khoa-tran',name:'Trần Đình Khoa',department:'management',jira:'khoa.tran',position:'CEO',responsibility:'Phê duyệt kế hoạch, chính sách và hợp đồng lớn.'},
 {id:'hoang-nguyen',name:'Nguyễn Minh Hoàng',department:'engineering',jira:'hoang.nguyen',position:'CTO',responsibility:'Kỹ thuật, an toàn thông tin, lưu trữ dữ liệu và hạ tầng.'},
 {id:'thao-le',name:'Lê Thị Phương Thảo',department:'operations',jira:'thao.le',position:'Ops Lead',responsibility:'Vận hành, quy trình nội bộ và điều phối công việc.'},
 {id:'yen-pham',name:'Phạm Hải Yến',department:'hr',jira:'yen.pham',position:'HR & Admin',responsibility:'Nhân sự, hợp đồng lao động, BHXH và nội quy.'},
 {id:'hanh-vu',name:'Vũ Thị Hồng Hạnh',department:'finance',jira:'hanh.vu',position:'Finance',responsibility:'Tài chính, thuế, hóa đơn và quy chế tài chính.'},
 {id:'bao-dang',name:'Đặng Quốc Bảo',department:'sales',jira:'bao.dang',position:'Sales Lead',responsibility:'Kinh doanh và hợp đồng dịch vụ khách hàng.'},
 {id:'phuong-bui',name:'Bùi Bích Phương',department:'operations',jira:'phuong.bui',position:'Account Lead',responsibility:'Dự án, SLA, nghiệm thu và cam kết khách hàng.'},
 {id:'minh-do',name:'Đỗ Nhật Minh',department:'engineering',jira:'minh.do',position:'Backend Dev',responsibility:'Thực hiện và kiểm thử kỹ thuật backend.'},
 {id:'duc-hoang',name:'Hoàng Văn Đức',department:'engineering',jira:'duc.hoang',position:'Frontend Dev',responsibility:'Thực hiện thay đổi giao diện web/app.'},
 {id:'anh-nguyen',name:'Nguyễn Mai Anh',department:'product',jira:'anh.nguyen',position:'UI/UX',responsibility:'Thiết kế và kiểm thử trải nghiệm người dùng.'},
];
export const digitalProfile={organizationId:'nexora-digital' as const,name:'NEXORA TECHNOLOGY',activity:'Cung cấp giải pháp phần mềm, website thương mại điện tử và dịch vụ truyền thông số.',sector:'Phần mềm · Thương mại điện tử · Truyền thông số',employees:10,locations:'',structure:'10 nhân sự. Chưa có người rà soát pháp lý chuyên trách được chỉ định.',processes:'1. Quản trị và vận hành: hợp đồng lao động, nhân sự, tài chính, thuế và quy trình nội bộ.\n2. Kinh doanh và khách hàng: hợp đồng dịch vụ IT/website, phụ lục, SLA, nghiệm thu và thanh lý.\n3. Sản phẩm và công nghệ: phát triển phần mềm, giao diện, bảo mật, sao lưu và chính sách người dùng.\nPhạm vi theo hồ sơ được cung cấp; chi tiết cách vận hành và luồng dữ liệu cần xác minh.',systems:'Chưa cung cấp hạ tầng, nhà cung cấp, vị trí lưu và danh mục dữ liệu xử lý.',policies:'Chưa cung cấp toàn văn hợp đồng, chính sách và tiêu chí kiểm tra.',revision:1,updatedAt:null,origin:'user_input' as const};
export const jiraProjects=[
 {id:'NEX-GOV',name:{vi:'Quản trị, Hành chính & Vận hành',en:'Governance & Operations'},members:['yen-pham','hanh-vu','thao-le','khoa-tran'],departments:['hr','finance','operations','management']},
 {id:'NEX-BIZ',name:{vi:'Kinh doanh, Hợp đồng & Khách hàng',en:'Sales, Contracts & Clients'},members:['bao-dang','phuong-bui','khoa-tran'],departments:['sales','operations','management']},
 {id:'NEX-PROD',name:{vi:'Sản phẩm, Dự án & Công nghệ',en:'Product & Technology'},members:['hoang-nguyen','minh-do','duc-hoang','anh-nguyen'],departments:['engineering','product']},
];
export const digitalDepartments=[
 ['management','Ban giám đốc','Management',''],['legal','Rà soát pháp lý','Legal review',''],['hr','Nhân sự & Hành chính','HR & Administration','yen-pham'],['finance','Tài chính & Kế toán','Finance','hanh-vu'],['sales','Kinh doanh','Sales','bao-dang'],['operations','Vận hành & Khách hàng','Operations & Accounts','thao-le'],['engineering','Công nghệ & Kỹ thuật','Technology & Engineering','hoang-nguyen'],['product','Sản phẩm & Thiết kế','Product & Design',''],['unassigned','Chưa phân công','Unassigned',''],
].map(([id,vi,en,headId])=>({id,name:{vi,en},headId,responsibility:digitalRoster.filter(p=>p.department===id).map(p=>p.responsibility).join(' '),active:true,parentId:null}));
