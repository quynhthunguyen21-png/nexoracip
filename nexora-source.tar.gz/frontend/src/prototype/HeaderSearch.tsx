import { useEffect, useRef, useState } from 'react';
import { Icon } from './ui';
import { quickSearch } from './selectors';
import type { WorkspaceState, WorkspaceTask } from './workspaces';
import type { Locale } from './demo';
export default function HeaderSearch({state,locale,openDocument,openTask}:{state:WorkspaceState;locale:Locale;openDocument:(id:string)=>void;openTask:(task:WorkspaceTask)=>void}) {
 const [query,setQuery]=useState(''),[opened,setOpened]=useState(false),ref=useRef<HTMLDivElement>(null),input=useRef<HTMLInputElement>(null);
 const t=(vi:string,en:string)=>locale==='vi'?vi:en;
 const q=query.trim();
 const results=quickSearch(state,query,locale).map(r=>({...r,kind:r.kind==='document'?t('Nguồn mẫu','Sample source'):t('Công việc','Task'),open:()=>r.kind==='document'?openDocument(r.id):openTask(state.tasks.find(task=>task.id===r.id)!)}));
 useEffect(()=>{function outside(e:PointerEvent){if(ref.current&&!ref.current.contains(e.target as Node))setOpened(false);}function key(e:KeyboardEvent){if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'&&input.current?.offsetParent){e.preventDefault();input.current.focus();setOpened(true);}if(e.key==='Escape')setOpened(false);}document.addEventListener('pointerdown',outside);document.addEventListener('keydown',key);return()=>{document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',key);};},[]);
 useEffect(()=>{setQuery('');setOpened(false);},[state.role,state.department]);
 return <div className="header-search" ref={ref} role="search"><Icon name="search" size={18}/><input ref={input} aria-label={t('Tìm nhanh hồ sơ và công việc','Quick search records and tasks')} placeholder={t('Tìm kiếm…','Search…')} value={query} onFocus={()=>setOpened(true)} onChange={e=>{setQuery(e.target.value);setOpened(true);}} onKeyDown={e=>{if(e.key==='Enter'&&results[0]){results[0].open();setOpened(false);input.current?.blur();}}}/><kbd>⌘ K</kbd>{opened&&q&&<div className="header-search-results">{results.length?results.map(r=><button key={r.id} onClick={()=>{r.open();setOpened(false);}}><strong>{r.title}</strong><small>{r.kind} · {r.id}</small></button>):<p>{t('Không có kết quả trong phạm vi vai trò.','No results within your role scope.')}</p>}</div>}</div>;
}
