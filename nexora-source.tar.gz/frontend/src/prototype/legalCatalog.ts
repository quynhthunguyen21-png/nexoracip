/** User-supplied workbook observations; not authenticated legal approvals. */
export const legalCatalog = [
  {
    "id": "L01",
    "title": "Luật Bảo vệ dữ liệu cá nhân",
    "identifier": "91/2025/QH15",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "26/06/2025",
    "effective": "01/01/2026",
    "sourceStatus": "Có hiệu lực từ 01/01/2026",
    "related": "13/2023/NĐ-CP",
    "sourceUrl": "https://vanban.chinhphu.vn/?docid=214590&pageid=27160",
    "attachmentUrl": "https://datafiles.chinhphu.vn/cpp/files/vbpq/2025/7/91qh.signed.pdf",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "B"
    }
  },
  {
    "id": "L02",
    "title": "Luật An ninh mạng",
    "identifier": "116/2025/QH15",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "10/12/2025",
    "effective": "01/07/2026",
    "sourceStatus": "Có hiệu lực từ 01/07/2026",
    "related": "24/2018/QH14; 53/2022/NĐ-CP",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=216499&orggroupid=1&pageid=27160",
    "attachmentUrl": "https://datafiles.chinhphu.vn/cpp/files/vbpq/2026/01/luat116-2025.pdf",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "C"
    }
  },
  {
    "id": "L03",
    "title": "Luật Trí tuệ nhân tạo",
    "identifier": "134/2025/QH15",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "10/12/2025",
    "effective": "01/03/2026",
    "sourceStatus": "Có hiệu lực từ 01/03/2026",
    "related": "91/2025/QH15; 116/2025/QH15",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=216334&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?classid=1&docid=216334&pageid=27160",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "D"
    }
  },
  {
    "id": "L04",
    "title": "Luật Thương mại điện tử",
    "identifier": "122/2025/QH15",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "10/12/2025",
    "effective": "01/07/2026",
    "sourceStatus": "Có hiệu lực từ 01/07/2026",
    "related": "52/2013/NĐ-CP; 85/2021/NĐ-CP; 248/2026/NĐ-CP",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=216503&pageid=27160",
    "attachmentUrl": "https://datafiles.chinhphu.vn/cpp/files/vbpq/2026/01/luat122.2025.qh15.pdf",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "E"
    }
  },
  {
    "id": "L05",
    "title": "Luật Giao dịch điện tử",
    "identifier": "20/2023/QH15",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "22/06/2023",
    "effective": "01/07/2024",
    "sourceStatus": "Cần rà soát hiệu lực và văn bản hướng dẫn liên quan",
    "related": "Luật Giao dịch điện tử 2005",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=208421&pageid=27160&typegroupid=3",
    "attachmentUrl": "https://datafiles.chinhphu.vn/cpp/files/vbpq/2023/8/luat20-2023-qh15..pdf",
    "teamReview": "Chưa kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "F"
    }
  },
  {
    "id": "L06",
    "title": "Luật Bảo vệ quyền lợi người tiêu dùng",
    "identifier": "19/2023/QH15",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "20/06/2023",
    "effective": "01/07/2024",
    "sourceStatus": "Cần rà soát hiệu lực và văn bản hướng dẫn liên quan",
    "related": "59/2010/QH12; 47/VBHN-VPQH",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=208363&orggroupid=1&pageid=27160",
    "attachmentUrl": "https://datafiles.chinhphu.vn/cpp/files/vbpq/2023/7/luat19_2023.pdf",
    "teamReview": "Chưa kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "G"
    }
  },
  {
    "id": "L07",
    "title": "Nghị định về bảo vệ dữ liệu cá nhân",
    "identifier": "13/2023/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "17/04/2023",
    "effective": "01/07/2023",
    "sourceStatus": "Hết hiệu lực",
    "related": "91/2025/QH15",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=207759&orggroupid=2&pageid=27160",
    "attachmentUrl": "https://datafiles.chinhphu.vn/cpp/files/vbpq/2023/4/13nd.signed.pdf",
    "teamReview": "Chưa kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "H"
    }
  },
  {
    "id": "L08",
    "title": "Nghị định về thương mại điện tử",
    "identifier": "52/2013/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "16/05/2013",
    "effective": "01/07/2013",
    "sourceStatus": "Cần rà soát quan hệ với Luật 122/2025/QH15 và Nghị định 248/2026/NĐ-CP",
    "related": "85/2021/NĐ-CP; 122/2025/QH15; 248/2026/NĐ-CP",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=167457&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?classid=1&docid=167457&pageid=27160",
    "teamReview": "Chưa kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "I"
    }
  },
  {
    "id": "L09",
    "title": "Nghị định sửa đổi Nghị định 52/2013/NĐ-CP về thương mại điện tử",
    "identifier": "85/2021/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "25/09/2021",
    "effective": "01/01/2022",
    "sourceStatus": "Cần rà soát cùng Luật 122/2025/QH15 và Nghị định 248/2026/NĐ-CP",
    "related": "52/2013/NĐ-CP; 122/2025/QH15",
    "sourceUrl": "https://vanban.chinhphu.vn/default.aspx?docid=204191&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/default.aspx?docid=204191&pageid=27160",
    "teamReview": "Chưa kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "J"
    }
  },
  {
    "id": "L10",
    "title": "Nghị định quy định chi tiết một số điều của Luật Thương mại điện tử",
    "identifier": "248/2026/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "30/06/2026",
    "effective": "01/07/2026",
    "sourceStatus": "Có hiệu lực từ 01/07/2026",
    "related": "122/2025/QH15",
    "sourceUrl": "https://vanban.chinhphu.vn/?docid=218747&orggroupid=2&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?docid=218747&orggroupid=2&pageid=27160",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "K"
    }
  },
  {
    "id": "L11",
    "title": "Nghị định quy định chi tiết một số điều của Luật An ninh mạng",
    "identifier": "53/2022/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "15/08/2022",
    "effective": "01/10/2022",
    "sourceStatus": "Cần rà soát điều khoản chuyển tiếp và văn bản hướng dẫn sau Luật 116/2025/QH15",
    "related": "24/2018/QH14; 116/2025/QH15",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=206381&pageid=27160&typegroupid=3",
    "attachmentUrl": "https://datafiles.chinhphu.vn/cpp/files/vbpq/2022/08/53-cp.signed.pdf",
    "teamReview": "Chưa kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "L"
    }
  },
  {
    "id": "L12",
    "title": "Nghị định quản lý, cung cấp, sử dụng dịch vụ internet và thông tin trên mạng",
    "identifier": "147/2024/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "09/11/2024",
    "effective": "25/12/2024",
    "sourceStatus": "Cần rà soát hiệu lực và văn bản sửa đổi liên quan",
    "related": "Luật An ninh mạng; Luật Công nghệ thông tin",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=211654&orggroupid=2&pageid=27160",
    "attachmentUrl": "https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/11/147-nd.signed.pdf",
    "teamReview": "Chưa kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "M"
    }
  },
  {
    "id": "L13",
    "title": "Luật Viễn thông",
    "identifier": "24/2023/QH15",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "24/11/2023",
    "effective": "01/07/2024",
    "sourceStatus": "Cần rà soát phạm vi áp dụng theo mô hình dịch vụ của doanh nghiệp",
    "related": "Văn bản hướng dẫn Luật Viễn thông",
    "sourceUrl": "https://vanban.chinhphu.vn/?docid=209631&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?docid=209631&pageid=27160",
    "teamReview": "Chưa kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "N"
    }
  },
  {
    "id": "L14",
    "title": "Luật Công nghệ thông tin",
    "identifier": "67/2006/QH11",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "29/06/2006",
    "effective": "01/01/2007",
    "sourceStatus": "Cần rà soát hiệu lực từng phần và quan hệ với luật chuyên ngành mới",
    "related": "86/2015/QH13; 20/2023/QH15",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=29137&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?classid=1&docid=29137&pageid=27160",
    "teamReview": "Chưa kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "O"
    }
  },
  {
    "id": "L15",
    "title": "Luật An toàn thông tin mạng",
    "identifier": "86/2015/QH13",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "19/11/2015",
    "effective": "01/07/2016",
    "sourceStatus": "Cần rà soát hiệu lực từng phần và điều khoản chuyển tiếp sau Luật An ninh mạng 2025",
    "related": "116/2025/QH15; 53/2022/NĐ-CP",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=183196&pageid=27160&typegroupid=3",
    "attachmentUrl": "https://vanban.chinhphu.vn/?classid=1&docid=183196&pageid=27160&typegroupid=3",
    "teamReview": "Chưa kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "P"
    }
  },
  {
    "id": "L16",
    "title": "Luật Sở hữu trí tuệ",
    "identifier": "50/2005/QH11",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "12/12/2005",
    "effective": "01/07/2006",
    "sourceStatus": "Đã được sửa đổi nhiều lần; tra cứu bản hợp nhất hiện hành trước khi áp dụng",
    "related": "07/2022/QH15",
    "sourceUrl": "https://vanban.chinhphu.vn/?docid=30015&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?docid=30015&pageid=27160",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "Q"
    }
  },
  {
    "id": "L17",
    "title": "Luật sửa đổi, bổ sung một số điều của Luật Sở hữu trí tuệ",
    "identifier": "07/2022/QH15",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "16/06/2022",
    "effective": "01/01/2023",
    "sourceStatus": "Văn bản sửa đổi; cần đọc cùng Luật Sở hữu trí tuệ và các sửa đổi khác",
    "related": "50/2005/QH11",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=206240&org=&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?classid=1&docid=206240&org=&pageid=27160",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "R"
    }
  },
  {
    "id": "L18",
    "title": "Luật sửa đổi, bổ sung một số điều của Luật Quảng cáo",
    "identifier": "75/2025/QH15",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "16/06/2025",
    "effective": "01/01/2026",
    "sourceStatus": "Có hiệu lực từ 01/01/2026",
    "related": "16/2012/QH13; 342/2025/NĐ-CP; 88/VBHN-VPQH",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=214561&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?classid=1&docid=214561&pageid=27160",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "S"
    }
  },
  {
    "id": "L19",
    "title": "Nghị định quy định chi tiết một số điều của Luật Quảng cáo",
    "identifier": "342/2025/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "26/12/2025",
    "effective": "15/02/2026",
    "sourceStatus": "Có hiệu lực từ 15/02/2026",
    "related": "75/2025/QH15; 16/2012/QH13",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=216403&orggroupid=2&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?classid=1&docid=216403&orggroupid=2&pageid=27160",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "T"
    }
  },
  {
    "id": "L20",
    "title": "Nghị định quy định về hóa đơn, chứng từ",
    "identifier": "123/2020/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "19/10/2020",
    "effective": "01/07/2022",
    "sourceStatus": "Đã được sửa đổi, bổ sung bởi Nghị định 70/2025/NĐ-CP; kiểm tra quy định thuế hiện hành",
    "related": "70/2025/NĐ-CP; 78/2021/TT-BTC",
    "sourceUrl": "https://vanban.chinhphu.vn/?docid=201365&lang=vi&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?docid=201365&lang=vi&pageid=27160",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "U"
    }
  },
  {
    "id": "L21",
    "title": "Nghị định sửa đổi, bổ sung một số điều của Nghị định 123/2020/NĐ-CP về hóa đơn, chứng từ",
    "identifier": "70/2025/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "20/03/2025",
    "effective": "01/06/2025",
    "sourceStatus": "Có hiệu lực từ 01/06/2025",
    "related": "123/2020/NĐ-CP",
    "sourceUrl": "https://vanban.chinhphu.vn/?docid=213179&lang=vi&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?docid=213179&lang=vi&pageid=27160",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "V"
    }
  },
  {
    "id": "L22",
    "title": "Nghị định xử phạt vi phạm hành chính trong lĩnh vực bưu chính, viễn thông, CNTT và giao dịch điện tử",
    "identifier": "15/2020/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "03/02/2020",
    "effective": "15/04/2020",
    "sourceStatus": "Đã được sửa đổi, bổ sung",
    "related": "14/2022/NĐ-CP; 211/2025/NĐ-CP",
    "sourceUrl": "https://vanban.chinhphu.vn/?docid=199053&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?docid=199053&pageid=27160",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "W"
    }
  },
  {
    "id": "L23",
    "title": "Nghị định về hoạt động mật mã dân sự và sửa đổi Nghị định 15/2020/NĐ-CP",
    "identifier": "211/2025/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "25/07/2025",
    "effective": "09/09/2025",
    "sourceStatus": "Có hiệu lực từ 09/09/2025",
    "related": "15/2020/NĐ-CP; 14/2022/NĐ-CP",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=0&docid=214736&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?classid=0&docid=214736&pageid=27160",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "X"
    }
  },
  {
    "id": "L24",
    "title": "Văn bản hợp nhất Luật Quảng cáo",
    "identifier": "88/VBHN-VPQH",
    "kind": "Văn bản hợp nhất",
    "issuer": "Văn phòng Quốc hội",
    "issued": "22/08/2025",
    "effective": "Không áp dụng như ngày hiệu lực của luật mới",
    "sourceStatus": "Dùng để tra cứu văn bản hợp nhất; đối chiếu Luật 75/2025/QH15 và Nghị định 342/2025/NĐ-CP",
    "related": "16/2012/QH13; 75/2025/QH15",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=0&docid=215066&pageid=27160",
    "attachmentUrl": "https://vanban.chinhphu.vn/?classid=0&docid=215066&pageid=27160",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "Y"
    }
  },
  {
    "id": "L25",
    "title": "Nghị định quy định chi tiết một số điều và biện pháp thi hành Luật Bảo vệ dữ liệu cá nhân",
    "identifier": "356/2025/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "31/12/2025",
    "effective": "01/01/2026",
    "sourceStatus": "Có hiệu lực từ 01/01/2026; đối chiếu phạm vi áp dụng và điều khoản chuyển tiếp",
    "related": "91/2025/QH15; 13/2023/NĐ-CP",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=216387&pageid=27160",
    "attachmentUrl": "https://datafiles.chinhphu.vn/cpp/files/vbpq/2026/01/356-nd.signed.pdf",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "Z"
    }
  },
  {
    "id": "L26",
    "title": "Nghị định quy định xử phạt vi phạm hành chính trong lĩnh vực an ninh mạng và bảo vệ dữ liệu cá nhân",
    "identifier": "330/2026/NĐ-CP",
    "kind": "Nghị định",
    "issuer": "Chính phủ",
    "issued": "19/08/2026",
    "effective": "19/08/2026",
    "sourceStatus": "Có hiệu lực từ 19/08/2026; phải xác định đúng hành vi và điều khoản xử phạt",
    "related": "91/2025/QH15; 116/2025/QH15; 356/2025/NĐ-CP",
    "sourceUrl": "https://vanban.chinhphu.vn/?docid=219266&orggroupid=2&pageid=27160",
    "attachmentUrl": "https://datafiles.chinhphu.vn/cpp/files/vbpq/2026/8/330_2026_nd-cp_19082026-signed.signed.pdf",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "AA"
    }
  },
  {
    "id": "L27",
    "title": "Luật Công nghệ cao",
    "identifier": "133/2025/QH15",
    "kind": "Luật",
    "issuer": "Quốc hội",
    "issued": "10/12/2025",
    "effective": "01/07/2026",
    "sourceStatus": "Có hiệu lực từ 01/07/2026; chỉ áp dụng theo phạm vi luật và hoạt động thực tế",
    "related": "Luật Công nghệ cao trước đây; văn bản hướng dẫn thi hành",
    "sourceUrl": "https://congbao.chinhphu.vn/van-ban/luat-so-133-2025-qh15-468693/61694.htm",
    "attachmentUrl": "https://congbao.chinhphu.vn/van-ban/luat-so-133-2025-qh15-468693/61694.htm",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "AB"
    }
  },
  {
    "id": "L28",
    "title": "Nghị định số 333/2026/NĐ-CP quy định chi tiết một số điều và biện pháp thi hành Luật An ninh mạng",
    "identifier": "333/2026/NĐ-CP",
    "kind": "Nghị định ",
    "issuer": "Chính phủ",
    "issued": "2026-08-19T00:00:00",
    "effective": "2026-08-19T00:00:00",
    "sourceStatus": "Còn hiệu lực",
    "related": "Luật An ninh mạng số 116/2025/QH15",
    "sourceUrl": "https://vanban.chinhphu.vn/?classid=1&docid=219244&pageid=27160&typegroupid=4&utm_source",
    "attachmentUrl": "https://datafiles.chinhphu.vn/cpp/files/vbpq/2026/8/333_2026_nd-cp_19082026-signed.signed.pdf",
    "teamReview": "Đã kiểm tra",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "TÀI LIỆU VỀ PHÁP LUẬT ",
      "column": "AC"
    }
  }
];
export const changeCandidates = [
  {
    "id": "LC01",
    "before": "L07 – 13/2023/NĐ-CP",
    "after": "L01 – 91/2025/QH15",
    "scope": "Luật 91/2025/QH15: đối chiếu các điều về phạm vi áp dụng, nguyên tắc xử lý, quyền/nghĩa vụ của chủ thể dữ liệu và điều khoản thi hành/chuyển tiếp. Nghị định 13/2023/NĐ-CP: đối chiếu các điều về xử lý dữ liệu, sự đồng ý, quyền chủ thể dữ liệu, hồ sơ đánh giá tác động và chuyển dữ liệu ra nước ngoài. Không coi đây là sửa đổi từng điều của Nghị định 13 nếu chưa có điều khoản thay thế hoặc bãi bỏ tương ứng.",
    "oldSummary": "Nghị định 13/2023/NĐ-CP đặt ra quy định chi tiết về bảo vệ dữ liệu cá nhân, gồm nguyên tắc xử lý, sự đồng ý, quyền của chủ thể dữ liệu và hồ sơ đánh giá tác động xử lý/chuyển dữ liệu ra nước ngoài. ",
    "newSummary": "Luật 91/2025/QH15 là luật chuyên ngành về bảo vệ dữ liệu cá nhân, có hiệu lực 01/01/2026. Khi đối chiếu, trích đúng điều về phạm vi, nguyên tắc/căn cứ xử lý, quyền chủ thể dữ liệu và điều khoản chuyển tiếp từ PDF chính thức; không suy ra toàn bộ Nghị định 13/2023/NĐ-CP hết hiệu lực chỉ vì luật mới có hiệu lực.",
    "description": "Cập nhật khung pháp lý bảo vệ dữ liệu cá nhân; cần lập bảng đối chiếu nghĩa vụ, căn cứ xử lý, quyền chủ thể dữ liệu và chuyển tiếp.",
    "departments": "Pháp chế; IT; Data; bảo mật; kinh doanh",
    "processes": "Lập bản đồ dữ liệu; thông báo/đồng ý khi cần; phân quyền; lưu trữ; chia sẻ; xử lý yêu cầu chủ thể dữ liệu; ứng phó sự cố.",
    "rationale": "Doanh nghiệp công nghệ có thể xử lý dữ liệu khách hàng, nhân viên hoặc dữ liệu vận hành; cần xác định vai trò và nghĩa vụ cụ thể.",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "LUẬT THAY ĐỔI ",
      "column": "B"
    }
  },
  {
    "id": "LC02",
    "before": "old_text",
    "after": "L02 – 116/2025/QH15",
    "scope": "Đối chiếu Luật An ninh mạng 24/2018/QH14, Luật 116/2025/QH15 và điều khoản thi hành/chuyển tiếp của luật mới. Với Nghị định 53/2022/NĐ-CP, xác định riêng quy định còn hiệu lực và văn bản hướng dẫn thay thế; không gộp mọi quy định an ninh mạng thành một cặp điều khoản.",
    "oldSummary": "Luật 24/2018/QH14 và Nghị định 53/2022/NĐ-CP là nền tảng pháp lý trước đó về an ninh mạng, trong đó có quy định về bảo vệ hệ thống thông tin quan trọng, trách nhiệm bảo đảm an ninh mạng và các yêu cầu áp dụng theo điều kiện luật định. Chỉ trích điều khoản phù hợp sau khi xác định loại hệ thống và hoạt động của Nexora.",
    "newSummary": " Luật 116/2025/QH15 về an ninh mạng có hiệu lực 01/07/2026. Phải đối chiếu trực tiếp các điều về phạm vi áp dụng, trách nhiệm của cơ quan/tổ chức/doanh nghiệp, bảo vệ hệ thống và điều khoản thi hành; Nghị định 330/2026/NĐ-CP cần được kiểm tra theo đúng phạm vi điều chỉnh và ngày hiệu lực 19/08/2026.",
    "description": "Cập nhật khung an ninh mạng; đánh giá yêu cầu liên quan hệ thống, dữ liệu, sự cố và trách nhiệm của doanh nghiệp theo phạm vi áp dụng.",
    "departments": "IT; an toàn thông tin; vận hành; pháp chế",
    "processes": "Quản lý tài sản hệ thống; kiểm soát truy cập; ghi log; ứng phó sự cố; rà soát nhà cung cấp và lưu trữ dữ liệu.",
    "rationale": "Có thể tác động đến kiến trúc hệ thống, quy trình phản ứng sự cố và bằng chứng tuân thủ; cần xác định nghĩa vụ cụ thể theo mô hình kinh doanh.",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "LUẬT THAY ĐỔI ",
      "column": "C"
    }
  },
  {
    "id": "LC03",
    "before": "L08 – 52/2013/NĐ-CP và L09 – 85/2021/NĐ-CP",
    "after": "L04 – 122/2025/QH15; L10 – 248/2026/NĐ-CP",
    "scope": "Luật 122/2025/QH15: đối chiếu điều về phạm vi/đối tượng, chủ thể tham gia thương mại điện tử, nền tảng thương mại điện tử, trách nhiệm cung cấp thông tin và điều khoản thi hành hoặc chuyển tiếp. Nghị định 52/2013/NĐ-CP được sửa đổi bởi Nghị định 85/2021/NĐ-CP; kiểm tra quy định nào được thay thế hoặc tiếp tục áp dụng theo văn bản hướng dẫn mới (ghi nhận trong cơ sở dữ liệu là Nghị định 248/2026/NĐ-CP, cần kiểm tra chính xác điều khoản và phạm vi).",
    "oldSummary": "Nghị định 52/2013/NĐ-CP, được sửa đổi/bổ sung bởi Nghị định 85/2021/NĐ-CP, quy định về hoạt động thương mại điện tử, website/ứng dụng thương mại điện tử, thông báo/đăng ký và trách nhiệm của các bên theo từng mô hình. Phải chọn điều khoản tương ứng với mô hình hoạt động của Nexora; không mặc định mọi nghĩa vụ áp dụng cho mọi doanh nghiệp.",
    "newSummary": "Luật 122/2025/QH15 về thương mại điện tử có hiệu lực 01/07/2026. Đối chiếu các nghĩa vụ mới theo đúng vai trò (người bán, đơn vị vận hành nền tảng, trung gian hoặc nhà cung cấp dịch vụ) và quy định chuyển tiếp. ",
    "description": "Cập nhật khung thương mại điện tử; cần kiểm tra nghĩa vụ theo loại nền tảng, vai trò trung gian/người bán và hoạt động cung cấp dịch vụ.",
    "departments": "Sản phẩm; kinh doanh; vận hành; chăm sóc khách hàng; pháp chế",
    "processes": "Đăng ký/thông báo nếu thuộc diện; quản lý thông tin người bán; điều khoản dịch vụ; lưu trữ giao dịch; tiếp nhận khiếu nại.",
    "rationale": "Nếu Nexora vận hành nền tảng, marketplace hoặc dịch vụ số có chức năng thương mại, cần xác định đúng vai trò pháp lý và nghĩa vụ tương ứng.",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "LUẬT THAY ĐỔI ",
      "column": "D"
    }
  },
  {
    "id": "LC04",
    "before": " Luật AI là khung mới",
    "after": "L03 – 134/2025/QH15",
    "scope": "Không phải hồ sơ sửa đổi nếu chưa xác định điều khoản cũ cụ thể. Phân loại là “văn bản mới/khung pháp lý mới”; rà soát điều khoản về phạm vi, phân loại hệ thống AI, vai trò các chủ thể, nghĩa vụ quản lý rủi ro và điều khoản thi hành của Luật 134/2025/QH15.",
    "oldSummary": null,
    "newSummary": " Luật 134/2025/QH15 về trí tuệ nhân tạo có hiệu lực 01/03/2026 theo hồ sơ nguồn đã thu thập. Phân tích theo phạm vi điều chỉnh, phân loại/đánh giá rủi ro và trách nhiệm của chủ thể liên quan; chỉ áp dụng nghĩa vụ cụ thể sau khi phân loại sản phẩm/hệ thống AI mà Nexora phát triển, tích hợp hoặc sử dụng.",
    "description": "Tạo khung tuân thủ AI; xác định sản phẩm có thuộc phạm vi điều chỉnh và nghĩa vụ nào áp dụng.",
    "departments": "AI/ML; sản phẩm; kỹ thuật; pháp chế; quản trị rủi ro",
    "processes": "Kiểm kê hệ thống AI; phân loại mục đích sử dụng; đánh giá dữ liệu đầu vào/đầu ra; lưu hồ sơ kiểm thử và giám sát.",
    "rationale": "Nếu phát triển, tích hợp hoặc cung cấp hệ thống AI, cần xác định vai trò nhà phát triển/nhà cung cấp/bên triển khai và nghĩa vụ thực tế.",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "LUẬT THAY ĐỔI ",
      "column": "E"
    }
  },
  {
    "id": "LC05",
    "before": "Luật 59/2010/QH12",
    "after": "L06 – 19/2023/QH15; đối chiếu bản hợp nhất hiện hành",
    "scope": "Đối chiếu Luật 19/2023/QH15 (có hiệu lực 01/07/2024) với Luật Bảo vệ quyền lợi người tiêu dùng 59/2010/QH12, đặc biệt các quy định về giao dịch từ xa, cung cấp thông tin, hợp đồng theo mẫu/điều kiện giao dịch chung, trách nhiệm của tổ chức kinh doanh trên không gian mạng và điều khoản thi hành. Kiểm tra văn bản hợp nhất đang dùng để tránh trích bản hết cập nhật.",
    "oldSummary": " Luật 59/2010/QH12 quy định các quyền cơ bản của người tiêu dùng và trách nhiệm của tổ chức, cá nhân kinh doanh hàng hóa/dịch vụ. Khi lập so sánh cần lấy đúng điều khoản cũ liên quan đến thông tin, giao dịch từ xa, hợp đồng mẫu hoặc giải quyết khiếu nại; không dùng phần giới thiệu chung thay cho điều luật.",
    "newSummary": " Luật 19/2023/QH15 có hiệu lực 01/07/2024, thay thế khuôn khổ Luật 59/2010/QH12 theo điều khoản thi hành. Luật mới quy định cụ thể hơn về bảo vệ người tiêu dùng trong giao dịch với tổ chức kinh doanh, gồm giao dịch từ xa và trên không gian mạng; phải trích điều khoản cụ thể từ bản luật chính thức/bản hợp nhất phù hợp.",
    "description": "Rà soát nghĩa vụ cung cấp thông tin, điều khoản giao dịch, tiếp nhận phản ánh và bảo vệ người tiêu dùng trên môi trường số.",
    "departments": "Kinh doanh; chăm sóc khách hàng; sản phẩm; pháp chế",
    "processes": "Rà soát điều khoản dịch vụ; hiển thị giá/phí; quy trình khiếu nại; hoàn tiền; lưu vết trao đổi với khách hàng.",
    "rationale": "Có thể ảnh hưởng đến nội dung hợp đồng, giao diện cung cấp thông tin và quy trình xử lý tranh chấp khách hàng.",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "LUẬT THAY ĐỔI ",
      "column": "F"
    }
  },
  {
    "id": "LC06",
    "before": "L07 – 13/2023/NĐ-CP (đối chiếu phạm vi còn áp dụng)",
    "after": "L01 – 91/2025/QH15; L25 – 356/2025/NĐ-CP",
    "scope": "Đối chiếu theo chủ đề, không mặc định là sửa đổi từng điều: Luật 91/2025/QH15 và Nghị định 356/2025/NĐ-CP, kiểm tra điều khoản thi hành của Luật 91 và điều khoản hiệu lực hoặc bãi bỏ của Nghị định 356 để xác định quy định nào của Nghị định 13/2023/NĐ-CP tiếp tục áp dụng hoặc bị thay thế.",
    "oldSummary": "Nghị định 13/2023/NĐ-CP quy định thủ tục/nghĩa vụ chi tiết về bảo vệ dữ liệu cá nhân. Dùng làm nền so sánh theo từng chủ đề (đồng ý, quyền chủ thể, hồ sơ đánh giá tác động, chuyển dữ liệu ra nước ngoài); cần xác minh điều khoản hiệu lực và phạm vi còn áp dụng sau khi Luật 91/2025/QH15 và Nghị định 356/2025/NĐ-CP có hiệu lực.",
    "newSummary": " Luật 91/2025/QH15 và Nghị định 356/2025/NĐ-CP có hiệu lực từ 01/01/2026 theo nguồn chính thức đã kiểm tra. Nghị định 356 là văn bản quy định chi tiết/hướng dẫn thi hành luật mới. Chỉ kết luận quy định cũ bị bãi bỏ hoặc tiếp tục áp dụng khi viện dẫn chính xác điều khoản thi hành/chuyển tiếp của hai văn bản.",
    "description": "Bổ sung luật và nghị định hướng dẫn về bảo vệ dữ liệu cá nhân; cập nhật hồ sơ và quy trình xử lý dữ liệu theo vai trò thực tế.",
    "departments": "Pháp chế; IT; Data; bảo mật; nhân sự; kinh doanh",
    "processes": "Lập bản đồ dữ liệu; phân loại vai trò; quản lý căn cứ xử lý; kiểm soát nhà cung cấp; xử lý yêu cầu chủ thể dữ liệu; lưu hồ sơ.",
    "rationale": "Có thể ảnh hưởng trực tiếp nếu Nexora thu thập, lưu trữ, sử dụng hoặc chia sẻ dữ liệu cá nhân.",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "LUẬT THAY ĐỔI ",
      "column": "G"
    }
  },
  {
    "id": "LC07",
    "before": "Luật An ninh mạng 24/2018/QH14 và các văn bản hướng dẫn liên quan",
    "after": "L02 – 116/2025/QH15; L26 – 330/2026/NĐ-CP, L28 – 333/2026/NĐ-CP",
    "scope": "Đối chiếu riêng điều khoản hiệu lực, chuyển tiếp và quy định xử phạt của Luật 116/2025/QH15 với Nghị định 53/2022/NĐ-CP và văn bản xử phạt liên quan. Nghị định 330/2026/NĐ-CP cần được mô tả đúng theo tên/phạm vi của văn bản trong sheet tài liệu; không tự suy luận rằng nghị định này thay thế toàn bộ Nghị định 53/2022/NĐ-CP.",
    "oldSummary": "Trước khi Luật 116/2025/QH15 có hiệu lực, các nghĩa vụ an ninh mạng được xác định từ Luật 24/2018/QH14 và văn bản hướng dẫn như Nghị định 53/2022/NĐ-CP; chế tài hành chính phải tra đúng nghị định xử phạt tương ứng với hành vi. Không gộp quy định nghĩa vụ và mức phạt vào cùng một căn cứ.",
    "newSummary": " Luật 116/2025/QH15 có hiệu lực 01/07/2026; hồ sơ dữ liệu ghi Nghị định 330/2026/NĐ-CP có hiệu lực 19/08/2026. Cần xác minh trực tiếp phạm vi điều chỉnh của Nghị định 330 và các điều khoản xử phạt/thi hành trước khi gắn với một hành vi cụ thể của Nexora. Nghị định 333/2026/NĐ-CP quy định chi tiết một số điều và biện pháp thi hành Luật An ninh mạng.",
    "description": "Cập nhật khung an ninh mạng và chế tài; xây dựng ma trận nghĩa vụ–rủi ro–mức xử phạt dựa trên điều khoản gốc.",
    "departments": "Pháp chế; IT; an ninh mạng; bảo mật; quản trị rủi ro",
    "processes": "Kiểm soát truy cập; quản lý sự cố; lưu log; đánh giá nhà cung cấp; lưu bằng chứng tuân thủ và quy trình khắc phục.",
    "rationale": "Giúp xác định nghĩa vụ bảo mật và rủi ro chế tài; mức phạt phải gắn với hành vi cụ thể.",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "LUẬT THAY ĐỔI ",
      "column": "H"
    }
  },
  {
    "id": "LC08",
    "before": "Luật Công nghệ cao trước đây ",
    "after": "L27 – 133/2025/QH15",
    "scope": "Đây là hồ sơ rà soát luật mới, không nên gọi là “sửa đổi Luật Công nghệ cao” nếu không tìm thấy điều khoản sửa đổi trực tiếp. Đối chiếu Luật 133/2025/QH15 với luật công nghệ cao trước đó theo chủ đề, phạm vi, chính sách/điều kiện và điều khoản chuyển tiếp; ghi rõ là so sánh chính sách nếu không có cặp điều khoản tương ứng.",
    "oldSummary": "Chưa xác định được điều khoản cũ tương ứng. Không trích một điều bất kỳ của Luật Công nghệ cao cũ để tạo thành cặp sửa đổi giả. Ghi nhận đây là văn bản cũ tham chiếu theo chủ đề, không phải văn bản bị sửa đổi trực tiếp trừ khi luật mới có quy định rõ.",
    "newSummary": " Luật 133/2025/QH15 được đưa vào danh mục để rà soát phạm vi liên quan tới hoạt động công nghệ cao. Trích nguyên văn từ PDF chính thức tại Công báo sau khi xác định điều khoản có tác động thực tế; hiện không ghi số điều cụ thể khi chưa xác minh được toàn văn và quan hệ sửa đổi/thay thế.",
    "description": "Bổ sung luật nền về công nghệ cao; xác định phạm vi liên quan dựa trên hoạt động/sản phẩm cụ thể của Nexora.",
    "departments": "Ban lãnh đạo; sản phẩm; R&D; pháp chế; tài chính",
    "processes": "Rà soát ngành nghề/sản phẩm; kiểm tra điều kiện chính sách và hồ sơ chứng minh hoạt động công nghệ.",
    "rationale": "Có thể liên quan nếu hoạt động của Nexora thuộc phạm vi điều chỉnh hoặc điều kiện chính sách trong luật.",
    "origin": {
      "file": "SOS.xlsx",
      "sheet": "LUẬT THAY ĐỔI ",
      "column": "I"
    }
  }
];
