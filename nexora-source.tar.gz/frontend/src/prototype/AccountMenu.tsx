import {enterprise,currentIdentity} from './enterprise';
import type {WorkspaceState} from './workspaces';
import {useDepartments} from './EnterpriseContext';
import { useEffect, useRef, useState } from 'react';
import { Icon } from './ui';
import { roleLabels, identity, headDepartments } from './permissions';
import type { Role } from './permissions';
import { departments } from './workflow';
import type { Department } from './workflow';
import type { Locale } from './demo';
export default function AccountMenu({state,role,department,locale,changeRole,changeDepartment,onAccount,dark,changeLocale,toggleTheme}: {state:WorkspaceState;role:Role;department:Department;locale:Locale;changeRole:(role:Role)=>void;changeDepartment:(department:Department)=>void;onAccount:(mode:'login'|'register')=>void;dark:boolean;changeLocale:(locale:Locale)=>void;toggleTheme:()=>void}) {
  const ref=useRef<HTMLDetailsElement>(null);
  const [expanded,setExpanded]=useState(false);
  const user=currentIdentity(state),departments=useDepartments();
  const t=(vi:string,en:string)=>locale==='vi'?vi:en;
  function close(){if(ref.current)ref.current.open=false;setExpanded(false);ref.current?.querySelector('summary')?.focus();}
  useEffect(()=>{function outside(e:PointerEvent){if(ref.current&&!ref.current.contains(e.target as Node)){ref.current.open=false;setExpanded(false);}}document.addEventListener('pointerdown',outside);return()=>document.removeEventListener('pointerdown',outside);},[]);
  return <details className="account-menu" ref={ref} onToggle={e=>{if(!e.currentTarget.open)setExpanded(false);}} onKeyDown={e=>{if(e.key==='Escape'){e.preventDefault();close();}}}>
    <summary aria-label={t('Mở tài khoản demo','Open demo account')}><span className="avatar"><Icon name="user" size={24}/></span><span className="account-name">{user.name}<small>{roleLabels[role][locale]}</small></span><span aria-hidden="true">⌄</span></summary>
    <div className="account-dropdown">
      <div className="account-identity"><strong>{user.name}</strong><span>{roleLabels[role][locale]}</span><small>{t('Danh tính mẫu · Chưa đăng nhập','Synthetic identity · Not signed in')}</small></div>
      <button className="role-expander" aria-expanded={expanded} onClick={()=>setExpanded(!expanded)}>{t('Chuyển vai trò demo','Switch demo role')}<Icon name="chevron" size={18}/></button>
      {expanded&&<div className="role-options">{(Object.keys(roleLabels) as Role[]).map(r=><button key={r} aria-pressed={role===r} onClick={()=>{changeRole(r);close();}}><span>{roleLabels[r][locale]}</span>{role===r&&<Icon name="check" size={18}/>}</button>)}</div>}
      {role==='department'&&<label className="account-department">{t('Bộ phận phụ trách','Managed department')}<select value={department} onChange={e=>{changeDepartment(e.target.value as Department);close();}}>{enterprise(state).departments.filter(d=>d.headId||d.id===department).map(record=>{const d=record.id;return <option value={d} key={d}>{departments[d][locale]}</option>;})}</select></label>}
      <div className="account-preferences"><label>{t('Ngôn ngữ','Language')}<select value={locale} onChange={e=>changeLocale(e.target.value as Locale)}><option value="vi">Tiếng Việt</option><option value="en">English</option></select></label><button onClick={toggleTheme}><Icon name={dark?'sun':'moon'} size={16}/>{t(dark?'Bật chế độ sáng':'Bật chế độ tối',dark?'Use light mode':'Use dark mode')}</button></div>
      <div className="account-links">{(['login','register'] as const).map(mode=><button key={mode} onClick={()=>{close();onAccount(mode);}}>{mode==='login'?t('Đăng nhập','Login'):t('Đăng ký','Register')}</button>)}</div>
    </div>
  </details>;
}
