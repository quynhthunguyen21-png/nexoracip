import {workingFiles} from './presentationCases';
export function downloadWorkingFile(key:keyof typeof workingFiles){const f=workingFiles[key],u=URL.createObjectURL(new Blob([f.text],{type:'text/plain;charset=utf-8'})),a=document.createElement('a');a.href=u;a.download=f.name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}
