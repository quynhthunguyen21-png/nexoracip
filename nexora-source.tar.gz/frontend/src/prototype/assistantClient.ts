import {caseContext} from './presentationCases.ts';
import {skillContext,validSkillResult} from './skillsClient.ts';
import {providerError} from './aiErrors.ts';
import {enterprise} from './enterprise.ts';
import type {WorkspaceState} from './workspaces.ts';
import type {Locale} from './demo.ts';
import type {Skill,SkillResult,AIProvider} from './skillsClient.ts';
export interface ChatResult {provider?:AIProvider;proposed_actions?:SkillResult['actions'];answer:string;citations:{document_id:string;quote:string}[];record_ids:string[];missing_information:string[];next_steps:{label:string;page:'documents'|'review'|'tasks'|'company'|'contracts'}[]}
export interface ContractResult {summary:string;company_fit:string;findings:{title:string;category:'attention'|'clarify'|'information_gap';contract_quote:string;explanation:string;recommendation:string}[];citations:{document_id:string;quote:string}[];missing_information:string[];limitations:string[]}
export const CONTRACT_LIMIT=5*1024*1024;
export function contractFileAllowed(name:string,size:number){return /\.(pdf|docx|txt)$/i.test(name)&&size>0&&size<=CONTRACT_LIMIT&&name.length<=200;}
export async function contractPayload(file:File){
 if(!contractFileAllowed(file.name,file.size))throw Error('PDF / DOCX / TXT · ≤ 5 MiB');
 const bytes=new Uint8Array(await file.arrayBuffer());let preview='';
 if(/\.pdf$/i.test(file.name)&&new TextDecoder().decode(bytes.slice(0,5))!=='%PDF-')throw Error('PDF không hợp lệ / Invalid PDF');
 if(/\.docx$/i.test(file.name)&&(bytes[0]!==80||bytes[1]!==75))throw Error('DOCX không hợp lệ / Invalid DOCX');
 if(/\.txt$/i.test(file.name)){preview=new TextDecoder('utf-8',{fatal:true}).decode(bytes);if(!preview.trim()||preview.includes('\0')||preview.length>60000)throw Error('TXT UTF-8 · ≤ 60000 ký tự / characters');}
 let binary='';for(let i=0;i<bytes.length;i+=16384)binary+=String.fromCharCode(...bytes.subarray(i,i+16384));
 return {filename:file.name.replace(/[\\/\x00-\x1f]/g,'_'),file_base64:btoa(binary),preview};
}
function strings(x:unknown,max:number){return Array.isArray(x)&&x.length<=max&&x.every(v=>typeof v==='string'&&v.length<=6000);}
function citations(x:unknown,id:string,excerpt:string){return Array.isArray(x)&&x.length<=10&&x.every(c=>c&&c.document_id===id&&typeof c.quote==='string'&&!!c.quote&&excerpt.includes(c.quote));}
export function validChatResult(v:unknown,id:string,excerpt:string,ids:string[]):v is ChatResult{if(!v||typeof v!=='object')return false;const r=v as ChatResult;return (r.proposed_actions===undefined||validSkillResult({summary:r.answer,findings:[],missing_information:[],citations:[],actions:r.proposed_actions,evidence_assessment:'not_assessed'}))&&typeof r.answer==='string'&&!!r.answer.trim()&&r.answer.length<=6000&&citations(r.citations,id,excerpt)&&strings(r.record_ids,20)&&r.record_ids.every(x=>ids.includes(x))&&strings(r.missing_information,10)&&Array.isArray(r.next_steps)&&r.next_steps.length<=3&&r.next_steps.every(n=>n&&typeof n.label==='string'&&n.label.length<=120&&['documents','review','tasks','company','contracts'].includes(n.page));}
export function validContractResult(v:unknown,id:string,excerpt:string,contractText?:string):v is ContractResult{if(!v||typeof v!=='object')return false;const r=v as ContractResult;return typeof r.summary==='string'&&!!r.summary.trim()&&r.summary.length<=5000&&typeof r.company_fit==='string'&&r.company_fit.length<=3000&&citations(r.citations,id,excerpt)&&strings(r.missing_information,15)&&strings(r.limitations,10)&&r.limitations.length>0&&Array.isArray(r.findings)&&r.findings.length<=15&&r.findings.every(f=>f&&['title','contract_quote','explanation','recommendation'].every(k=>typeof f[k as 'title']==='string')&&['attention','clarify','information_gap'].includes(f.category)&&(!contractText||!f.contract_quote||contractText.includes(f.contract_quote)));}
async function call(path:string,body:object,state:WorkspaceState,locale:Locale,signal:AbortSignal|undefined){
 const r=await fetch('/api/assistant/'+path,{method:'POST',headers:{'Content-Type':'application/json','X-Nexora-Client':'workspace'},body:JSON.stringify(body),signal});
 if(!r.ok)throw Error(await providerError(r,locale)||(locale==='vi'?(r.status===503?'Chưa cấu hình AI ở backend. Nội dung chưa được gửi tới AI.':r.status===422?'Kiểm tra tệp và quyền gửi dữ liệu. Gemini hỗ trợ PDF/TXT; hãy chuyển DOCX sang PDF.':r.status===429?'AI đang bận hoặc đã chạm hạn mức. Kiểm tra quota rồi thử lại sau.':`Không xử lý được (${r.status}). Có thể thử lại.`):(r.status===503?'AI is not configured on the backend. Content was not sent to AI.':r.status===422?'Check file and sharing consent. For Gemini, convert DOCX to PDF or TXT.':`Request failed (${r.status}). You can retry.`)));
 const raw:unknown=await r.json();if(!raw||typeof raw!=='object')throw Error('Invalid response');const value=raw as Record<string,unknown>;if(!['openai','gemini'].includes(String(value.provider))||value.review_status!=='unreviewed'||value.company_revision!==enterprise(state).profile.revision)throw Error(locale==='vi'?'Kết quả không khớp ngữ cảnh.':'Response does not match context.');return value;
}
export async function chatRequest(state:WorkspaceState,id:string,locale:Locale,question:string,skill:Skill,messages:{role:'user'|'assistant';content:string}[],excerpt:string,signal?:AbortSignal,caseId=''):Promise<ChatResult>{
 const tasks=state.tasks.filter(t=>state.role!=='department'||t.department===state.department).slice(0,100).map(t=>({id:t.id,title:t.title[locale],department:t.department,status:t.status,due:t.due}));
 const result=await call('chat',{company:skillContext(state),document_id:id,locale,question,skill,messages:messages.slice(-12),tasks,source_excerpt:excerpt,context_at:new Date().toISOString(),...(caseId?{case_context:await caseContext(caseId)}:{})},state,locale,signal);
 if(result.document_id!==id||!validChatResult(result.result,id,excerpt,[id,...tasks.map(t=>t.id)]))throw Error(locale==='vi'?'Căn cứ hoặc nội dung phản hồi không hợp lệ.':'Response or references could not be validated.');return {...result.result,provider:result.provider as AIProvider};
}
export async function reviewContract(state:WorkspaceState,id:string,locale:Locale,file:{filename:string;file_base64:string;preview:string},excerpt:string,focus:string,signal?:AbortSignal){
 const data=await call('contracts/review',{company:skillContext(state),document_id:id,locale,filename:file.filename,file_base64:file.file_base64,source_excerpt:excerpt,focus,consent_to_send:true},state,locale,signal);
 if(data.document_id!==id||!validContractResult(data.result,id,excerpt,file.preview||undefined))throw Error(locale==='vi'?'Không xác minh được trích dẫn trả về.':'Returned quotations could not be validated.');return {result:data.result as ContractResult,fileQuoteVerification:data.file_quote_verification as string};
}
