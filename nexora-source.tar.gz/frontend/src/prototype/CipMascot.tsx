import {useState} from 'react';
import type {Locale} from './demo';
import mascot from '../assets/cip-assistant-robot.png';
const greetingKey='nexora-cip-mascot-greeting-dismissed';
export default function CipMascot({locale,open}:{locale:Locale;open:()=>void}){
 const label=locale==='vi'?'Mở Trợ lý AI CIP':'Open CIP AI Assistant';
 const [greeting,setGreeting]=useState(()=>{try{return sessionStorage.getItem(greetingKey)!=='yes';}catch{return true;}});
 function dismiss(){setGreeting(false);try{sessionStorage.setItem(greetingKey,'yes');}catch{/* Optional session preference; closing still works. */}}
 return <div className="cip-launcher">
  {greeting&&<div className="cip-greeting"><p>{locale==='vi'?'Cần hỗ trợ? Hỏi CIP nhé!':'Need a hand? Ask CIP!'}</p><button type="button" className="cip-greeting-close" onClick={dismiss} aria-label={locale==='vi'?'Đóng lời chào CIP':'Dismiss CIP greeting'} title={locale==='vi'?'Thu gọn lời chào':'Hide greeting'}>×</button></div>}
  <button type="button" className="cip-mascot" onClick={open} aria-label={label} title={label}><img src={mascot} alt="" aria-hidden="true" draggable={false}/><span>{locale==='vi'?'Trợ lý AI CIP':'CIP AI Assistant'}</span></button>
 </div>;
}
