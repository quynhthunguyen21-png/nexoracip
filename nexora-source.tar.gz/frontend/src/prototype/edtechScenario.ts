/** User-supplied test scenario, received 2026-10-21. Not retrieved from Jira; linked by the owner to KAN-10; Jira content is not independently retrieved. */
export const edtechScenarioIssue='KAN-10';
export const edtechScenarioTitle='Kiến trúc EdTech: sinh trắc học, thanh toán, bản quyền và dữ liệu xuyên biên giới';
export const edtechScenario=`1. KIẾN TRÚC ĐỊNH DANH SINH TRẮC HỌC & GIÁM SÁT AI TẬP TRUNG
• Cơ chế thu thập dữ liệu ngầm: Tích hợp trực tiếp bộ công cụ phát triển phần mềm (SDK AI) vào hệ thống camera, thiết bị học tập thông minh và ứng dụng mobile tại 500+ trường học/trung tâm đối tác.
• Tần suất và loại dữ liệu thu thập:
- Tự động kích hoạt camera/mic ngầm với tần suất 5-10 giây/lần.
- Thu thập và trích xuất dữ liệu mô hình khuôn mặt 3D (Face ID), nhận diện vi biểu cảm (micro-expressions), theo dõi võng mạc (eye-tracking), chuyển động đầu và phân tích tần số âm thanh giọng nói của học sinh (độ tuổi từ 6 đến 11 tuổi).
- Thu thập toàn bộ dữ liệu vị trí GPS, lịch sử truy cập thiết bị cá nhân của học sinh và phụ huynh.
• Mục đích xử lý & Thương mại hóa:
- Dữ liệu sinh trắc học và hồ sơ tâm lý học sinh được đồng bộ realtime để tính toán "Chỉ số trung thực & Độ tập trung AI".
- Tự động đóng gói, chia sẻ và bán lại gói dữ liệu hồ sơ hành vi người dùng (User Behavioral Data) cho các bên thứ ba gồm: Công ty nghiên cứu thị trường, Quỹ đầu tư EdTech, Đơn vị phát hành quảng cáo targeted-ads.
- Hệ thống KHÔNG gửi thông báo, KHÔNG xây dựng biểu mẫu xin ý kiến đồng ý (Consent) riêng biệt từ cha mẹ hoặc người giám hộ hợp pháp của trẻ em.
• Thời hạn & Phương thức lưu trữ: Toàn bộ dữ liệu sinh trắc học thô (Raw Biometric Data) và video ghi hình được lưu trữ vĩnh viễn trên hệ thống Cloud, không cung cấp tính năng cho phép phụ huynh yêu cầu chỉnh sửa hoặc xóa bỏ dữ liệu.

2. CƠ CHẾ THANH TOÁN B2B2C, ĐIỀU KIỆN GIA HẠN CƯỠNG ÉP & PHẠT VI PHẠM
• Tự động trích nợ định kỳ (Auto-debit / Recurring Billing):
- Tích hợp cổng thanh toán tự động Nexora Pay với các tài khoản ngân hàng, thẻ credit/debit và ví điện tử của phụ huynh cùng các trường học liên kết.
- Tự động gia hạn gói cước theo chu kỳ tháng/năm. Quá trình trừ tiền diễn ra hoàn toàn tự động mà KHÔNG cần gửi mã xác thực OTP, KHÔNG gửi tin nhắn/email thông báo trước hoặc sau khi giao dịch hoàn tất.
• Chính sách chấm dứt hợp đồng & Phạt vi phạm bất bình đẳng:
- Trường hợp khách hàng hoặc doanh nghiệp đối tác gửi yêu cầu hủy dịch vụ trước thời hạn hợp đồng, hệ thống sẽ tự động niêm phong, khóa quyền truy cập và xóa toàn bộ dữ liệu quản lý/học tập của đơn vị đó.
- Áp dụng chế tài phạt 30% trên tổng giá trị hợp đồng còn lại, đồng thời mặc định KHÔNG hoàn trả bất kỳ khoản tiền trả trước nào dưới mọi hình thức.
• Điều khoản miễn trừ trách nhiệm tuyệt đối (Liability Limitation):
- Quy chế sử dụng dịch vụ mặc định tuyên bố Nexora Digital hoàn toàn miễn trừ mọi nghĩa vụ bồi thường thiệt hại tài chính, pháp lý trong các trường hợp: Hệ thống bị tấn công gây rò rỉ dữ liệu cá nhân, gián đoạn vận hành, hoặc phát sinh các giao dịch trích nợ sai sót/trùng lặp.

3. SÀN GIAO DỊCH TRI THỨC SỐ & TỰ ĐỘNG TƯỚC ĐẠT QUYỀN SỞ HỮU TRÍ TUỆ
• Cơ chế tự động chuyển giao bản quyền (IP Transfer Clause):
- Mọi bài giảng điện tử, đề thi, giáo án số, video hướng dẫn và tài liệu đào tạo do giáo viên, chuyên gia hoặc các nhà xuất bản/doanh nghiệp đối tác tải lên Sàn giao dịch Tri thức Nexora sẽ tự động chuyển thành Tài sản sở hữu trí tuệ toàn quyền, vĩnh viễn & độc quyền thuộc về Nexora Digital.
- Nexora Digital có toàn quyền biên tập, chỉnh sửa, thương mại hóa, cấp li-xăng (license) hoặc bán lại cho bên thứ ba mà KHÔNG phải trích trả bất kỳ khoản phí bản quyền, tác quyền hay phân chia doanh thu nào cho tác giả gốc.
• Chối bỏ nghĩa vụ kiểm duyệt & Trách nhiệm pháp lý:
- Nexora Digital thiết lập cơ chế KHÔNG rà soát, KHÔNG kiểm duyệt nội dung, KHÔNG xác minh nguồn gốc bản quyền đối với các sản phẩm được niêm yết mua bán trên sàn.
- Trường hợp phát sinh tranh chấp bản quyền, khiếu nại sở hữu trí tuệ hoặc nội dung vi phạm thuần phong mỹ tục/chính trị từ tài liệu được tải lên, cá nhân/doanh nghiệp đăng tải nội dung đó phải tự chịu toàn bộ trách nhiệm trước cơ quan quản lý và pháp luật, Nexora hoàn toàn đứng ngoài tranh chấp.

4. CHUYỂN TẢI DỮ LIỆU XUYÊN BIÊN GIỚI & LƯU TRỮ TRỰC TIẾP TẠI NƯỚC NGOÀI
• Kiến trúc luồng dữ liệu xuyên biên giới:
- Toàn bộ dữ liệu thô (Raw Data) hệ thống thu thập tại Việt Nam — bao gồm: Dữ liệu sinh trắc học khuôn mặt/giọng nói học sinh, dữ liệu định danh Căn cước công dân, dữ liệu tài khoản ngân hàng/ví điện tử, biến động tài chính của phụ huynh và các trường học đối tác — sẽ được đồng bộ trực tiếp về cụm máy chủ Cloud tính toán hiệu năng cao (GPU Clusters) đặt tại Singapore và Hoa Kỳ để huấn luyện AI.
• Hạ tầng & Nghĩa vụ lưu trữ nội địa:
- Nhằm tối ưu hóa 45% chi phí đầu tư hạ tầng và vận hành, hệ thống KHÔNG duy trì bất kỳ máy chủ lưu trữ bản sao dữ liệu (Local Backup Server) nào tại lãnh thổ Việt Nam.
• Bỏ qua quy trình quản lý hành chính:
- Dự án KHÔNG tiến hành lập Hồ sơ Đánh giá tác động chuyển dữ liệu cá nhân ra nước ngoài (DPIA).
- KHÔNG thực hiện đăng ký hay báo cáo đánh giá an ninh mạng với Cục An ninh mạng và phòng, chống tội phạm sử dụng công nghệ cao (A05 - Bộ Công an) và Cục An toàn thông tin.`;
