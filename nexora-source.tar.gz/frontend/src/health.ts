/** A connection is valid only after successful HTTP and the health contract. */
export async function checkHealth(signal: AbortSignal, request: typeof fetch = fetch): Promise<void> {
  const response = await request('/api/health', {
    signal,
    cache: 'no-store',
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`Backend trả lỗi HTTP ${response.status}.`);
  let body: unknown;
  try { body = await response.json(); }
  catch { throw new Error('Backend không trả JSON hợp lệ.'); }
  if (typeof body !== 'object' || body === null || Array.isArray(body)
    || !('status' in body) || body.status !== 'ok') {
    throw new Error('Phản hồi health không đúng định dạng.');
  }
}
