import { useEffect, useState } from 'react';
import { checkHealth } from './health';
export default function HealthPanel({ en }: { en: boolean }) {
  const [connection, setConnection] = useState<'loading' | 'connected' | 'error'>('loading');
  const [message, setMessage] = useState('');
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    const controller = new AbortController(); let active = true; let timedOut = false;
    setConnection('loading');
    const timeout = window.setTimeout(() => { timedOut = true; controller.abort(); }, 8000);
    checkHealth(controller.signal).then(() => { if (active) { setConnection('connected'); setMessage('status: ok'); } }).catch((error: unknown) => {
      if (active) { setConnection('error'); setMessage(timedOut ? (en ? 'Backend timeout (8s)' : 'Hết thời gian chờ backend (8 giây)') : en ? 'Health request failed. Check that the backend is running.' : error instanceof Error ? error.message : 'Lỗi kết nối'); }
    }).finally(() => window.clearTimeout(timeout));
    return () => { active = false; window.clearTimeout(timeout); controller.abort(); };
  }, [attempt, en]);
  return <div className="health-box"><span className={`health-dot ${connection}`} /><span>{connection === 'loading' ? (en ? 'Checking backend…' : 'Đang kiểm tra backend…') : connection === 'connected' ? 'Backend · status: ok' : (en ? 'Backend unavailable' : 'Backend chưa kết nối')}</span><button className="text-button" onClick={() => setAttempt(n => n + 1)} disabled={connection === 'loading'}>{en ? 'Retry' : 'Thử lại'}</button><small>{message} · {en ? 'Liveness only. The demo works independently.' : 'Chỉ liveness. Demo chạy độc lập.'}</small></div>;
}
