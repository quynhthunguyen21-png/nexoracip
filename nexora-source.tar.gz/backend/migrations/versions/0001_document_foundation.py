"""document_foundation

Revision ID: 0001
Revises: none
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '0001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    # Reviewed initial schema. Triggers below implement cross-row history rules.
    op.create_table('document_blobs',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('sha256', sa.String(length=64), nullable=False),
    sa.Column('byte_size', sa.BigInteger(), nullable=False),
    sa.Column('storage_key', sa.Text(), nullable=False),
    sa.Column('media_type', sa.Text(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    sa.CheckConstraint("sha256 ~ '^[0-9a-f]{64}$'", name=op.f('ck_document_blobs_sha256_format')),
    sa.CheckConstraint("storage_key ~ '^[A-Za-z0-9_-]+(/[A-Za-z0-9_.-]+)*$' AND storage_key !~ '(^|/)\\.\\.?(/|$)'", name=op.f('ck_document_blobs_safe_storage_key')),
    sa.CheckConstraint('byte_size >= 0', name=op.f('ck_document_blobs_byte_size_nonnegative')),
    sa.CheckConstraint('length(btrim(media_type)) > 0', name=op.f('ck_document_blobs_media_type_nonempty')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_document_blobs')),
    sa.UniqueConstraint('sha256', name=op.f('uq_document_blobs_sha256')),
    sa.UniqueConstraint('storage_key', name=op.f('uq_document_blobs_storage_key'))
    )
    op.create_table('legal_documents',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('display_label', sa.Text(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    sa.CheckConstraint('length(btrim(display_label)) > 0', name=op.f('ck_legal_documents_label_nonempty')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_legal_documents'))
    )
    op.create_table('document_versions',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('document_id', sa.UUID(), nullable=False),
    sa.Column('sequence', sa.Integer(), nullable=False),
    sa.Column('blob_id', sa.UUID(), nullable=False),
    sa.Column('baseline_version_id', sa.UUID(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    sa.CheckConstraint('baseline_version_id IS NULL OR baseline_version_id <> id', name=op.f('ck_document_versions_baseline_not_self')),
    sa.CheckConstraint('sequence > 0', name=op.f('ck_document_versions_sequence_positive')),
    sa.ForeignKeyConstraint(['baseline_version_id', 'document_id'], ['document_versions.id', 'document_versions.document_id'], name='fk_document_versions_baseline_same_document', ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['blob_id'], ['document_blobs.id'], name=op.f('fk_document_versions_blob_id_document_blobs'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['document_id'], ['legal_documents.id'], name=op.f('fk_document_versions_document_id_legal_documents'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_document_versions')),
    sa.UniqueConstraint('document_id', 'sequence', name='uq_document_versions_document_sequence'),
    sa.UniqueConstraint('id', 'blob_id', name='uq_document_versions_id_blob'),
    sa.UniqueConstraint('id', 'document_id', name='uq_document_versions_id_document')
    )
    op.create_index('ix_document_versions_baseline_version_id', 'document_versions', ['baseline_version_id'], unique=False)
    op.create_index('ix_document_versions_blob_id', 'document_versions', ['blob_id'], unique=False)
    op.create_table('document_sources',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('blob_id', sa.UUID(), nullable=False),
    sa.Column('version_id', sa.UUID(), nullable=True),
    sa.Column('ingestion_method', sa.Text(), nullable=False),
    sa.Column('original_filename', sa.Text(), nullable=False),
    sa.Column('original_url', sa.Text(), nullable=True),
    sa.Column('collected_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('collected_by', sa.Text(), nullable=True),
    sa.Column('received_by', sa.Text(), nullable=False),
    sa.Column('received_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    sa.Column('provenance_state', sa.Text(), server_default='missing', nullable=False),
    sa.Column('permission_state', sa.Text(), server_default='unknown', nullable=False),
    sa.Column('source_values', postgresql.JSONB(astext_type=sa.Text()), server_default=sa.text("'{}'::jsonb"), nullable=False),
    sa.CheckConstraint("ingestion_method IN ('manual_upload','automated_ingestion')", name=op.f('ck_document_sources_ingestion_method')),
    sa.CheckConstraint("jsonb_typeof(source_values) = 'object'", name=op.f('ck_document_sources_source_values_object')),
    sa.CheckConstraint("original_url IS NULL OR (original_url ~ '^https?://' AND original_url !~ '^https?://[^/]*@')", name=op.f('ck_document_sources_source_url_no_userinfo')),
    sa.CheckConstraint("permission_state IN ('unknown','review_required','documented')", name=op.f('ck_document_sources_permission_state')),
    sa.CheckConstraint("provenance_state IN ('missing','unverified','verified','conflicting')", name=op.f('ck_document_sources_provenance_state')),
    sa.CheckConstraint('length(btrim(original_filename)) > 0 AND length(btrim(received_by)) > 0', name=op.f('ck_document_sources_intake_labels_nonempty')),
    sa.ForeignKeyConstraint(['blob_id'], ['document_blobs.id'], name=op.f('fk_document_sources_blob_id_document_blobs'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['version_id', 'blob_id'], ['document_versions.id', 'document_versions.blob_id'], name='fk_document_sources_version_same_blob', ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_document_sources')),
    sa.UniqueConstraint('id', 'version_id', name='uq_document_sources_id_version')
    )
    op.create_index('ix_document_sources_blob_id_received_at', 'document_sources', ['blob_id', 'received_at'], unique=False)
    op.create_index('ix_document_sources_version_id', 'document_sources', ['version_id'], unique=False)
    op.create_table('metadata_revisions',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('version_id', sa.UUID(), nullable=False),
    sa.Column('revision', sa.Integer(), nullable=False),
    sa.Column('source_values', postgresql.JSONB(astext_type=sa.Text()), server_default=sa.text("'{}'::jsonb"), nullable=False),
    sa.Column('extracted_values', postgresql.JSONB(astext_type=sa.Text()), server_default=sa.text("'{}'::jsonb"), nullable=False),
    sa.Column('human_corrections', postgresql.JSONB(astext_type=sa.Text()), server_default=sa.text("'{}'::jsonb"), nullable=False),
    sa.Column('selected_values', postgresql.JSONB(astext_type=sa.Text()), server_default=sa.text("'{}'::jsonb"), nullable=False),
    sa.Column('issued_on', sa.Date(), nullable=True),
    sa.Column('effective_on', sa.Date(), nullable=True),
    sa.Column('document_class', sa.Text(), nullable=True),
    sa.Column('validation_state', sa.Text(), server_default='unverified', nullable=False),
    sa.Column('actor_kind', sa.Text(), nullable=False),
    sa.Column('actor_subject', sa.Text(), nullable=True),
    sa.Column('correction_reason', sa.Text(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    sa.CheckConstraint("actor_kind = 'system' OR length(btrim(coalesce(actor_subject,''))) > 0", name=op.f('ck_metadata_revisions_human_actor_required')),
    sa.CheckConstraint("actor_kind IN ('system','human','test')", name=op.f('ck_metadata_revisions_actor_kind')),
    sa.CheckConstraint("document_class IS NULL OR document_class IN ('normative','official_other','draft','unknown')", name=op.f('ck_metadata_revisions_document_class')),
    sa.CheckConstraint("jsonb_typeof(source_values) = 'object' AND jsonb_typeof(extracted_values) = 'object' AND jsonb_typeof(human_corrections) = 'object' AND jsonb_typeof(selected_values) = 'object'", name=op.f('ck_metadata_revisions_metadata_layers_objects')),
    sa.CheckConstraint("validation_state IN ('unverified','needs_review','validated','blocked','rejected')", name=op.f('ck_metadata_revisions_validation_state')),
    sa.CheckConstraint('revision > 0', name=op.f('ck_metadata_revisions_revision_positive')),
    sa.ForeignKeyConstraint(['version_id'], ['document_versions.id'], name=op.f('fk_metadata_revisions_version_id_document_versions'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_metadata_revisions')),
    sa.UniqueConstraint('version_id', 'revision', name='uq_metadata_revisions_version_revision')
    )
    op.create_index('ix_metadata_revisions_validation_state_created_at', 'metadata_revisions', ['validation_state', 'created_at'], unique=False)
    op.create_table('article_references',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('version_id', sa.UUID(), nullable=False),
    sa.Column('source_id', sa.UUID(), nullable=True),
    sa.Column('reference_key', sa.Text(), nullable=False),
    sa.Column('locator', postgresql.JSONB(astext_type=sa.Text()), server_default=sa.text("'{}'::jsonb"), nullable=False),
    sa.Column('quote_text', sa.Text(), nullable=False),
    sa.Column('origin', sa.Text(), nullable=False),
    sa.Column('verification_state', sa.Text(), server_default='unverified', nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    sa.CheckConstraint("jsonb_typeof(locator) = 'object' AND locator <> '{}'::jsonb", name=op.f('ck_article_references_locator_object_nonempty')),
    sa.CheckConstraint("origin IN ('manual_entry','source_supplied','extracted')", name=op.f('ck_article_references_reference_origin')),
    sa.CheckConstraint("verification_state IN ('unverified','verified','conflicting')", name=op.f('ck_article_references_verification_state')),
    sa.CheckConstraint('length(btrim(reference_key)) > 0 AND length(btrim(quote_text)) > 0', name=op.f('ck_article_references_reference_content_nonempty')),
    sa.ForeignKeyConstraint(['source_id', 'version_id'], ['document_sources.id', 'document_sources.version_id'], name='fk_article_references_source_same_version', ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['version_id'], ['document_versions.id'], name=op.f('fk_article_references_version_id_document_versions'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_article_references')),
    sa.UniqueConstraint('version_id', 'reference_key', name='uq_article_references_version_key')
    )
    op.create_index('ix_article_references_source_id', 'article_references', ['source_id'], unique=False)
    op.create_table('audit_events',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('document_id', sa.UUID(), nullable=True),
    sa.Column('source_id', sa.UUID(), nullable=True),
    sa.Column('version_id', sa.UUID(), nullable=True),
    sa.Column('metadata_revision_id', sa.UUID(), nullable=True),
    sa.Column('action', sa.Text(), nullable=False),
    sa.Column('actor_kind', sa.Text(), nullable=False),
    sa.Column('actor_subject', sa.Text(), nullable=True),
    sa.Column('changed_fields', postgresql.ARRAY(sa.Text()), server_default=sa.text("'{}'::text[]"), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    sa.CheckConstraint("action IN ('created','linked','validation_changed','review_recorded')", name=op.f('ck_audit_events_action')),
    sa.CheckConstraint("actor_kind = 'system' OR length(btrim(coalesce(actor_subject,''))) > 0", name=op.f('ck_audit_events_human_actor_required')),
    sa.CheckConstraint("actor_kind IN ('system','human','test')", name=op.f('ck_audit_events_actor_kind')),
    sa.CheckConstraint("changed_fields <@ ARRAY['display_label','version_id','baseline_version_id','source_values','extracted_values','human_corrections','selected_values','validation_state','review_state','document_class','issued_on','effective_on']::text[]", name=op.f('ck_audit_events_changed_fields_allowlist')),
    sa.CheckConstraint('num_nonnulls(document_id,source_id,version_id,metadata_revision_id) = 1', name=op.f('ck_audit_events_exactly_one_target')),
    sa.ForeignKeyConstraint(['document_id'], ['legal_documents.id'], name=op.f('fk_audit_events_document_id_legal_documents'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['metadata_revision_id'], ['metadata_revisions.id'], name=op.f('fk_audit_events_metadata_revision_id_metadata_revisions'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['source_id'], ['document_sources.id'], name=op.f('fk_audit_events_source_id_document_sources'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['version_id'], ['document_versions.id'], name=op.f('fk_audit_events_version_id_document_versions'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_audit_events'))
    )
    op.create_index('ix_audit_events_document_id_created_at', 'audit_events', ['document_id', 'created_at'], unique=False)
    op.create_index('ix_audit_events_metadata_revision_id_created_at', 'audit_events', ['metadata_revision_id', 'created_at'], unique=False)
    op.create_index('ix_audit_events_source_id_created_at', 'audit_events', ['source_id', 'created_at'], unique=False)
    op.create_index('ix_audit_events_version_id_created_at', 'audit_events', ['version_id', 'created_at'], unique=False)
    op.create_table('review_events',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('metadata_revision_id', sa.UUID(), nullable=False),
    sa.Column('sequence', sa.Integer(), nullable=False),
    sa.Column('from_state', sa.Text(), nullable=False),
    sa.Column('to_state', sa.Text(), nullable=False),
    sa.Column('actor_kind', sa.Text(), nullable=False),
    sa.Column('actor_subject', sa.Text(), nullable=False),
    sa.Column('note', sa.Text(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    sa.CheckConstraint("(from_state,to_state) IN (('draft','pending'),('pending','approved'),('pending','rejected'),('pending','changes_requested'),('changes_requested','pending'))", name=op.f('ck_review_events_allowed_transition')),
    sa.CheckConstraint("actor_kind IN ('human','test') AND length(btrim(actor_subject)) > 0", name=op.f('ck_review_events_actor_required')),
    sa.CheckConstraint('sequence > 0', name=op.f('ck_review_events_sequence_positive')),
    sa.ForeignKeyConstraint(['metadata_revision_id'], ['metadata_revisions.id'], name=op.f('fk_review_events_metadata_revision_id_metadata_revisions'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_review_events')),
    sa.UniqueConstraint('metadata_revision_id', 'sequence', name='uq_review_events_revision_sequence')
    )
    _install_guards()


def _install_guards():
    op.execute("""
        CREATE FUNCTION nexora_reject_history_mutation() RETURNS trigger
        LANGUAGE plpgsql AS $$
        BEGIN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'Historical records are append-only';
        END;
        $$
    """)
    for table in ('document_blobs', 'document_versions', 'metadata_revisions', 'review_events', 'audit_events'):
        op.execute(f'CREATE TRIGGER {table}_immutable BEFORE UPDATE OR DELETE ON {table} FOR EACH ROW EXECUTE FUNCTION nexora_reject_history_mutation()')
        op.execute(f'CREATE TRIGGER {table}_no_truncate BEFORE TRUNCATE ON {table} FOR EACH STATEMENT EXECUTE FUNCTION nexora_reject_history_mutation()')
    op.execute("""
        CREATE FUNCTION nexora_guard_baseline() RETURNS trigger
        LANGUAGE plpgsql AS $$
        DECLARE baseline_sequence integer;
        BEGIN
            IF NEW.baseline_version_id IS NOT NULL THEN
                SELECT sequence INTO baseline_sequence FROM document_versions
                WHERE id = NEW.baseline_version_id AND document_id = NEW.document_id;
                IF baseline_sequence IS NULL OR baseline_sequence >= NEW.sequence THEN
                    RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'Baseline must be an earlier version of the same document';
                END IF;
            END IF;
            RETURN NEW;
        END;
        $$
    """)
    op.execute('CREATE TRIGGER document_versions_guard_baseline BEFORE INSERT ON document_versions FOR EACH ROW EXECUTE FUNCTION nexora_guard_baseline()')
    op.execute("""
        CREATE FUNCTION nexora_guard_review_sequence() RETURNS trigger
        LANGUAGE plpgsql AS $$
        DECLARE validation text; prior_sequence integer; prior_state text;
        BEGIN
            SELECT validation_state INTO validation FROM metadata_revisions
            WHERE id = NEW.metadata_revision_id FOR UPDATE;
            IF NOT FOUND THEN
                RAISE EXCEPTION USING ERRCODE = '23503', MESSAGE = 'Review revision does not exist';
            END IF;
            SELECT sequence, to_state INTO prior_sequence, prior_state FROM review_events
            WHERE metadata_revision_id = NEW.metadata_revision_id ORDER BY sequence DESC LIMIT 1;
            IF NEW.sequence <> coalesce(prior_sequence, 0) + 1
               OR NEW.from_state <> coalesce(prior_state, 'draft') THEN
                RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'Review must continue the current revision event stream';
            END IF;
            IF NEW.to_state = 'approved' AND validation <> 'validated' THEN
                RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'Unvalidated revision cannot be approved';
            END IF;
            RETURN NEW;
        END;
        $$
    """)
    op.execute('CREATE TRIGGER review_events_guard_sequence BEFORE INSERT ON review_events FOR EACH ROW EXECUTE FUNCTION nexora_guard_review_sequence()')
    op.execute("""
        CREATE FUNCTION nexora_guard_source_snapshot() RETURNS trigger
        LANGUAGE plpgsql AS $$
        BEGIN
            IF TG_OP <> 'UPDATE' THEN
                RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'Source observations cannot be removed';
            END IF;
            IF OLD.version_id IS NOT NULL OR NEW.version_id IS NULL
               OR (to_jsonb(NEW) - 'version_id') IS DISTINCT FROM (to_jsonb(OLD) - 'version_id') THEN
                RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'Only one-time version linking is allowed on a source snapshot';
            END IF;
            RETURN NEW;
        END;
        $$
    """)
    op.execute('CREATE TRIGGER document_sources_snapshot BEFORE UPDATE OR DELETE ON document_sources FOR EACH ROW EXECUTE FUNCTION nexora_guard_source_snapshot()')
    op.execute('CREATE TRIGGER document_sources_no_truncate BEFORE TRUNCATE ON document_sources FOR EACH STATEMENT EXECUTE FUNCTION nexora_reject_history_mutation()')


def downgrade():
    if not op.get_context().opts.get("allow_destructive_test", False):
        raise RuntimeError("Downgrade is restricted to an explicitly authorized test database.")
    # Only an explicitly authorized test target can reach the drop operations.
    op.drop_table('review_events')
    op.drop_index('ix_audit_events_version_id_created_at', table_name='audit_events')
    op.drop_index('ix_audit_events_source_id_created_at', table_name='audit_events')
    op.drop_index('ix_audit_events_metadata_revision_id_created_at', table_name='audit_events')
    op.drop_index('ix_audit_events_document_id_created_at', table_name='audit_events')
    op.drop_table('audit_events')
    op.drop_index('ix_article_references_source_id', table_name='article_references')
    op.drop_table('article_references')
    op.drop_index('ix_metadata_revisions_validation_state_created_at', table_name='metadata_revisions')
    op.drop_table('metadata_revisions')
    op.drop_index('ix_document_sources_version_id', table_name='document_sources')
    op.drop_index('ix_document_sources_blob_id_received_at', table_name='document_sources')
    op.drop_table('document_sources')
    op.drop_index('ix_document_versions_blob_id', table_name='document_versions')
    op.drop_index('ix_document_versions_baseline_version_id', table_name='document_versions')
    op.drop_table('document_versions')
    op.drop_table('legal_documents')
    op.drop_table('document_blobs')
    op.execute('DROP FUNCTION nexora_guard_source_snapshot()')
    op.execute('DROP FUNCTION nexora_guard_review_sequence()')
    op.execute('DROP FUNCTION nexora_guard_baseline()')
    op.execute('DROP FUNCTION nexora_reject_history_mutation()')
