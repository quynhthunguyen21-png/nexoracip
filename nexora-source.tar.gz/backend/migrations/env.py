"""Explicit, identity-checked migrations; never invoked by FastAPI startup."""

from alembic import context
from sqlalchemy.exc import SQLAlchemyError

from backend.app.db.base import Base
from backend.app.db import models  # noqa: F401: registers metadata
from backend.app.db.session import make_engine, verify_database
from backend.app.db.settings import DatabaseSettings

args = context.get_x_argument(as_dictionary=True)
settings = DatabaseSettings.from_environment(args.get("target", "dev"))
target_metadata = Base.metadata
options = {
    "target_metadata": target_metadata,
    "compare_type": True,
    "compare_server_default": True,
    "allow_destructive_test": settings.target == "test" and args.get("allow_destructive_test") == "true",
}

if context.is_offline_mode():
    context.configure(url=settings.url, literal_binds=True, **options)
    with context.begin_transaction():
        context.run_migrations()
else:
    engine = make_engine(settings)
    try:
        with engine.connect() as connection:
            verify_database(connection, settings)
            connection.commit()  # Finish the read-only identity check transaction.
            context.configure(connection=connection, **options)
            with context.begin_transaction():
                context.run_migrations()
    except SQLAlchemyError:
        raise RuntimeError("Database operation failed; connection details and SQL parameters withheld.") from None
    finally:
        engine.dispose()
