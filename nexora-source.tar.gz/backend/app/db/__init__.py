"""Explicit persistence tools; importing this package never creates tables."""
