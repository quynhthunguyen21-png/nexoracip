"""Run explicitly: python -m backend.app.db.check --target dev|test."""

import argparse

from .session import make_engine, verify_database
from .settings import DatabaseSettings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", choices=("dev", "test"), default="dev")
    args = parser.parse_args()
    engine = None
    try:
        settings = DatabaseSettings.from_environment(args.target)
        engine = make_engine(settings)
        with engine.connect() as connection:
            version = verify_database(connection, settings)
        print(f"PASS: local {args.target} database identity verified; PostgreSQL {version}.")
        return 0
    except Exception as error:
        # Never stringify a DBAPI exception: it may contain connection data.
        print(f"BLOCKED: database verification failed ({type(error).__name__}); connection details withheld.")
        return 1
    finally:
        if engine is not None:
            engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
