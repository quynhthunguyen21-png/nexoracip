"""Persistence only. Legal validity and authentication cannot be inferred here."""

import uuid

from sqlalchemy import (
    BigInteger, CheckConstraint, Column, Date, DateTime, ForeignKey,
    ForeignKeyConstraint, Index, Integer, String, Text, UniqueConstraint, func, text,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID

from .base import Base


def identity():
    return Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)


def timestamp():
    return Column(DateTime(timezone=True), nullable=False, server_default=func.now())


def object_json():
    return Column(JSONB, nullable=False, server_default=text("'{}'::jsonb"))


class DocumentBlob(Base):
    __tablename__ = "document_blobs"
    id = identity()
    sha256 = Column(String(64), nullable=False, unique=True)
    byte_size = Column(BigInteger, nullable=False)
    storage_key = Column(Text, nullable=False, unique=True)
    media_type = Column(Text, nullable=False)
    created_at = timestamp()
    __table_args__ = (
        CheckConstraint("sha256 ~ '^[0-9a-f]{64}$'", name="sha256_format"),
        CheckConstraint("byte_size >= 0", name="byte_size_nonnegative"),
        CheckConstraint("storage_key ~ '^[A-Za-z0-9_-]+(/[A-Za-z0-9_.-]+)*$' AND storage_key !~ '(^|/)\\.\\.?(/|$)'", name="safe_storage_key"),
        CheckConstraint("length(btrim(media_type)) > 0", name="media_type_nonempty"),
    )


class LegalDocument(Base):
    __tablename__ = "legal_documents"
    id = identity()
    display_label = Column(Text, nullable=False)
    created_at = timestamp()
    __table_args__ = (CheckConstraint("length(btrim(display_label)) > 0", name="label_nonempty"),)


class DocumentVersion(Base):
    __tablename__ = "document_versions"
    id = identity()
    document_id = Column(UUID(as_uuid=True), ForeignKey("legal_documents.id", ondelete="RESTRICT"), nullable=False)
    sequence = Column(Integer, nullable=False)
    blob_id = Column(UUID(as_uuid=True), ForeignKey("document_blobs.id", ondelete="RESTRICT"), nullable=False)
    baseline_version_id = Column(UUID(as_uuid=True), nullable=True)
    created_at = timestamp()
    __table_args__ = (
        UniqueConstraint("document_id", "sequence", name="uq_document_versions_document_sequence"),
        UniqueConstraint("id", "document_id", name="uq_document_versions_id_document"),
        UniqueConstraint("id", "blob_id", name="uq_document_versions_id_blob"),
        ForeignKeyConstraint(["baseline_version_id", "document_id"], ["document_versions.id", "document_versions.document_id"], ondelete="RESTRICT", name="fk_document_versions_baseline_same_document"),
        CheckConstraint("sequence > 0", name="sequence_positive"),
        CheckConstraint("baseline_version_id IS NULL OR baseline_version_id <> id", name="baseline_not_self"),
        Index("ix_document_versions_blob_id", "blob_id"),
        Index("ix_document_versions_baseline_version_id", "baseline_version_id"),
    )


class DocumentSource(Base):
    __tablename__ = "document_sources"
    id = identity()
    blob_id = Column(UUID(as_uuid=True), ForeignKey("document_blobs.id", ondelete="RESTRICT"), nullable=False)
    version_id = Column(UUID(as_uuid=True), nullable=True)
    ingestion_method = Column(Text, nullable=False)
    original_filename = Column(Text, nullable=False)
    original_url = Column(Text, nullable=True)
    collected_at = Column(DateTime(timezone=True), nullable=True)
    collected_by = Column(Text, nullable=True)
    received_by = Column(Text, nullable=False)
    received_at = timestamp()
    provenance_state = Column(Text, nullable=False, server_default="missing")
    permission_state = Column(Text, nullable=False, server_default="unknown")
    source_values = object_json()
    __table_args__ = (
        UniqueConstraint("id", "version_id", name="uq_document_sources_id_version"),
        ForeignKeyConstraint(["version_id", "blob_id"], ["document_versions.id", "document_versions.blob_id"], ondelete="RESTRICT", name="fk_document_sources_version_same_blob"),
        CheckConstraint("ingestion_method IN ('manual_upload','automated_ingestion')", name="ingestion_method"),
        CheckConstraint("provenance_state IN ('missing','unverified','verified','conflicting')", name="provenance_state"),
        CheckConstraint("permission_state IN ('unknown','review_required','documented')", name="permission_state"),
        CheckConstraint("original_url IS NULL OR (original_url ~ '^https?://' AND original_url !~ '^https?://[^/]*@')", name="source_url_no_userinfo"),
        CheckConstraint("length(btrim(original_filename)) > 0 AND length(btrim(received_by)) > 0", name="intake_labels_nonempty"),
        CheckConstraint("jsonb_typeof(source_values) = 'object'", name="source_values_object"),
        Index("ix_document_sources_blob_id_received_at", "blob_id", "received_at"),
        Index("ix_document_sources_version_id", "version_id"),
    )


class MetadataRevision(Base):
    __tablename__ = "metadata_revisions"
    id = identity()
    version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id", ondelete="RESTRICT"), nullable=False)
    revision = Column(Integer, nullable=False)
    source_values = object_json()
    extracted_values = object_json()
    human_corrections = object_json()
    selected_values = object_json()
    issued_on = Column(Date, nullable=True)
    effective_on = Column(Date, nullable=True)
    document_class = Column(Text, nullable=True)
    validation_state = Column(Text, nullable=False, server_default="unverified")
    actor_kind = Column(Text, nullable=False)
    actor_subject = Column(Text, nullable=True)
    correction_reason = Column(Text, nullable=True)
    created_at = timestamp()
    __table_args__ = (
        UniqueConstraint("version_id", "revision", name="uq_metadata_revisions_version_revision"),
        CheckConstraint("revision > 0", name="revision_positive"),
        CheckConstraint("validation_state IN ('unverified','needs_review','validated','blocked','rejected')", name="validation_state"),
        CheckConstraint("document_class IS NULL OR document_class IN ('normative','official_other','draft','unknown')", name="document_class"),
        CheckConstraint("actor_kind IN ('system','human','test')", name="actor_kind"),
        CheckConstraint("actor_kind = 'system' OR length(btrim(coalesce(actor_subject,''))) > 0", name="human_actor_required"),
        CheckConstraint("jsonb_typeof(source_values) = 'object' AND jsonb_typeof(extracted_values) = 'object' AND jsonb_typeof(human_corrections) = 'object' AND jsonb_typeof(selected_values) = 'object'", name="metadata_layers_objects"),
        Index("ix_metadata_revisions_validation_state_created_at", "validation_state", "created_at"),
    )


class ArticleReference(Base):
    __tablename__ = "article_references"
    id = identity()
    version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id", ondelete="RESTRICT"), nullable=False)
    source_id = Column(UUID(as_uuid=True), nullable=True)
    reference_key = Column(Text, nullable=False)
    locator = object_json()
    quote_text = Column(Text, nullable=False)
    origin = Column(Text, nullable=False)
    verification_state = Column(Text, nullable=False, server_default="unverified")
    created_at = timestamp()
    __table_args__ = (
        UniqueConstraint("version_id", "reference_key", name="uq_article_references_version_key"),
        ForeignKeyConstraint(["source_id", "version_id"], ["document_sources.id", "document_sources.version_id"], ondelete="RESTRICT", name="fk_article_references_source_same_version"),
        CheckConstraint("length(btrim(reference_key)) > 0 AND length(btrim(quote_text)) > 0", name="reference_content_nonempty"),
        CheckConstraint("jsonb_typeof(locator) = 'object' AND locator <> '{}'::jsonb", name="locator_object_nonempty"),
        CheckConstraint("origin IN ('manual_entry','source_supplied','extracted')", name="reference_origin"),
        CheckConstraint("verification_state IN ('unverified','verified','conflicting')", name="verification_state"),
        Index("ix_article_references_source_id", "source_id"),
    )


class ReviewEvent(Base):
    __tablename__ = "review_events"
    id = identity()
    metadata_revision_id = Column(UUID(as_uuid=True), ForeignKey("metadata_revisions.id", ondelete="RESTRICT"), nullable=False)
    sequence = Column(Integer, nullable=False)
    from_state = Column(Text, nullable=False)
    to_state = Column(Text, nullable=False)
    actor_kind = Column(Text, nullable=False)
    actor_subject = Column(Text, nullable=False)
    note = Column(Text, nullable=True)
    created_at = timestamp()
    __table_args__ = (
        UniqueConstraint("metadata_revision_id", "sequence", name="uq_review_events_revision_sequence"),
        CheckConstraint("sequence > 0", name="sequence_positive"),
        CheckConstraint("(from_state,to_state) IN (('draft','pending'),('pending','approved'),('pending','rejected'),('pending','changes_requested'),('changes_requested','pending'))", name="allowed_transition"),
        CheckConstraint("actor_kind IN ('human','test') AND length(btrim(actor_subject)) > 0", name="actor_required"),
    )


class AuditEvent(Base):
    __tablename__ = "audit_events"
    id = identity()
    document_id = Column(UUID(as_uuid=True), ForeignKey("legal_documents.id", ondelete="RESTRICT"), nullable=True)
    source_id = Column(UUID(as_uuid=True), ForeignKey("document_sources.id", ondelete="RESTRICT"), nullable=True)
    version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id", ondelete="RESTRICT"), nullable=True)
    metadata_revision_id = Column(UUID(as_uuid=True), ForeignKey("metadata_revisions.id", ondelete="RESTRICT"), nullable=True)
    action = Column(Text, nullable=False)
    actor_kind = Column(Text, nullable=False)
    actor_subject = Column(Text, nullable=True)
    changed_fields = Column(ARRAY(Text), nullable=False, server_default=text("'{}'::text[]"))
    created_at = timestamp()
    __table_args__ = (
        CheckConstraint("num_nonnulls(document_id,source_id,version_id,metadata_revision_id) = 1", name="exactly_one_target"),
        CheckConstraint("action IN ('created','linked','validation_changed','review_recorded')", name="action"),
        CheckConstraint("actor_kind IN ('system','human','test')", name="actor_kind"),
        CheckConstraint("actor_kind = 'system' OR length(btrim(coalesce(actor_subject,''))) > 0", name="human_actor_required"),
        CheckConstraint("changed_fields <@ ARRAY['display_label','version_id','baseline_version_id','source_values','extracted_values','human_corrections','selected_values','validation_state','review_state','document_class','issued_on','effective_on']::text[]", name="changed_fields_allowlist"),
        Index("ix_audit_events_document_id_created_at", "document_id", "created_at"),
        Index("ix_audit_events_source_id_created_at", "source_id", "created_at"),
        Index("ix_audit_events_version_id_created_at", "version_id", "created_at"),
        Index("ix_audit_events_metadata_revision_id_created_at", "metadata_revision_id", "created_at"),
    )
