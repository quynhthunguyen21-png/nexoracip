from sqlalchemy import create_engine, text
from sqlalchemy.engine import Connection, Engine

from .settings import DATABASE_NAMES, DatabaseSettings


def make_engine(settings: DatabaseSettings) -> Engine:
    return create_engine(
        settings.url, echo=False, hide_parameters=True, pool_pre_ping=True,
        connect_args={"connect_timeout": 5},
    )


def verify_database(connection: Connection, settings: DatabaseSettings) -> str:
    row = connection.execute(text(
        "SELECT current_database(), inet_server_port(), current_setting('server_version')"
    )).one()
    if row[0] != DATABASE_NAMES[settings.target] or row[1] != 5432:
        raise RuntimeError("Connected database identity does not match the selected local target.")
    return row[2]
