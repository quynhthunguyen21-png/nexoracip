"""Fail closed on database selection. URLs and credentials are never logged."""

from dataclasses import dataclass, field
import os

from sqlalchemy.engine import URL, make_url

DATABASE_NAMES = {"dev": "nexora_cip_dev", "test": "nexora_cip_test"}


class DatabaseConfigurationError(ValueError):
    pass


@dataclass(frozen=True)
class DatabaseSettings:
    target: str
    url: URL = field(repr=False)

    @classmethod
    def from_environment(cls, target: str = "dev") -> "DatabaseSettings":
        if target not in DATABASE_NAMES:
            raise DatabaseConfigurationError("Database target must be dev or test.")
        key = "TEST_DATABASE_URL" if target == "test" else "DATABASE_URL"
        raw = os.environ.get(key, "")
        if not raw:
            raise DatabaseConfigurationError(f"{key} is required; no fallback is permitted.")
        try:
            url = make_url(raw)
            valid = (
                url.drivername in {"postgresql", "postgresql+psycopg"}
                and url.host in {"127.0.0.1", "localhost", "::1"}
                and url.port in {None, 5432}
                and url.database == DATABASE_NAMES[target]
                and set(url.query) <= {"sslmode", "connect_timeout"}
            )
        except Exception:
            raise DatabaseConfigurationError("Invalid local database configuration.") from None
        if not valid:
            raise DatabaseConfigurationError("Only the designated local database and psycopg driver are permitted.")
        return cls(target=target, url=url.set(drivername="postgresql+psycopg"))
