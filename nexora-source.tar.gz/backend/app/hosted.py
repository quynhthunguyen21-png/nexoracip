"""Password-protected demo hosting, not multi-user business authorization."""
import base64
import binascii
import os
import secrets
from pathlib import Path
from starlette.responses import Response
from starlette.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware
from .access import demo_origin


def validate_hosted():
    origin = demo_origin()
    user = os.environ.get('DEMO_USERNAME', '')
    password = os.environ.get('DEMO_PASSWORD', '')
    if not user or ':' in user or len(user) > 100 or len(password) < 16:
        raise ValueError('Hosted demo requires a username and password of at least 16 characters')
    root = Path(os.environ.get('DEMO_STATIC_DIR', Path(__file__).resolve().parents[2] / 'frontend/dist'))
    if not (root / 'index.html').is_file():
        raise ValueError('Build frontend before starting the hosted demo')
    if os.environ.get('JIRA_WRITE_ENABLED') == 'yes':
        storage = os.environ.get('DEMO_STORAGE_DIR', '')
        volume = os.environ.get('RAILWAY_VOLUME_MOUNT_PATH', '')
        if not volume and os.environ.get('RENDER')=='true' and os.environ.get('DEMO_STORAGE_PERSISTENT')=='yes':
            volume=storage  # Explicit operator confirmation after attaching a paid persistent disk.
        if not storage or not Path(storage).is_absolute() or not volume or Path(storage).resolve() != Path(volume).resolve() or not Path(storage).is_dir():
            raise ValueError('Jira dispatch requires DEMO_STORAGE_DIR on a configured persistent hosting volume')
        # No ephemeral fallback when the receipt journal must survive a restart.
        probe = Path(storage) / ('.write-probe-' + secrets.token_hex(8))
        try:
            with probe.open('x') as f:
                f.write('probe')
            probe.unlink()
        except OSError:
            raise ValueError('Jira receipt volume is not writable') from None
    return origin, user, password, root


class DemoPassword:
    def __init__(self, app, username, password):
        self.app = app
        self.expected = (username + ':' + password).encode('utf-8')

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            return
        # Public liveness returns no configuration, provider, document or user data.
        if scope.get('path') in {'/health', '/api/health'} and scope.get('method') in {'GET', 'HEAD'}:
            await self.app(scope, receive, send)
            return
        headers = dict(scope.get('headers', []))
        value = headers.get(b'authorization', b'')
        supplied = b''
        scheme, _, encoded = value.partition(b' ')
        if scheme.lower() == b'basic' and len(encoded) <= 4096:
            try:
                supplied = base64.b64decode(encoded, validate=True)
            except (ValueError, binascii.Error):
                pass
        if not secrets.compare_digest(supplied, self.expected):
            await Response('Nexora CIP: authentication required', 401, headers={'WWW-Authenticate':'Basic realm="Nexora CIP", charset="UTF-8"','Cache-Control':'no-store'})(scope, receive, send)
            return
        async def secured_send(message):
            if message['type'] == 'http.response.start':
                message['headers'] = [(k, v) for k, v in message.get('headers', []) if k.lower() != b'cache-control'] + [(b'cache-control', b'no-store'),(b'x-content-type-options', b'nosniff'),(b'x-frame-options', b'DENY'),(b'referrer-policy', b'same-origin')]
            await send(message)
        await self.app(scope, receive, secured_send)


def install_hosted(app, config):
    origin, user, password, root = config
    from urllib.parse import urlsplit
    app.mount('/', StaticFiles(directory=root, html=True), name='frontend')
    app.add_middleware(DemoPassword, username=user, password=password)
    hosts=[urlsplit(origin).hostname, 'healthcheck.railway.app']
    render_host=urlsplit(os.environ.get('RENDER_EXTERNAL_URL','')).hostname
    if render_host:hosts.append(render_host)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=hosts)
