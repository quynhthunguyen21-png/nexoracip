"""Read process environment only; never load or expose credentials."""

from dataclasses import dataclass
import os


@dataclass(frozen=True)
class Settings:
    app_env: str
    ai_mode: str

    @classmethod
    def from_environment(cls) -> "Settings":
        app_env = os.environ.get("APP_ENV", "development")
        ai_mode = os.environ.get("AI_MODE", "mock")
        if app_env not in {"development", "test", "demo"}:
            raise ValueError("Only development, test and password-protected demo environments are supported.")
        if ai_mode not in {"mock", "openai", "gemini"}:
            raise ValueError("Only mock AI mode or explicit openai/gemini mode is supported.")
        return cls(app_env=app_env, ai_mode=ai_mode)
