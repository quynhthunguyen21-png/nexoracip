"""Explicit local Jira dispatch. Browser approval snapshots are not authentication."""
import asyncio
import hashlib
import json
import os
import re
from datetime import date
from pathlib import Path
from typing import Literal

import httpx
from fastapi import HTTPException, Request
from pydantic import Field
from .jira import router, SITE
from .jira_read import read_guard, project_guard, jira_json, api_base, credentials, check_status, stamp
from .skills import StrictModel

LEDGER = Path(__file__).resolve().parents[2] / 'data/local/jira-dispatch.jsonl'
LOCK = asyncio.Lock()

class Options(StrictModel):
    project: Literal['KAN'] = 'KAN'

class DispatchItem(StrictModel):
    task_id: str = Field(min_length=1, max_length=150)
    title: str = Field(min_length=1, max_length=255)
    description: str = Field(min_length=1, max_length=12000)
    account_id: str = Field(min_length=1, max_length=150, pattern=r'^[a-zA-Z0-9:_-]+$')
    due: date

class Dispatch(Options):
    plan_id: str = Field(min_length=1, max_length=150)
    issue_type: str = Field(pattern=r'^\d{1,30}$')
    stage: Literal['deployed']
    approval_note: str = Field(min_length=1, max_length=2000)
    readiness_note: str = Field(min_length=1, max_length=2000)
    confirm_send: Literal[True]
    items: list[DispatchItem] = Field(min_length=1, max_length=8)

async def users(project, account_id=None):
    params = {'project': project, 'maxResults': 100}
    if account_id:
        params['accountId'] = account_id
    try:
        async with httpx.AsyncClient(timeout=18, follow_redirects=False) as c:
            r = await c.get(api_base()+'/rest/api/3/user/assignable/search', params=params, auth=credentials())
        check_status(r)
        data = r.json()
        if len(r.content)>1024*1024 or not isinstance(data,list):
            raise ValueError()
        return [{'accountId':u['accountId'],'displayName':u['displayName']} for u in data[:100] if u.get('active') is True and isinstance(u.get('accountId'),str) and isinstance(u.get('displayName'),str)]
    except (httpx.HTTPError,ValueError,KeyError,TypeError):
        raise HTTPException(502,'Could not validate assignable Jira users') from None

async def metadata(project):
    project_guard(project)
    permissions = await jira_json('mypermissions', {'projectKey':project,'permissions':'BROWSE_PROJECTS,CREATE_ISSUES,ASSIGN_ISSUES,SCHEDULE_ISSUES'})
    if not all(permissions.get('permissions',{}).get(k,{}).get('havePermission') for k in ['BROWSE_PROJECTS','CREATE_ISSUES','ASSIGN_ISSUES','SCHEDULE_ISSUES']):
        raise HTTPException(403,'Jira requires Browse, Create, Assign and Schedule Issues permissions')
    meta = await jira_json(f'issue/createmeta/{project}/issuetypes', {'maxResults':100})
    if meta.get('total',0)>100:
        raise HTTPException(422,'Issue-type list exceeds supported scope')
    return [{'id':r['id'],'name':r['name']} for r in meta.get('issueTypes',[]) if not r.get('subtask') and re.fullmatch(r'\d{1,30}',str(r.get('id','')))]

@router.post('/dispatch/options')
async def options(body: Options, request: Request):
    read_guard(request)
    return {'issue_types':await metadata(body.project),'users':await users(body.project),'write_enabled':os.environ.get('JIRA_WRITE_ENABLED')=='yes'}

def journal():
    return Path(os.environ['DEMO_STORAGE_DIR']) / 'jira-dispatch.jsonl' if os.environ.get('APP_ENV')=='demo' else LEDGER


def record(data):
    ledger=journal()
    ledger.parent.mkdir(parents=True,exist_ok=True)
    with ledger.open('a',encoding='utf-8') as f:
        f.write(json.dumps({**data,'at':stamp()})+'\n');f.flush();os.fsync(f.fileno())

def previous(label):
    ledger=journal()
    if not ledger.exists():return None
    last=None
    for line in ledger.read_text().splitlines():
        row=json.loads(line)
        if row.get('label')==label:last=row
    return last

async def send_issue(fields):
    async with httpx.AsyncClient(timeout=25,follow_redirects=False) as c:
        return await c.post(api_base()+'/rest/api/3/issue',auth=credentials(),headers={'Accept':'application/json'},json={'fields':fields})

@router.post('/dispatch')
async def dispatch(body: Dispatch, request: Request):
    read_guard(request)
    if os.environ.get('JIRA_WRITE_ENABLED')!='yes':raise HTTPException(403,'Enable Jira writes privately before sending')
    if not body.approval_note.strip() or not body.readiness_note.strip() or len({i.task_id for i in body.items})!=len(body.items):raise HTTPException(422,'Unique tasks and approval/readiness notes required')
    types=await metadata(body.project)
    if body.issue_type not in [t['id'] for t in types]:raise HTTPException(422,'Select an available standard issue type')
    meta=await jira_json(f'issue/createmeta/{body.project}/issuetypes/{body.issue_type}',{'maxResults':200})
    fields=meta.get('fields',[])
    if meta.get('total',0)>200:raise HTTPException(422,'Create metadata exceeds supported scope')
    supported={'project','issuetype','summary','description','assignee','duedate','labels'}
    if any(f.get('required') and f.get('fieldId') not in supported and not f.get('hasDefaultValue') for f in fields):
        raise HTTPException(422,'Jira has additional mandatory fields; configure the create screen first')
    if not {'assignee','duedate','labels'}.issubset({f.get('fieldId') for f in fields}):
        raise HTTPException(422,'Jira create screen must expose Assignee, Due date and Labels')
    for item in body.items:
        if not item.title.strip() or not item.description.strip() or not any(u['accountId']==item.account_id for u in await users(body.project,item.account_id)):
            raise HTTPException(422,'Select an active assignable Jira account for every task')
    receipts=[]
    async with LOCK:
        for item in body.items:
            label='nexora-'+hashlib.sha256(f'{body.project}:{body.plan_id}:{item.task_id}'.encode()).hexdigest()[:32]
            fingerprint=hashlib.sha256(json.dumps(item.model_dump(mode='json'),sort_keys=True).encode()).hexdigest()
            old=previous(label)
            if old and old['fingerprint']!=fingerprint:raise HTTPException(409,'Task changed after dispatch attempt; reconcile the original Jira ticket first')
            found=await jira_json('search/jql',{'jql':f'project = {body.project} AND labels = "{label}"','maxResults':2,'fields':'summary'})
            matches=found.get('issues',[])
            if len(matches)>1:raise HTTPException(409,'Multiple Jira tickets share the dispatch reference; reconcile manually')
            key=matches[0].get('key') if matches else old.get('key') if old and old.get('state')=='created' else None
            if key:
                if not re.fullmatch(body.project+r'-[1-9]\d*',key):raise HTTPException(502,'Invalid Jira receipt')
                receipts.append({'task_id':item.task_id,'key':key,'url':SITE+'/browse/'+key,'reused':True});continue
            if old and old.get('state') in ['pending','uncertain']:
                receipts.append({'task_id':item.task_id,'error':'Previous send is uncertain. Check Jira before retrying.'});break
            base={'label':label,'fingerprint':fingerprint,'state':'pending'}
            record(base)
            description=item.description+'\n\nInternal target: '+item.due.isoformat()+'\nApproval: '+body.approval_note+'\nReadiness: '+body.readiness_note+'\nLocal task: '+item.task_id
            payload={'project':{'key':body.project},'issuetype':{'id':body.issue_type},'summary':item.title,'assignee':{'accountId':item.account_id},'duedate':item.due.isoformat(),'labels':[label],'description':{'type':'doc','version':1,'content':[{'type':'paragraph','content':[{'type':'text','text':description}]}]}}
            try:
                r=await send_issue(payload)
                if r.status_code!=201:
                    record({**base,'state':'failed' if 400<=r.status_code<500 else 'uncertain'})
                    receipts.append({'task_id':item.task_id,'error':f'Jira rejected or could not confirm create ({r.status_code}); check permissions and fields.'});break
                key=r.json().get('key','')
                if not re.fullmatch(body.project+r'-[1-9]\d*',key):raise ValueError()
                record({**base,'state':'created','key':key})
                receipts.append({'task_id':item.task_id,'key':key,'url':SITE+'/browse/'+key,'reused':False})
            except (httpx.HTTPError,ValueError,TypeError):
                record({**base,'state':'uncertain'})
                receipts.append({'task_id':item.task_id,'error':'Send outcome unknown. Check Jira; do not create a replacement.'});break
    return {'receipts':receipts,'complete':len(receipts)==len(body.items) and all('key' in r for r in receipts)}
