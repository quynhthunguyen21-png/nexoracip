"""Nexora CIP local application skeleton."""
