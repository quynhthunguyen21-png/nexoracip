from .access import workspace_guard
"""Bounded, allowlisted Jira reads. No issue writes or automatic legal decisions."""
import asyncio
import base64
import hashlib
import json
import os
import re
from pathlib import Path
from datetime import datetime, timezone

import httpx
from fastapi import HTTPException, Request
from pydantic import Field

from .jira import router, SITE, PROJECT, configuration
from .skills import StrictModel, Context, Citation
from .assistant import local_guard, get_document, guarded_generation, check_citations, envelope


def stamp():
    return datetime.now(timezone.utc).isoformat()


def allowed_projects():
    keys = list(dict.fromkeys(os.environ.get("JIRA_ALLOWED_PROJECTS", PROJECT).strip().split(",")))
    keys = [k.strip() for k in keys]
    if not keys or len(keys) > 10 or any(not re.fullmatch(r"[A-Z][A-Z0-9_]{1,30}", k) for k in keys):
        raise HTTPException(503, "Invalid backend project allowlist")
    return keys


def project_guard(key):
    if key not in allowed_projects():
        raise HTTPException(403, "Project is outside the configured scope")


def issue_guard(key):
    if not re.fullmatch(r"[A-Z][A-Z0-9_]{1,30}-[1-9][0-9]{0,12}", key):
        raise HTTPException(422, "Invalid issue key")
    project_guard(key.rsplit("-", 1)[0])


def read_guard(request):
    workspace_guard(request)
    if configuration():
        raise HTTPException(503, "Configure Jira credentials privately in the backend")


def api_base():
    return "https://api.atlassian.com/ex/jira/" + os.environ["JIRA_CLOUD_ID"].strip() if os.environ.get("JIRA_TOKEN_MODE", "classic") == "scoped" else SITE


def credentials():
    return httpx.BasicAuth(os.environ["JIRA_EMAIL"].strip(), os.environ["JIRA_API_TOKEN"].strip())


def check_status(response):
    if response.status_code == 429:
        raise HTTPException(429, "Jira rate limit reached; retry later")
    if response.status_code in (401, 403):
        raise HTTPException(502, "Jira account lacks access or credentials are invalid")
    if response.status_code == 404:
        raise HTTPException(404, "Jira record is unavailable to this account")
    if response.status_code >= 300:
        raise HTTPException(502, "Jira returned an unsupported response; redirects are not followed")


async def jira_json(path, params=None):
    try:
        async with httpx.AsyncClient(timeout=18, follow_redirects=False) as client:
            response = await client.get(api_base() + "/rest/api/3/" + path, params=params, auth=credentials(), headers={"Accept": "application/json"})
        check_status(response)
        if len(response.content) > 4 * 1024 * 1024:
            raise ValueError()
        data = response.json()
        if not isinstance(data, dict):
            raise ValueError()
        return data
    except httpx.TimeoutException:
        raise HTTPException(504, "Jira timed out") from None
    except (httpx.HTTPError, ValueError, TypeError):
        raise HTTPException(502, "Jira data could not be validated") from None


def plain(value, limit=24000, status=None):
    def cut():
        if status is not None:
            status[0] = True
    if isinstance(value, str):
        if len(value) > limit:
            cut()
        return value[:limit]
    pieces = []
    characters = 0
    remaining = 5000
    def walk(node, depth=0):
        nonlocal remaining, characters
        remaining -= 1
        if remaining < 0 or characters > limit or depth > 18:
            cut()
            return
        if not isinstance(node, dict):
            return
        if isinstance(node.get("text"), str):
            part = node["text"][:limit + 1 - characters]
            pieces.append(part)
            characters += len(part)
        if node.get("type") == "mention":
            part = str(node.get("attrs", {}).get("text", ""))[:min(200, limit + 1 - characters)]
            pieces.append(part)
            characters += len(part)
        children = node.get("content", [])
        if len(children) > 1000:
            cut()
        for child in children[:1000]:
            walk(child, depth + 1)
        if node.get("type") in {"paragraph", "hardBreak", "heading", "codeBlock", "listItem"}:
            pieces.append("\n")
            characters += 1
    walk(value)
    output = "".join(pieces).strip()
    if len(output) > limit:
        cut()
    return output[:limit]


def text(value, maximum=300):
    return value[:maximum] if isinstance(value, str) else ""


def _normalize_issue(data):
    key = data.get("key", "")
    issue_guard(key)
    fields = data.get("fields")
    if not isinstance(fields, dict):
        raise HTTPException(502, "Invalid issue fields")
    comments_field = fields.get("comment") or {}
    comments = comments_field.get("comments", [])
    attachments = fields.get("attachment") or []
    description_status = [False]
    description = plain(fields.get("description"), status=description_status)
    row = {"key": key, "url": SITE + "/browse/" + key, "summary": text(fields.get("summary"), 1000),
        "description": description, "description_truncated": description_status[0], "status": text((fields.get("status") or {}).get("name")),
        "status_category": text(((fields.get("status") or {}).get("statusCategory") or {}).get("key")),
        "assignee": text((fields.get("assignee") or {}).get("displayName")), "updated": text(fields.get("updated"), 50),
        "due": text(fields.get("duedate"), 10), "comments": [{"id": text(c.get("id"), 100), "author": text((c.get("author") or {}).get("displayName")),
             "created": text(c.get("created"), 50), "text": plain(c.get("body"), 2000)} for c in comments[:20] if isinstance(c, dict)],
        "comments_complete": comments_field.get("total", len(comments)) <= min(len(comments), 20),
        "attachments": [{"id": str(a.get("id", "")), "filename": text(a.get("filename"), 200), "size": a.get("size", 0),
            "mime": text(a.get("mimeType"), 100), "created": text(a.get("created"), 50)} for a in attachments[:100] if isinstance(a, dict) and str(a.get("id", "")).isdigit()],
        "content_limits": "Description <=24000 characters, <=20 included comments of 2000 characters; attachments listed, contents not read."}
    row["content_hash"] = hashlib.sha256(json.dumps(row, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    row["fetched_at"] = stamp()
    return row


def normalize_issue(data):
    try:
        return _normalize_issue(data)
    except (AttributeError, TypeError, ValueError, KeyError):
        raise HTTPException(502, "Invalid Jira issue content") from None


async def fetch_issue(key):
    issue_guard(key)
    data = await jira_json("issue/" + key, {"fields": "summary,description,status,assignee,updated,duedate,attachment,comment"})
    if data.get("key") != key:
        raise HTTPException(502, "Unexpected issue identity")
    return normalize_issue(data)


class Query(StrictModel):
    project: str = Field(min_length=2, max_length=31)
    cursor: str = Field(default="", max_length=4096)


@router.post("/projects")
async def projects(request: Request):
    read_guard(request)
    rows = []
    for key in allowed_projects():
        data = await jira_json("project/" + key)
        if data.get("key") != key:
            raise HTTPException(502, "Unexpected project identity")
        rows.append({"key": key, "name": text(data.get("name")), "url": SITE + "/jira/software/projects/" + key + "/list"})
    return {"projects": rows, "fetched_at": stamp(), "scope": "configured_allowlist"}


@router.post("/issues/query")
async def issues(body: Query, request: Request):
    read_guard(request)
    project_guard(body.project)
    params = {"jql": 'project = "' + body.project + '" ORDER BY updated DESC, key ASC', "fields": "summary,status,assignee,updated,duedate", "maxResults": 25}
    if body.cursor:
        params["nextPageToken"] = body.cursor
    data = await jira_json("search/jql", params)
    if not isinstance(data.get("issues"), list) or len(data["issues"]) > 25:
        raise HTTPException(502, "Invalid Jira issue page")
    rows = [normalize_issue(i) for i in data["issues"]]
    if any(r["key"].rsplit("-", 1)[0] != body.project for r in rows):
        raise HTTPException(502, "Jira returned records outside the requested project")
    cursor = data.get("nextPageToken") or ""
    if not isinstance(cursor, str) or len(cursor) > 4096:
        raise HTTPException(502, "Invalid Jira cursor")
    if data.get("isLast") is False and not cursor:
        raise HTTPException(502, "Jira pagination is incomplete; retry the page")
    return {"issues": rows, "next_cursor": cursor, "is_last": not cursor, "fetched_at": stamp(), "project": body.project}


@router.post("/issues/{key}")
async def issue_detail(key: str, request: Request):
    read_guard(request)
    return await fetch_issue(key)


@router.post("/issues/{key}/attachments/{attachment_id}")
async def attachment(key: str, attachment_id: str, request: Request):
    read_guard(request)
    if not attachment_id.isdigit() or len(attachment_id) > 30:
        raise HTTPException(422, "Invalid attachment identity")
    issue = await fetch_issue(key)
    meta = next((a for a in issue["attachments"] if a["id"] == attachment_id), None)
    if not meta:
        raise HTTPException(404, "Attachment does not belong to this issue")
    if not isinstance(meta["size"], int) or not 0 < meta["size"] <= 10 * 1024 * 1024:
        raise HTTPException(422, "Attachment exceeds 10 MiB or is empty")
    extension = meta["filename"].rsplit(".", 1)[-1].lower()
    types = {"pdf": "application/pdf", "txt": "text/plain", "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg"}
    if extension not in types:
        raise HTTPException(422, "Supported evidence downloads: PDF, TXT, PNG and JPEG")
    try:
        async with httpx.AsyncClient(timeout=25, follow_redirects=False) as client:
            async with client.stream("GET", api_base() + "/rest/api/3/attachment/content/" + attachment_id,
                    params={"redirect": "false"}, auth=credentials(), headers={"Accept": "application/octet-stream"}) as response:
                check_status(response)
                parts, size = [], 0
                async for chunk in response.aiter_bytes():
                    size += len(chunk)
                    if size > 10 * 1024 * 1024:
                        raise HTTPException(422, "Attachment exceeds download limit")
                    parts.append(chunk)
        raw = b"".join(parts)
    except httpx.TimeoutException:
        raise HTTPException(504, "Attachment download timed out") from None
    except httpx.HTTPError:
        raise HTTPException(502, "Attachment could not be downloaded") from None
    valid = bool(raw) and (extension == "pdf" and raw.startswith(b"%PDF-") or extension == "png" and raw.startswith(b"\x89PNG\r\n\x1a\n") or extension in {"jpg", "jpeg"} and raw.startswith(b"\xff\xd8\xff"))
    if extension == "txt":
        try:
            valid = bool(raw.strip()) and b"\x00" not in raw
            raw.decode("utf-8-sig")
        except UnicodeError:
            valid = False
    if len(raw) != meta["size"]:
        raise HTTPException(502, "Attachment was incomplete or changed; refresh the issue")
    if not valid:
        raise HTTPException(422, "Attachment format does not match its filename")
    return {"issue_key": key, "attachment_id": attachment_id, "filename": re.sub(r"[\\/\x00-\x1f]", "_", meta["filename"]), "mime": types[extension], "size": len(raw),
        "base64": base64.b64encode(raw).decode(), "sha256": hashlib.sha256(raw).hexdigest(), "fetched_at": stamp(), "issue_updated": issue["updated"]}


class ReviewInput(StrictModel):
    project: str = Field(min_length=2, max_length=31)
    issue_keys: list[str] = Field(min_length=1, max_length=10)
    company: Context
    document_id: str = Field(pattern=r"^L\d{2}$")
    source_excerpt: str = Field(default="", max_length=12000)
    locale: str = Field(pattern=r"^(vi|en)$", default="vi")
    consent_to_send: bool = False


class Finding(StrictModel):
    issue_key: str = Field(max_length=50)
    title: str = Field(min_length=1, max_length=200)
    category: str = Field(pattern=r"^(needs_review|information_gap)$")
    issue_excerpt: str = Field(max_length=2000)
    explanation: str = Field(min_length=1, max_length=2000)
    suggested_action: str = Field(min_length=1, max_length=2000)


class JiraReview(StrictModel):
    summary: str = Field(min_length=1, max_length=4000)
    findings: list[Finding] = Field(max_length=25)
    citations: list[Citation] = Field(max_length=10)
    missing_information: list[str] = Field(max_length=15)
    limitations: list[str] = Field(min_length=1, max_length=10)


def issue_source(issue):
    return issue["summary"] + "\n" + issue["description"] + "\n" + "\n".join(c["text"] for c in issue["comments"])


@router.post("/review")
async def review(body: ReviewInput, request: Request):
    read_guard(request)
    local_guard(request)
    project_guard(body.project)
    if not body.consent_to_send:
        raise HTTPException(422, "Confirm permission to send selected Jira data to OpenAI")
    if len(set(body.issue_keys)) != len(body.issue_keys):
        raise HTTPException(422, "Duplicate issue keys")
    for key in body.issue_keys:
        issue_guard(key)
        if key.rsplit("-", 1)[0] != body.project:
            raise HTTPException(403, "Issue outside the selected project")
    document = get_document(body.document_id)
    semaphore = asyncio.Semaphore(3)
    async def get(key):
        async with semaphore:
            return await fetch_issue(key)
    snapshots = await asyncio.gather(*(get(key) for key in body.issue_keys))
    instructions = Path(__file__).with_name("instructions").joinpath("jira_review.txt").read_text() + "\nRespond in " + body.locale + "."
    content = json.dumps({"company": body.company.model_dump(), "source_excerpt": body.source_excerpt, "document_id": body.document_id, "legal_metadata": document, "jira_snapshot": snapshots}, ensure_ascii=False)
    if len(content) > 160000:
        raise HTTPException(422, "Selected Jira content exceeds review limit; select fewer issues")
    result = await guarded_generation(instructions, [{"type": "input_text", "text": content}], JiraReview)
    sources = {i["key"]: issue_source(i) for i in snapshots}
    try:
        check_citations(result, body)
        if any(f.issue_key not in sources or f.issue_excerpt and f.issue_excerpt not in sources[f.issue_key] for f in result.findings):
            raise ValueError()
    except ValueError:
        raise HTTPException(502, "AI references do not match the selected Jira data or legal excerpt") from None
    return {**envelope(body, result), "project": body.project, "reviewed_at": stamp(), "scope": body.issue_keys, "snapshots": snapshots, "attachment_content_read": False, "instruction_version": "jira-review-2026-10-21.2"}
