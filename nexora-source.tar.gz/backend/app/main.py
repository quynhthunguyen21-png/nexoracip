"""Local health and bounded AI adapters; no database writes or authenticated workflow."""

from fastapi import FastAPI

from .config import Settings
from .skills import router as skills_router
from .jira import router as jira_router
from . import jira_write
from . import jira_read  # registers bounded read/review routes on the same router
from .assistant import router as assistant_router


def create_app() -> FastAPI:
    settings = Settings.from_environment()
    hosted = settings.app_env == 'demo'
    if hosted:
        from .hosted import validate_hosted
        config = validate_hosted()
    app = FastAPI(title="Nexora CIP", version="0.1.0", docs_url=None if hosted else '/docs', redoc_url=None if hosted else '/redoc', openapi_url=None if hosted else '/openapi.json')
    app.state.settings = settings
    prefix = '/api' if hosted else ''
    app.include_router(skills_router, prefix=prefix)
    app.include_router(jira_router, prefix=prefix)
    app.include_router(assistant_router, prefix=prefix)

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    if hosted:
        app.add_api_route('/api/health', health, methods=['GET'], include_in_schema=False)
        from .hosted import install_hosted
        install_hosted(app, config)
    return app


app = create_app()
