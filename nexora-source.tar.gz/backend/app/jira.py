from .access import workspace_guard
"""Read-only Jira connection preparation. Never creates issues or sends business data."""
import os
import re

import httpx
from fastapi import APIRouter, HTTPException, Request

router = APIRouter(prefix="/integrations/jira", tags=["Jira"])
SITE = "https://st-team-ldgo0uso.atlassian.net"
PROJECT = "KAN"


def configuration():
    missing = [name for name in ("JIRA_EMAIL", "JIRA_API_TOKEN") if not os.environ.get(name, "").strip()]
    mode = os.environ.get("JIRA_TOKEN_MODE", "classic")
    cloud_id = os.environ.get("JIRA_CLOUD_ID", "").strip()
    if mode not in ("classic", "scoped"):
        missing.append("JIRA_TOKEN_MODE")
    if mode == "scoped" and not re.fullmatch(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", cloud_id):
        missing.append("JIRA_CLOUD_ID")
    return missing


@router.get("/status")
def status():
    return {"site": SITE, "project_key": PROJECT, "configured": not configuration(), "missing": configuration(),
            "verified": False, "sync_enabled": False, "mode": "human_confirmed_dispatch" if os.environ.get("JIRA_WRITE_ENABLED")=="yes" else "read_only_manual", "write_enabled": os.environ.get("JIRA_WRITE_ENABLED")=="yes", "allowed_projects": os.environ.get("JIRA_ALLOWED_PROJECTS", PROJECT).split(",")}


@router.post("/check")
async def check(request: Request):
    workspace_guard(request)
    if configuration():
        raise HTTPException(503, "Jira is not configured. Set backend environment variables privately.")
    # Fixed site/project. No arbitrary destination URL, redirect, attachment or issue payload.
    base = SITE
    if os.environ.get("JIRA_TOKEN_MODE", "classic") == "scoped":
        base = "https://api.atlassian.com/ex/jira/" + os.environ["JIRA_CLOUD_ID"].strip()
    try:
        async with httpx.AsyncClient(timeout=15, follow_redirects=False) as client:
            response = await client.get(base + "/rest/api/3/project/" + PROJECT,
                auth=httpx.BasicAuth(os.environ["JIRA_EMAIL"].strip(), os.environ["JIRA_API_TOKEN"].strip()),
                headers={"Accept": "application/json"})
        if response.status_code in (401, 403):
            raise HTTPException(502, "Jira authentication or project permission was denied.")
        if response.status_code == 404:
            raise HTTPException(502, "Project KAN is unavailable to this account.")
        if response.status_code == 429:
            raise HTTPException(429, "Jira rate limit reached. Try again later.")
        response.raise_for_status()
        data = response.json()
        if data.get("key") != PROJECT or not isinstance(data.get("name"), str) or not data["name"] or len(data["name"]) > 255:
            raise ValueError("Unexpected project metadata")
        return {"verified": True, "project_key": PROJECT, "project_name": data["name"],
                "site": SITE, "sync_enabled": False, "checked_at_scope": "project_metadata_only"}
    except httpx.TimeoutException:
        raise HTTPException(504, "Jira connection timed out.") from None
    except (httpx.HTTPError, ValueError, TypeError, AttributeError):
        raise HTTPException(502, "Jira connection could not be verified.") from None
