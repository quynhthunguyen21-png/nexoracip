"""Bounded Gemini REST adapter. Credentials stay in headers, never URLs or errors."""
import os
import re

import httpx
from fastapi import HTTPException


def provider():
    return os.environ.get("AI_MODE", "mock")


def readiness():
    mode = provider()
    prefix = "GEMINI" if mode == "gemini" else "OPENAI"
    missing = [key for key in (prefix + "_API_KEY", prefix + "_MODEL") if not os.environ.get(key, "").strip()]
    if mode == "gemini" and os.environ.get("GEMINI_MODEL", "").strip() and not re.fullmatch(r"gemini-[a-zA-Z0-9._-]{1,100}", os.environ["GEMINI_MODEL"]):
        missing.append("GEMINI_MODEL_VALID")
    if os.environ.get("AI_DATA_SHARING_APPROVED") != "yes":
        missing.append("AI_DATA_SHARING_APPROVED")
    if mode not in {"openai", "gemini"}:
        missing.append("AI_MODE")
    return missing


async def generate(instructions, content, output_type, max_tokens=6000):
    if provider() != "gemini" or readiness():
        raise HTTPException(503, "Gemini configuration and data-sharing approval are required.")
    parts = []
    for item in content:
        if item["type"] == "input_text":
            parts.append({"text": item["text"]})
        elif item["type"] == "input_file":
            header, encoded = item["file_data"].split(",", 1)
            if header != "data:application/pdf;base64":
                raise HTTPException(422, "Gemini: convert this contract to PDF or UTF-8 TXT before review.")
            parts.append({"inlineData": {"mimeType": "application/pdf", "data": encoded}})
        else:
            raise ValueError("Unsupported input")
    url = "https://generativelanguage.googleapis.com/v1beta/models/" + os.environ["GEMINI_MODEL"] + ":generateContent"
    async with httpx.AsyncClient(timeout=60, follow_redirects=False) as client:
        response = await client.post(url, headers={"x-goog-api-key": os.environ["GEMINI_API_KEY"]}, json={
            "systemInstruction": {"parts": [{"text": instructions}]},
            "contents": [{"role": "user", "parts": parts}],
            "generationConfig": {"responseMimeType": "application/json", "responseJsonSchema": output_type.model_json_schema(), "maxOutputTokens": max_tokens},
        })
        if response.status_code == 429:
            raise HTTPException(429, {"code": "provider_quota"})
        if response.status_code in {401, 403}:
            raise HTTPException(502, {"code": "provider_access_denied"})
        if response.status_code == 404:
            raise HTTPException(502, {"code": "provider_model_unavailable"})
        if response.status_code == 503:
            raise HTTPException(503, {"code": "provider_unavailable"})
        response.raise_for_status()
        data = response.json()
    candidates = data.get("candidates", [])
    if data.get("promptFeedback", {}).get("blockReason") or len(candidates) != 1 or candidates[0].get("finishReason") != "STOP":
        raise ValueError("Blocked or incomplete Gemini response")
    chunks = candidates[0].get("content", {}).get("parts", [])
    text = "".join(p["text"] for p in chunks if "text" in p and not p.get("thought"))
    return output_type.model_validate_json(text)
