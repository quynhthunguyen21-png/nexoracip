"""Common browser-origin gate; authentication for hosted demos is installed globally."""
import os
from urllib.parse import urlsplit
from fastapi import HTTPException


def demo_origin():
    configured = os.environ.get('DEMO_PUBLIC_URL', '').rstrip('/')
    if not configured and os.environ.get('RAILWAY_PUBLIC_DOMAIN'):
        configured = 'https://' + os.environ['RAILWAY_PUBLIC_DOMAIN'].strip()
    if not configured:
        configured = os.environ.get('RENDER_EXTERNAL_URL', '').rstrip('/')
    parsed = urlsplit(configured)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.path or parsed.query or parsed.fragment:
        raise ValueError('Configure an HTTPS DEMO_PUBLIC_URL or Railway public domain')
    return configured


def workspace_guard(request):
    allowed = {demo_origin()} if os.environ.get('APP_ENV') == 'demo' else {'http://127.0.0.1:5173', 'http://localhost:5173'}
    if request.headers.get('origin') not in allowed or request.headers.get('x-nexora-client') != 'workspace':
        raise HTTPException(403, 'Use the configured workspace origin')
